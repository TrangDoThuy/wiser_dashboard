BEGIN TRANSACTION;
CREATE TABLE `categories` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `previous_` text null, `author_` text null, `slug` varchar(255) null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "categories" VALUES(1,'Energy',NULL,NULL,NULL,1,NULL,1552325063771,1618919325417);
INSERT INTO "categories" VALUES(2,'Materials',NULL,NULL,NULL,1,NULL,1552325063772,1618919306533);
INSERT INTO "categories" VALUES(3,'Industrials',NULL,NULL,NULL,1,NULL,1552325063772,1552325063772);
INSERT INTO "categories" VALUES(4,'Consumer Discretionary',NULL,NULL,NULL,1,NULL,1552325063773,1552325063773);
INSERT INTO "categories" VALUES(5,'Comsumer Staples',NULL,NULL,NULL,1,NULL,1552325063773,1618919302209);
INSERT INTO "categories" VALUES(6,'Health Care',NULL,NULL,NULL,1,NULL,1552325063774,1618919329434);
INSERT INTO "categories" VALUES(7,'Financials',NULL,NULL,NULL,1,NULL,1552325063774,1552325063774);
INSERT INTO "categories" VALUES(8,'Information Technology',NULL,NULL,NULL,1,NULL,1552325063775,1552325063775);
INSERT INTO "categories" VALUES(9,'Communication Services',NULL,NULL,NULL,1,NULL,1552325063775,1552325063775);
INSERT INTO "categories" VALUES(10,'Utilities',NULL,NULL,NULL,1,NULL,1552325063776,1552325063776);
INSERT INTO "categories" VALUES(11,'Real Estate',NULL,NULL,NULL,1,NULL,1552325063777,1552325063777);
CREATE TABLE `components_investment_terms` (



    `id`           INTEGER       PRIMARY KEY AUTOINCREMENT



                               NOT NULL,



    `item` VARCHAR (255) NOT NULL,



    `detail` TEXT



);
INSERT INTO "components_investment_terms" VALUES(1,'Captial Raised','HKD 100,000,000');
INSERT INTO "components_investment_terms" VALUES(2,'Debt','HKD 80,000,000');
INSERT INTO "components_investment_terms" VALUES(3,'Total Asset','HKD 180,000,000');
INSERT INTO "components_investment_terms" VALUES(4,'Net profit','HKD 8,257,000');
INSERT INTO "components_investment_terms" VALUES(5,'Last-Twelve-Month Revenue','HKD 13,500,000');
INSERT INTO "components_investment_terms" VALUES(6,'Exit','IPO / Assets disposal');
INSERT INTO "components_investment_terms" VALUES(7,'Management fee (annum)','2%');
INSERT INTO "components_investment_terms" VALUES(8,'Est. min return (annum)','15% - 20%');
INSERT INTO "components_investment_terms" VALUES(9,'Terms','5 years');
INSERT INTO "components_investment_terms" VALUES(10,'Project structure','50 million USD / project');
INSERT INTO "components_investment_terms" VALUES(11,'Fund Size','Minimum 100 million USD');
INSERT INTO "components_investment_terms" VALUES(12,'Fund Structure','Cayman USD fund & may use QFLP structure');
INSERT INTO "components_investment_terms" VALUES(13,'Minimum Subscription ','USD 200,000 ');
INSERT INTO "components_investment_terms" VALUES(14,'Fund Currency','HKD / USD');
INSERT INTO "components_investment_terms" VALUES(15,'Lock Up Period','6 months');
INSERT INTO "components_investment_terms" VALUES(16,'Redemption Notice','30 days ');
INSERT INTO "components_investment_terms" VALUES(17,'Performance Fee','20%');
INSERT INTO "components_investment_terms" VALUES(18,'Management Fee','2%');
INSERT INTO "components_investment_terms" VALUES(19,'Fund Status','Open, for Professional Investors only ');
INSERT INTO "components_investment_terms" VALUES(20,'Transparency and Reporting','Monthly performance estimate, monthly comments, monthly valuation report from fund administrator, audited financial reporting and ad hoc investor calls and communications');
INSERT INTO "components_investment_terms" VALUES(21,'Fund Administrator','Interactive Brokers ');
INSERT INTO "components_investment_terms" VALUES(22,'Broker','Interactive Brokers (IBKR.US Nasdaq listed)');
INSERT INTO "components_investment_terms" VALUES(23,'Fund Inception','Year 2020');
INSERT INTO "components_investment_terms" VALUES(24,'Redemption Fee','2% during first 6 months, 0% thereafter ');
INSERT INTO "components_investment_terms" VALUES(25,' ','Sale to Japanese REIT



');
INSERT INTO "components_investment_terms" VALUES(26,'Exit','IPO the fund as a Japanese hospitality group



');
INSERT INTO "components_investment_terms" VALUES(27,'Performance fee','at 20% above 8% threshold');
INSERT INTO "components_investment_terms" VALUES(28,'Management fee','2%');
INSERT INTO "components_investment_terms" VALUES(29,'Valuation report','Annually');
INSERT INTO "components_investment_terms" VALUES(30,'Investor report','Quarterly');
INSERT INTO "components_investment_terms" VALUES(31,'Target investment return','IRR 10-12%');
INSERT INTO "components_investment_terms" VALUES(32,'Target annual operating return','4-6%');
INSERT INTO "components_investment_terms" VALUES(33,'Terms','5 years');
INSERT INTO "components_investment_terms" VALUES(34,'Minimum investment amount ','HKD10,000,000 or equivalent');
INSERT INTO "components_investment_terms" VALUES(35,'Target Leverage','~50% LTV



');
INSERT INTO "components_investment_terms" VALUES(36,' ','(3) Local third party operator that offers high return



');
INSERT INTO "components_investment_terms" VALUES(37,' ','(2) Local operator managed / authorized by Hua Liang, or



');
INSERT INTO "components_investment_terms" VALUES(38,'Operator','(1) AB Accommo,



');
INSERT INTO "components_investment_terms" VALUES(39,' ','TMK: B-Lot (Asset Management Company)



');
INSERT INTO "components_investment_terms" VALUES(40,'Asset Management','Cayman fund: Hua Liang Asset Management Limited



');
INSERT INTO "components_investment_terms" VALUES(41,'Long-term Strategy','Acquire + Renovation/ Reconstruction +Reposition + Operate ');
INSERT INTO "components_investment_terms" VALUES(42,'Short-term Strategy','Acquire + Reposition + Operate ');
INSERT INTO "components_investment_terms" VALUES(43,'Location','Tourist area： Tokyo, Osaka, Kyoto, Hokkaido and suburbs



');
INSERT INTO "components_investment_terms" VALUES(45,'Debt/Equity or Hybrid','Equity');
INSERT INTO "components_investment_terms" VALUES(46,'Purpose','Further research and development for core technology, applications of blockchain and vehicle data analytics');
INSERT INTO "components_investment_terms" VALUES(47,'Requested Amount','HKD 20,000,000 for 10% of company shares');
INSERT INTO "components_investment_terms" VALUES(48,'Tenor','5 years');
INSERT INTO "components_investment_terms" VALUES(49,'Debt/Equity or Hybrid','Debt');
INSERT INTO "components_investment_terms" VALUES(50,'Purpose','Opening physical stores in coverage area');
INSERT INTO "components_investment_terms" VALUES(51,'Requested Amount','HKD 76,000,000');
INSERT INTO "components_investment_terms" VALUES(52,'Last-Twelve-Month Revenue','HKD 3,890,000');
INSERT INTO "components_investment_terms" VALUES(53,'Net Profit','HKD 1,560,000');
INSERT INTO "components_investment_terms" VALUES(54,'Total Asset','HKD 300,000,000');
INSERT INTO "components_investment_terms" VALUES(55,'Debt','HKD 100,000,000');
INSERT INTO "components_investment_terms" VALUES(56,'Capital Raised','HKD 200,000,000');
INSERT INTO "components_investment_terms" VALUES(57,'Debt/Equity or Hybrid','Equity');
INSERT INTO "components_investment_terms" VALUES(58,'Purpose','Hardware optimization, further research and development for solar products');
INSERT INTO "components_investment_terms" VALUES(59,'Requested Amount','HKD 250,000,000 for 5% of company shares');
INSERT INTO "components_investment_terms" VALUES(60,'Last-Twelve-Month Revenue','HKD 90,000,650');
INSERT INTO "components_investment_terms" VALUES(61,'Net Profit','HKD 10,890,000');
INSERT INTO "components_investment_terms" VALUES(62,'Total Asset','HKD 4,000,000,000');
INSERT INTO "components_investment_terms" VALUES(63,'Debt','HKD 2,000,000,000');
INSERT INTO "components_investment_terms" VALUES(64,'Capital Raised','HKD 2,000,000,000');
INSERT INTO "components_investment_terms" VALUES(65,'Debt/Equity or Hybrid','Equity');
INSERT INTO "components_investment_terms" VALUES(66,'Purpose','Opening physical stores ');
INSERT INTO "components_investment_terms" VALUES(67,'Requested Amount','HKD 400,000,000 for 10% of company shares');
INSERT INTO "components_investment_terms" VALUES(68,'Last-Twelve-Month Revenue','HKD 100,790,000');
INSERT INTO "components_investment_terms" VALUES(69,'Net Profit','HKD 86,500,000');
INSERT INTO "components_investment_terms" VALUES(70,'Total Asset','HKD 3,000,000,000');
INSERT INTO "components_investment_terms" VALUES(71,'Debt','HKD 1,500,000,000');
INSERT INTO "components_investment_terms" VALUES(72,'Capital Raised','HKD 1,500,000,000');
CREATE TABLE `components_meta` (`id` integer not null primary key autoincrement, `name` varchar(255) not null, `content` varchar(255) not null);
CREATE TABLE `components_seo` (`id` integer not null primary key autoincrement, `title` varchar(255) not null, `description` varchar(255) not null);
INSERT INTO "components_seo" VALUES(1,'Foodadvisor Strapi Demo App','Foodadvisor is Strapi''s demo App, Strap is an open-source headless CMS fueled by a community of amazing developers, designers and users. At Strapi, our mission is to fuel the world’s creativity by unleashing the power of content.');
CREATE TABLE `components_seo_components` (`id` integer not null primary key autoincrement, `field` varchar(255) not null, `order` integer not null, `component_type` varchar(255) not null, `component_id` integer not null, `components_seo_id` integer not null, constraint `components_seo_id_fk` foreign key(`components_seo_id`) references `components_seo`(`id`) on delete CASCADE);
CREATE TABLE `core_store` (



                          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,







`key` varchar(255)  NULL ,







`value` longtext  NULL ,







`type` varchar(255)  NULL ,







`environment` varchar(255)  NULL ,







`tag` varchar(255)  NULL



                        );
INSERT INTO "core_store" VALUES(1,'db_model_categories','{



  "name": { "default": "", "type": "string" },







  "projects": {



    "collection": "project",



    "via": "category",



    "isVirtual": true



  },



  "created_by": { "model": "user", "plugin": "admin" },



  "updated_by": { "model": "user", "plugin": "admin" },



  "created_at": { "type": "currentTimestamp" },



  "updated_at": { "type": "currentTimestamp" }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(5,'db_model_core_store','{"key":{"type":"string"},"value":{"type":"text"},"type":{"type":"string"},"environment":{"type":"string"},"tag":{"type":"string"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(6,'db_model_upload_file','{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"collection":"*","filter":"field","configurable":false},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(7,'db_model_users-permissions_permission','{"type":{"type":"string","required":true,"configurable":false},"controller":{"type":"string","required":true,"configurable":false},"action":{"type":"string","required":true,"configurable":false},"enabled":{"type":"boolean","required":true,"configurable":false},"policy":{"type":"string","configurable":false},"role":{"model":"role","via":"permissions","plugin":"users-permissions","configurable":false},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(8,'db_model_users-permissions_role','{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"collection":"permission","via":"role","plugin":"users-permissions","configurable":false,"isVirtual":true},"users":{"collection":"user","via":"role","configurable":false,"plugin":"users-permissions","isVirtual":true},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(9,'db_model_users-permissions_user','{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"model":"role","via":"users","plugin":"users-permissions","configurable":false},"picture":{"model":"file","via":"related","plugin":"upload","required":false},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(10,'db_model_upload_file_morph','{"upload_file_id":{"type":"integer"},"related_id":{"type":"integer"},"related_type":{"type":"text"},"field":{"type":"text"},"order":{"type":"integer"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(11,'plugin_content-manager_schema','{



  "generalSettings": {



    "search": true,



    "filters": true,



    "bulkActions": true,



    "pageEntries": 10



  },



  "models": {



    "plugins": {



      "upload": {



        "file": {



          "label": "File",



          "labelPlural": "Files",



          "orm": "bookshelf",



          "search": true,



          "filters": true,



          "bulkActions": true,



          "pageEntries": 10,



          "defaultSort": "id",



          "sort": "ASC",



          "options": { "timestamps": ["created_at", "updated_at"] },



          "editDisplay": {



            "availableFields": {



              "name": {



                "label": "Name",



                "type": "string",



                "description": "",



                "name": "name",



                "editable": true,



                "placeholder": ""



              },



              "hash": {



                "label": "Hash",



                "type": "string",



                "description": "",



                "name": "hash",



                "editable": true,



                "placeholder": ""



              },



              "sha256": {



                "label": "Sha256",



                "type": "string",



                "description": "",



                "name": "sha256",



                "editable": true,



                "placeholder": ""



              },



              "ext": {



                "label": "Ext",



                "type": "string",



                "description": "",



                "name": "ext",



                "editable": true,



                "placeholder": ""



              },



              "mime": {



                "label": "Mime",



                "type": "string",



                "description": "",



                "name": "mime",



                "editable": true,



                "placeholder": ""



              },



              "size": {



                "label": "Size",



                "type": "string",



                "description": "",



                "name": "size",



                "editable": true,



                "placeholder": ""



              },



              "url": {



                "label": "Url",



                "type": "string",



                "description": "",



                "name": "url",



                "editable": true,



                "placeholder": ""



              },



              "provider": {



                "label": "Provider",



                "type": "string",



                "description": "",



                "name": "provider",



                "editable": true,



                "placeholder": ""



              },



              "public_id": {



                "label": "Public_id",



                "type": "string",



                "description": "",



                "name": "public_id",



                "editable": true,



                "placeholder": ""



              }



            },



            "displayedField": "id",



            "fields": [



              "name",



              "hash",



              "sha256",



              "ext",



              "mime",



              "size",



              "url",



              "provider",



              "public_id"



            ],



            "relations": []



          },



          "info": { "name": "file", "description": "" },



          "connection": "default",



          "collectionName": "upload_file",



          "attributes": {



            "name": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "hash": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "sha256": { "type": "string", "configurable": false },



            "ext": { "type": "string", "configurable": false },



            "mime": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "size": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "url": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "provider": {



              "type": "string",



              "configurable": false,



              "required": true



            },



            "public_id": { "type": "string", "configurable": false },



            "related": {



              "collection": "*",



              "filter": "field",



              "configurable": false



            }



          },



          "globalId": "UploadFile",



          "globalName": "UploadFile",



          "primaryKey": "id",



          "associations": [



            {



              "alias": "related",



              "type": "collection",



              "related": ["Project", "UsersPermissionsUser"],



              "nature": "manyMorphToOne",



              "autoPopulate": true,



              "filter": "field"



            }



          ],



          "fields": {



            "name": {



              "label": "Name",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "name",



              "sortable": true,



              "searchable": true



            },



            "hash": {



              "label": "Hash",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "hash",



              "sortable": true,



              "searchable": true



            },



            "sha256": {



              "label": "Sha256",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "sha256",



              "sortable": true,



              "searchable": true



            },



            "ext": {



              "label": "Ext",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "ext",



              "sortable": true,



              "searchable": true



            },



            "mime": {



              "label": "Mime",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "mime",



              "sortable": true,



              "searchable": true



            },



            "size": {



              "label": "Size",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "size",



              "sortable": true,



              "searchable": true



            },



            "url": {



              "label": "Url",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "url",



              "sortable": true,



              "searchable": true



            },



            "provider": {



              "label": "Provider",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "provider",



              "sortable": true,



              "searchable": true



            },



            "public_id": {



              "label": "Public_id",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "public_id",



              "sortable": true,



              "searchable": true



            }



          },



          "listDisplay": [



            {



              "name": "id",



              "label": "Id",



              "type": "string",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Name",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "name",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Hash",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "hash",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Sha256",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "sha256",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Ext",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "ext",



              "sortable": true,



              "searchable": true



            }



          ],



          "relations": {



            "related": {



              "alias": "related",



              "type": "collection",



              "related": ["Project", "UsersPermissionsUser"],



              "nature": "manyMorphToOne",



              "autoPopulate": true,



              "filter": "field",



              "description": "",



              "label": "Related",



              "displayedAttribute": "id"



            }



          }



        }



      },



      "users-permissions": {



        "permission": {



          "label": "Permission",



          "labelPlural": "Permissions",



          "orm": "bookshelf",



          "search": true,



          "filters": true,



          "bulkActions": true,



          "pageEntries": 10,



          "defaultSort": "id",



          "sort": "ASC",



          "options": { "timestamps": false },



          "editDisplay": {



            "availableFields": {



              "type": {



                "label": "Type",



                "type": "string",



                "description": "",



                "name": "type",



                "editable": true,



                "placeholder": ""



              },



              "controller": {



                "label": "Controller",



                "type": "string",



                "description": "",



                "name": "controller",



                "editable": true,



                "placeholder": ""



              },



              "action": {



                "label": "Action",



                "type": "string",



                "description": "",



                "name": "action",



                "editable": true,



                "placeholder": ""



              },



              "enabled": {



                "label": "Enabled",



                "type": "boolean",



                "description": "",



                "name": "enabled",



                "editable": true,



                "placeholder": ""



              },



              "policy": {



                "label": "Policy",



                "type": "string",



                "description": "",



                "name": "policy",



                "editable": true,



                "placeholder": ""



              }



            },



            "displayedField": "id",



            "fields": ["type", "controller", "action", "enabled", "policy"],



            "relations": ["role"]



          },



          "info": { "name": "permission", "description": "" },



          "connection": "default",



          "collectionName": "users-permissions_permission",



          "attributes": {



            "type": {



              "type": "string",



              "required": true,



              "configurable": false



            },



            "controller": {



              "type": "string",



              "required": true,



              "configurable": false



            },



            "action": {



              "type": "string",



              "required": true,



              "configurable": false



            },



            "enabled": {



              "type": "boolean",



              "required": true,



              "configurable": false



            },



            "policy": { "type": "string", "configurable": false },



            "role": {



              "model": "role",



              "via": "permissions",



              "plugin": "users-permissions",



              "configurable": false



            }



          },



          "globalId": "UsersPermissionsPermission",



          "globalName": "UsersPermissionsPermission",



          "primaryKey": "id",



          "associations": [



            {



              "alias": "role",



              "type": "model",



              "model": "role",



              "via": "permissions",



              "nature": "manyToOne",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions"



            }



          ],



          "fields": {



            "type": {



              "label": "Type",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "type",



              "sortable": true,



              "searchable": true



            },



            "controller": {



              "label": "Controller",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "controller",



              "sortable": true,



              "searchable": true



            },



            "action": {



              "label": "Action",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "action",



              "sortable": true,



              "searchable": true



            },



            "enabled": {



              "label": "Enabled",



              "description": "",



              "type": "boolean",



              "disabled": false,



              "name": "enabled",



              "sortable": true,



              "searchable": true



            },



            "policy": {



              "label": "Policy",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "policy",



              "sortable": true,



              "searchable": true



            }



          },



          "listDisplay": [



            {



              "name": "id",



              "label": "Id",



              "type": "string",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Type",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "type",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Controller",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "controller",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Action",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "action",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Enabled",



              "description": "",



              "type": "boolean",



              "disabled": false,



              "name": "enabled",



              "sortable": true,



              "searchable": true



            }



          ],



          "relations": {



            "role": {



              "alias": "role",



              "type": "model",



              "model": "role",



              "via": "permissions",



              "nature": "manyToOne",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions",



              "description": "",



              "label": "Role",



              "displayedAttribute": "name"



            }



          }



        },



        "role": {



          "label": "Role",



          "labelPlural": "Roles",



          "orm": "bookshelf",



          "search": true,



          "filters": true,



          "bulkActions": true,



          "pageEntries": 10,



          "defaultSort": "id",



          "sort": "ASC",



          "options": { "timestamps": false },



          "editDisplay": {



            "availableFields": {



              "name": {



                "label": "Name",



                "type": "string",



                "description": "",



                "name": "name",



                "editable": true,



                "placeholder": ""



              },



              "description": {



                "label": "Description",



                "type": "string",



                "description": "",



                "name": "description",



                "editable": true,



                "placeholder": ""



              },



              "type": {



                "label": "Type",



                "type": "string",



                "description": "",



                "name": "type",



                "editable": true,



                "placeholder": ""



              }



            },



            "displayedField": "id",



            "fields": ["name", "description", "type"],



            "relations": ["permissions", "users"]



          },



          "info": { "name": "role", "description": "" },



          "connection": "default",



          "collectionName": "users-permissions_role",



          "attributes": {



            "name": {



              "type": "string",



              "minLength": 3,



              "required": true,



              "configurable": false



            },



            "description": { "type": "string", "configurable": false },



            "type": { "type": "string", "unique": true, "configurable": false },



            "permissions": {



              "collection": "permission",



              "via": "role",



              "plugin": "users-permissions",



              "configurable": false,



              "isVirtual": true



            },



            "users": {



              "collection": "user",



              "via": "role",



              "plugin": "users-permissions",



              "isVirtual": true



            }



          },



          "globalId": "UsersPermissionsRole",



          "globalName": "UsersPermissionsRole",



          "primaryKey": "id",



          "associations": [



            {



              "alias": "permissions",



              "type": "collection",



              "collection": "permission",



              "via": "role",



              "nature": "oneToMany",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions"



            },



            {



              "alias": "users",



              "type": "collection",



              "collection": "user",



              "via": "role",



              "nature": "oneToMany",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions"



            }



          ],



          "fields": {



            "name": {



              "label": "Name",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "name",



              "sortable": true,



              "searchable": true



            },



            "description": {



              "label": "Description",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "description",



              "sortable": true,



              "searchable": true



            },



            "type": {



              "label": "Type",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "type",



              "sortable": true,



              "searchable": true



            }



          },



          "listDisplay": [



            {



              "name": "id",



              "label": "Id",



              "type": "string",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Name",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "name",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Description",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "description",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Type",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "type",



              "sortable": true,



              "searchable": true



            }



          ],



          "relations": {



            "permissions": {



              "alias": "permissions",



              "type": "collection",



              "collection": "permission",



              "via": "role",



              "nature": "oneToMany",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions",



              "description": "",



              "label": "Permissions",



              "displayedAttribute": "type"



            },



            "users": {



              "alias": "users",



              "type": "collection",



              "collection": "user",



              "via": "role",



              "nature": "oneToMany",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions",



              "description": "",



              "label": "Users",



              "displayedAttribute": "username"



            }



          }



        },



        "user": {



          "label": "User",



          "labelPlural": "Users",



          "orm": "bookshelf",



          "search": true,



          "filters": true,



          "bulkActions": true,



          "pageEntries": 10,



          "defaultSort": "id",



          "sort": "ASC",



          "options": { "timestamps": false },



          "editDisplay": {



            "availableFields": {



              "username": {



                "label": "Username",



                "type": "string",



                "description": "",



                "name": "username",



                "editable": true,



                "placeholder": ""



              },



              "email": {



                "label": "Email",



                "type": "email",



                "description": "",



                "name": "email",



                "editable": true,



                "placeholder": ""



              },



              "provider": {



                "label": "Provider",



                "type": "string",



                "description": "",



                "name": "provider",



                "editable": true,



                "placeholder": ""



              },



              "password": {



                "label": "Password",



                "type": "password",



                "description": "",



                "name": "password",



                "editable": true,



                "placeholder": ""



              },



              "confirmed": {



                "label": "Confirmed",



                "type": "boolean",



                "description": "",



                "name": "confirmed",



                "editable": true,



                "placeholder": ""



              },



              "blocked": {



                "label": "Blocked",



                "type": "boolean",



                "description": "",



                "name": "blocked",



                "editable": true,



                "placeholder": ""



              },



              "picture": {



                "description": "",



                "editable": true,



                "label": "Picture",



                "multiple": false,



                "name": "picture",



                "placeholder": "",



                "type": "file",



                "disabled": false



              }



            },



            "displayedField": "id",



            "fields": [



              "username",



              "email",



              "provider",



              "password",



              "confirmed",



              "blocked",



              "picture"



            ],



            "relations": ["role"]



          },



          "info": { "name": "user", "description": "" },



          "connection": "default",



          "collectionName": "users-permissions_user",



          "attributes": {



            "username": {



              "type": "string",



              "minLength": 3,



              "unique": true,



              "configurable": false,



              "required": true



            },



            "email": {



              "type": "email",



              "minLength": 6,



              "configurable": false,



              "required": true



            },



            "provider": { "type": "string", "configurable": false },



            "password": {



              "type": "password",



              "minLength": 6,



              "configurable": false,



              "private": true



            },



            "confirmed": {



              "type": "boolean",



              "default": false,



              "configurable": false



            },



            "blocked": {



              "type": "boolean",



              "default": false,



              "configurable": false



            },



            "role": {



              "model": "role",



              "via": "users",



              "plugin": "users-permissions",



              "configurable": false



            },



















            "picture": {



              "model": "file",



              "via": "related",



              "plugin": "upload",



              "required": false



            }



          },



          "globalId": "UsersPermissionsUser",



          "globalName": "UsersPermissionsUser",



          "primaryKey": "id",



          "associations": [



            {



              "alias": "role",



              "type": "model",



              "model": "role",



              "via": "users",



              "nature": "manyToOne",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions"



            },















            {



              "alias": "picture",



              "type": "model",



              "model": "file",



              "via": "related",



              "nature": "oneToManyMorph",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "upload",



              "filter": "field"



            }



          ],



          "fields": {



            "username": {



              "label": "Username",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "username",



              "sortable": true,



              "searchable": true



            },



            "email": {



              "label": "Email",



              "description": "",



              "type": "email",



              "disabled": false,



              "name": "email",



              "sortable": true,



              "searchable": true



            },



            "provider": {



              "label": "Provider",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "provider",



              "sortable": true,



              "searchable": true



            },



            "password": {



              "label": "Password",



              "description": "",



              "type": "password",



              "disabled": false,



              "name": "password",



              "sortable": true,



              "searchable": true



            },



            "confirmed": {



              "label": "Confirmed",



              "description": "",



              "type": "boolean",



              "disabled": false,



              "name": "confirmed",



              "sortable": true,



              "searchable": true



            },



            "blocked": {



              "label": "Blocked",



              "description": "",



              "type": "boolean",



              "disabled": false,



              "name": "blocked",



              "sortable": true,



              "searchable": true



            }



          },



          "listDisplay": [



            {



              "name": "id",



              "label": "Id",



              "type": "string",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Username",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "username",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Email",



              "description": "",



              "type": "email",



              "disabled": false,



              "name": "email",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Provider",



              "description": "",



              "type": "string",



              "disabled": false,



              "name": "provider",



              "sortable": true,



              "searchable": true



            },



            {



              "label": "Password",



              "description": "",



              "type": "password",



              "disabled": false,



              "name": "password",



              "sortable": true,



              "searchable": true



            }



          ],



          "relations": {



            "role": {



              "alias": "role",



              "type": "model",



              "model": "role",



              "via": "users",



              "nature": "manyToOne",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "users-permissions",



              "description": "",



              "label": "Role",



              "displayedAttribute": "name"



            },















            "picture": {



              "alias": "picture",



              "type": "model",



              "model": "file",



              "via": "related",



              "nature": "oneToManyMorph",



              "autoPopulate": true,



              "dominant": true,



              "plugin": "upload",



              "filter": "field",



              "description": "",



              "label": "Picture",



              "displayedAttribute": "name"



            }



          }



        }



      }



    },



    "category": {



      "label": "Category",



      "labelPlural": "Categories",



      "orm": "bookshelf",



      "search": true,



      "filters": true,



      "bulkActions": true,



      "pageEntries": 10,



      "defaultSort": "id",



      "sort": "ASC",



      "options": {



        "increments": true,



        "timestamps": ["created_at", "updated_at"],



        "comment": ""



      },



      "editDisplay": {



        "availableFields": {



          "name": {



            "label": "Name",



            "type": "string",



            "description": "",



            "name": "name",



            "editable": true,



            "placeholder": ""



          }



        },



        "displayedField": "id",



        "fields": ["name"],



        "relations": [ "projects"]



      },



      "info": { "name": "category", "description": "" },



      "connection": "default",



      "collectionName": "categories",



      "attributes": {



        "name": { "default": "", "type": "string" },







        "projects": {



          "collection": "project",



          "via": "category",



          "isVirtual": true



        }



      },



      "globalId": "Category",



      "globalName": "Category",



      "primaryKey": "id",



      "associations": [







        {



          "alias": "projects",



          "type": "collection",



          "collection": "project",



          "via": "category",



          "nature": "oneToMany",



          "autoPopulate": true,



          "dominant": true



        }



      ],



      "fields": {



        "name": {



          "label": "Name",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "name",



          "sortable": true,



          "searchable": true



        }



      },



      "listDisplay": [



        {



          "name": "id",



          "label": "Id",



          "type": "string",



          "sortable": true,



          "searchable": true



        },



        {



          "label": "Name",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "name",



          "sortable": true,



          "searchable": true



        }



      ],



      "relations": {







        "projects": {



          "alias": "projects",



          "type": "collection",



          "collection": "project",



          "via": "category",



          "nature": "oneToMany",



          "autoPopulate": true,



          "dominant": true,



          "description": "",



          "label": "Projects",



          "displayedAttribute": "name"



        }



      }



    },



    "project": {



      "label": "Project",



      "labelPlural": "Projects",



      "orm": "bookshelf",



      "search": true,



      "filters": true,



      "bulkActions": true,



      "pageEntries": 10,



      "defaultSort": "id",



      "sort": "ASC",



      "options": {



        "increments": true,



        "timestamps": ["created_at", "updated_at"],



        "comment": ""



      },



      "editDisplay": {



        "availableFields": {



          "name": {



            "label": "Name",



            "type": "string",



            "description": "",



            "name": "name",



            "editable": true,



            "placeholder": ""



          },



          "description": {



            "label": "Description",



            "type": "text",



            "description": "",



            "name": "description",



            "editable": true,



            "placeholder": ""



          },



          "investment_terms": {



            "label": "Investment_terms",



            "type": "text",



            "description": "",



            "name": "investment_terms",



            "editable": true,



            "placeholder": ""



          },



          "address": {



            "label": "Address",



            "type": "string",



            "description": "",



            "name": "address",



            "editable": true,



            "placeholder": ""



          },



          "website": {



            "label": "Website",



            "type": "string",



            "description": "",



            "name": "website",



            "editable": true,



            "placeholder": ""



          },



          "phone": {



            "label": "Phone",



            "type": "string",



            "description": "",



            "name": "phone",



            "editable": true,



            "placeholder": ""



          },



          "amount": {



            "label": "Amount",



            "type": "enumeration",



            "description": "",



            "name": "amount",



            "editable": true,



            "placeholder": ""



          },



          "location": {



            "label": "Location",



            "type": "enumeration",



            "description": "",



            "name": "location",



            "editable": true,



            "placeholder": ""



          },



          "cover": {



            "description": "",



            "editable": true,



            "label": "Cover",



            "multiple": true,



            "name": "cover",



            "placeholder": "",



            "type": "file",



            "disabled": false



          }



        },



        "displayedField": "id",



        "fields": [



          "name",



          "description",



          "investment_terms",



          "address",



          "website",



          "phone",



          "amount",



          "location",



          "cover"



        ],



        "relations": [ "category"]



      },



      "info": { "name": "project", "description": "" },



      "connection": "default",



      "collectionName": "projects",



      "attributes": {



        "cover": {



          "collection": "file",



          "via": "related",



          "plugin": "upload",



          "required": false



        },



        "name": { "default": "", "type": "string" },



        "description": { "default": "", "type": "text" },



        "investment_terms": { "default": "", "type": "text" },



        "address": { "default": "", "type": "string" },



        "website": { "default": "", "type": "string" },



        "phone": { "default": "", "type": "string" },



        "amount": { "default": "", "type": "string" },



        "location": {



          "default": "",



          "type": "enumeration",



          "enum": ["_china", "_japan", "_united_states", "_others"]



        },







        "category": { "model": "category", "via": "projects" }



      },



      "globalId": "Project",



      "globalName": "Project",



      "primaryKey": "id",



      "associations": [



        {



          "alias": "cover",



          "type": "collection",



          "collection": "file",



          "via": "related",



          "nature": "manyToManyMorph",



          "autoPopulate": true,



          "dominant": true,



          "plugin": "upload",



          "filter": "field"



        },







        {



          "alias": "category",



          "type": "model",



          "model": "category",



          "via": "projects",



          "nature": "manyToOne",



          "autoPopulate": true,



          "dominant": true



        }



      ],



      "fields": {



        "name": {



          "label": "Name",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "name",



          "sortable": true,



          "searchable": true



        },



        "description": {



          "label": "Description",



          "description": "",



          "type": "text",



          "disabled": false,



          "name": "description",



          "sortable": true,



          "searchable": true



        },



        "investment_terms": {



          "label": "Investment_terms",



          "description": "",



          "type": "text",



          "disabled": false,



          "name": "investment_terms",



          "sortable": true,



          "searchable": true



        },



        "address": {



          "label": "Address",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "address",



          "sortable": true,



          "searchable": true



        },



        "website": {



          "label": "Website",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "website",



          "sortable": true,



          "searchable": true



        },



        "phone": {



          "label": "Phone",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "phone",



          "sortable": true,



          "searchable": true



        },



        "amount": {



          "label": "Amount",



          "description": "",



          "type": "enumeration",



          "disabled": false,



          "name": "amount",



          "sortable": true,



          "searchable": true



        },



        "location": {



          "label": "Location",



          "description": "",



          "type": "enumeration",



          "disabled": false,



          "name": "location",



          "sortable": true,



          "searchable": true



        }



      },



      "listDisplay": [



        {



          "name": "id",



          "label": "Id",



          "type": "string",



          "sortable": true,



          "searchable": true



        },



        {



          "label": "Name",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "name",



          "sortable": true,



          "searchable": true



        },



        {



          "label": "Description",



          "description": "",



          "type": "text",



          "disabled": false,



          "name": "description",



          "sortable": true,



          "searchable": true



        },



        {



          "label": "Investment_terms",



          "description": "",



          "type": "text",



          "disabled": false,



          "name": "investment_terms",



          "sortable": true,



          "searchable": true



        },



        {



          "label": "Address",



          "description": "",



          "type": "string",



          "disabled": false,



          "name": "address",



          "sortable": true,



          "searchable": true



        }



      ],



      "relations": {



        "cover": {



          "alias": "cover",



          "type": "collection",



          "collection": "file",



          "via": "related",



          "nature": "manyToManyMorph",



          "autoPopulate": true,



          "dominant": true,



          "plugin": "upload",



          "filter": "field",



          "description": "",



          "label": "Cover",



          "displayedAttribute": "name"



        },







        "category": {



          "alias": "category",



          "type": "model",



          "model": "category",



          "via": "projects",



          "nature": "manyToOne",



          "autoPopulate": true,



          "dominant": true,



          "description": "",



          "label": "Category",



          "displayedAttribute": "name"



        }



      }



    },











  },



  "layout": {



    "user": {



      "actions": {



        "create": "User.create",



        "update": "User.update",



        "destroy": "User.destroy",



        "deleteall": "User.destroyAll"



      },



      "attributes": {



        "username": { "className": "col-md-6" },



        "email": { "className": "col-md-6" },



        "resetPasswordToken": { "className": "d-none" },



        "role": { "className": "d-none" }



      }



    },



    "category": { "attributes": {} },







 







    "project": { "attributes": {} },







    "comment": { "attributes": {} }



  }



}



','object','','');
INSERT INTO "core_store" VALUES(12,'core_application','{"name":"Default Application","description":"This API is going to be awesome!"}','object','','');
INSERT INTO "core_store" VALUES(13,'plugin_users-permissions_grant','{"email":{"enabled":true,"icon":"envelope"},"discord":{"enabled":false,"icon":"comments","key":"","secret":"","callback":"/auth/discord/callback","scope":["identify","email"]},"facebook":{"enabled":false,"icon":"facebook-official","key":"","secret":"","callback":"/auth/facebook/callback","scope":["email"]},"google":{"enabled":false,"icon":"google","key":"","secret":"","callback":"/auth/google/callback","scope":["email"]},"github":{"enabled":false,"icon":"github","key":"","secret":"","callback":"/auth/github/callback","scope":["user","user:email"],"redirect_uri":"/auth/github/callback"},"microsoft":{"enabled":false,"icon":"windows","key":"","secret":"","callback":"/auth/microsoft/callback","scope":["user.read"]},"twitter":{"enabled":false,"icon":"twitter","key":"","secret":"","callback":"/auth/twitter/callback"},"instagram":{"enabled":false,"icon":"instagram","key":"","secret":"","callback":"/auth/instagram/callback","scope":["user_profile"]},"vk":{"enabled":false,"icon":"vk","key":"","secret":"","callback":"/auth/vk/callback","scope":["email"]},"twitch":{"enabled":false,"icon":"twitch","key":"","secret":"","callback":"/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"enabled":false,"icon":"linkedin","key":"","secret":"","callback":"/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"enabled":false,"icon":"aws","key":"","secret":"","subdomain":"my.subdomain.com","callback":"/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"enabled":false,"icon":"reddit","key":"","secret":"","state":true,"callback":"/auth/reddit/callback","scope":["identity"]},"auth0":{"enabled":false,"icon":"","key":"","secret":"","subdomain":"my-tenant.eu","callback":"/auth/auth0/callback","scope":["openid","email","profile"]}}','object','','');
INSERT INTO "core_store" VALUES(14,'plugin_email_provider','{"provider":"sendmail","name":"Sendmail","auth":{"sendmail_default_from":{"label":"Sendmail Default From","type":"text"},"sendmail_default_replyto":{"label":"Sendmail Default Reply-To","type":"text"}}}','object','development','');
INSERT INTO "core_store" VALUES(15,'plugin_upload_provider','{"provider":"local","name":"Local server","enabled":true,"sizeLimit":1000000}','object','development','');
INSERT INTO "core_store" VALUES(16,'plugin_users-permissions_email','{"reset_password":{"display":"Email.template.reset_password","icon":"refresh","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"­Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\n\n<p>But don’t worry! You can use the following link to reset your password:</p>\n\n<p><%= URL %>?code=<%= TOKEN %></p>\n\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square-o","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\n\n<p>You have to confirm your email address. Please click on the link below.</p>\n\n<p><%= URL %>?confirmation=<%= CODE %></p>\n\n<p>Thanks.</p>"}}}','object','','');
INSERT INTO "core_store" VALUES(17,'plugin_users-permissions_advanced','{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_confirmation_redirection":"http://localhost:1337/admin","default_role":"authenticated"}','object','','');
INSERT INTO "core_store" VALUES(18,'db_model_groups_opening_hours','{"day_interval":{"required":true,"type":"string"},"opening_hour":{"type":"string"},"closing_hour":{"type":"string"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(19,'db_model_strapi_administrator','{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"registrationToken":{"type":"string","configurable":false,"private":true},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"collection":"role","collectionName":"strapi_users_roles","via":"users","dominant":true,"plugin":"admin","configurable":false,"private":true,"attribute":"role","column":"id","isVirtual":true},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(20,'plugin_documentation_config','{"restrictedAccess":false}','object','','');
INSERT INTO "core_store" VALUES(25,'plugin_content_manager_configuration_content_types::admin.administrator','{"uid":"administrator","source":"admin","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","resetPasswordToken"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"resetPasswordToken","size":6}],[{"name":"blocked","size":4}]],"editRelations":[]}}','object','','');
INSERT INTO "core_store" VALUES(26,'plugin_content_manager_configuration_content_types::upload.file','{"uid":"file","source":"upload","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"hash":{"edit":{"label":"Hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Hash","searchable":true,"sortable":true}},"sha256":{"edit":{"label":"Sha256","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Sha256","searchable":true,"sortable":true}},"ext":{"edit":{"label":"Ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"Mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"Size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Size","searchable":true,"sortable":true}},"url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"public_id":{"edit":{"label":"Public_id","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Public_id","searchable":true,"sortable":true}},"related":{"edit":{"label":"Related","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Related","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","hash","sha256"],"edit":[[{"name":"name","size":6},{"name":"hash","size":6}],[{"name":"sha256","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":6}],[{"name":"url","size":6},{"name":"provider","size":6}],[{"name":"public_id","size":6}]],"editRelations":["related"]}}','object','','');
INSERT INTO "core_store" VALUES(27,'plugin_content_manager_configuration_content_types::users-permissions.permission','{"uid":"permission","source":"users-permissions","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"controller":{"edit":{"label":"Controller","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Controller","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"enabled":{"edit":{"label":"Enabled","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Enabled","searchable":true,"sortable":true}},"policy":{"edit":{"label":"Policy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Policy","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}}},"layouts":{"list":["id","type","controller","action"],"edit":[[{"name":"type","size":6},{"name":"controller","size":6}],[{"name":"action","size":6},{"name":"enabled","size":4}],[{"name":"policy","size":6}]],"editRelations":["role"]}}','object','','');
INSERT INTO "core_store" VALUES(28,'plugin_content_manager_configuration_content_types::users-permissions.role','{"uid":"role","source":"users-permissions","settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"id","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"type"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6}]],"editRelations":["permissions","users"]}}','object','','');
INSERT INTO "core_store" VALUES(29,'plugin_content_manager_configuration_content_types::users-permissions.user','{



  "uid": "user",



  "source": "users-permissions",



  "settings": {



    "searchable": true,



    "filterable": true,



    "bulkable": true,



    "pageSize": 10,



    "mainField": "id",



    "defaultSortBy": "id",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": true, "sortable": true }



    },



    "username": {



      "edit": {



        "label": "Username",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Username", "searchable": true, "sortable": true }



    },



    "email": {



      "edit": {



        "label": "Email",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Email", "searchable": true, "sortable": true }



    },



    "provider": {



      "edit": {



        "label": "Provider",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": { "label": "Provider", "searchable": true, "sortable": true }



    },



    "password": {



      "edit": {



        "label": "Password",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Password", "searchable": true, "sortable": true }



    },



    "resetPasswordToken": {



      "edit": {



        "label": "ResetPasswordToken",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": {



        "label": "ResetPasswordToken",



        "searchable": true,



        "sortable": true



      }



    },



    "confirmed": {



      "edit": {



        "label": "Confirmed",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Confirmed", "searchable": true, "sortable": true }



    },



    "blocked": {



      "edit": {



        "label": "Blocked",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Blocked", "searchable": true, "sortable": true }



    },



    "role": {



      "edit": {



        "label": "Role",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true,



        "mainField": "name"



      },



      "list": { "label": "Role", "searchable": false, "sortable": false }



    },















    "picture": {



      "edit": {



        "label": "Picture",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Picture", "searchable": false, "sortable": false }



    },



    "created_at": {



      "edit": {



        "label": "Created_at",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": { "label": "Created_at", "searchable": true, "sortable": true }



    },



    "updated_at": {



      "edit": {



        "label": "Updated_at",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": { "label": "Updated_at", "searchable": true, "sortable": true }



    }



  },



  "layouts": {



    "list": ["id", "username", "email", "provider"],



    "edit": [



      [



        { "name": "username", "size": 6 },



        { "name": "email", "size": 6 }



      ],



      [



        { "name": "provider", "size": 6 },



        { "name": "password", "size": 6 }



      ],



      [



        { "name": "resetPasswordToken", "size": 6 },



        { "name": "confirmed", "size": 4 }



      ],



      [



        { "name": "blocked", "size": 4 },



        { "name": "picture", "size": 6 }



      ]



    ],



    "editRelations": ["role"]



  }



}



','object','','');
INSERT INTO "core_store" VALUES(30,'plugin_content_manager_configuration_groups::opening_hours','{"uid":"opening_hours","isGroup":true,"settings":{"searchable":true,"filterable":true,"bulkable":true,"pageSize":10,"mainField":"day_interval","defaultSortBy":"day_interval","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"day_interval":{"edit":{"label":"Day_interval","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Day_interval","searchable":true,"sortable":true}},"opening_hour":{"edit":{"label":"Opening_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Opening_hour","searchable":true,"sortable":true}},"closing_hour":{"edit":{"label":"Closing_hour","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Closing_hour","searchable":true,"sortable":true}}},"layouts":{"list":["day_interval","opening_hour","closing_hour"],"edit":[[{"name":"day_interval","size":6},{"name":"opening_hour","size":6}],[{"name":"closing_hour","size":6}]],"editRelations":[]}}','object','','');
INSERT INTO "core_store" VALUES(31,'db_model_strapi_webhooks','{"name":{"type":"string"},"url":{"type":"text"},"headers":{"type":"json"},"events":{"type":"json"},"enabled":{"type":"boolean"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(32,'db_model_components_opening_hours','{"day_interval":{"required":true,"type":"string"},"opening_hour":{"type":"string"},"closing_hour":{"type":"string"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(33,'plugin_content_manager_configuration_content_types::application::category.category','{"uid":"application::category.category","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"id","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"projects":{"edit":{"label":"Projects","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Projects","searchable":false,"sortable":false}},"previous_":{"edit":{"label":"Previous_","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Previous_","searchable":false,"sortable":false}},"author_":{"edit":{"label":"Author_","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Author_","searchable":false,"sortable":false}},"slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"edit":[[{"name":"name","size":6},{"name":"slug","size":6}]],"editRelations":["projects"],"list":["id","name","created_at","updated_at"]}}','object','','');
INSERT INTO "core_store" VALUES(37,'plugin_content_manager_configuration_content_types::plugins::upload.file','{"uid":"plugins::upload.file","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"AlternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"AlternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"Caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"Width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Width","searchable":true,"sortable":true}},"height":{"edit":{"label":"Height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"Formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"Hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"Ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"Mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"Size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Size","searchable":true,"sortable":true}},"url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"PreviewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"PreviewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"Provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Provider_metadata","searchable":false,"sortable":false}},"related":{"edit":{"label":"Related","description":"","placeholder":"","visible":true,"editable":true,"mainField":"id"},"list":{"label":"Related","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","hash","alternativeText"],"edit":[[{"name":"name","size":6},{"name":"hash","size":6}],[{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"alternativeText","size":6},{"name":"caption","size":6}],[{"name":"width","size":4},{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"previewUrl","size":6}]],"editRelations":["related"]}}','object','','');
INSERT INTO "core_store" VALUES(38,'plugin_content_manager_configuration_content_types::plugins::users-permissions.permission','{"uid":"plugins::users-permissions.permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"type","defaultSortBy":"type","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"controller":{"edit":{"label":"Controller","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Controller","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"enabled":{"edit":{"label":"Enabled","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Enabled","searchable":true,"sortable":true}},"policy":{"edit":{"label":"Policy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Policy","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}}},"layouts":{"list":["id","type","controller","action"],"edit":[[{"name":"type","size":6},{"name":"controller","size":6}],[{"name":"action","size":6},{"name":"enabled","size":4}],[{"name":"policy","size":6}]],"editRelations":["role"]}}','object','','');
INSERT INTO "core_store" VALUES(39,'plugin_content_manager_configuration_content_types::plugins::users-permissions.role','{"uid":"plugins::users-permissions.role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"type"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users","searchable":false,"sortable":false}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6}]],"editRelations":["permissions","users"]}}','object','','');
INSERT INTO "core_store" VALUES(41,'plugin_content_manager_configuration_content_types::plugins::users-permissions.user','{"uid":"plugins::users-permissions.user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"Provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"Confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}},"picture":{"edit":{"label":"Picture","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Picture","searchable":false,"sortable":false}},"remarks":{"edit":{"label":"Remarks","description":"","placeholder":"","visible":true,"editable":true,"mainField":"phone"},"list":{"label":"Remarks","searchable":false,"sortable":false}},"projects":{"edit":{"label":"Projects","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Projects","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"picture","size":6}]],"editRelations":["role","remarks","projects"]}}','object','','');
INSERT INTO "core_store" VALUES(43,'db_model_strapi_permission','{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"fields":{"type":"json","configurable":false,"required":false,"default":[]},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"model":"role","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(44,'db_model_strapi_role','{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"collection":"user","via":"roles","plugin":"admin","attribute":"user","column":"id","isVirtual":true},"permissions":{"configurable":false,"plugin":"admin","collection":"permission","via":"role","isVirtual":true},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(45,'db_model_strapi_users_roles','{"user_id":{"type":"integer"},"role_id":{"type":"integer"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(46,'plugin_upload_settings','{"sizeOptimization":true,"responsiveDimensions":true}','object','development','');
INSERT INTO "core_store" VALUES(47,'plugin_content_manager_configuration_content_types::strapi::permission','{"uid":"strapi::permission","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"subject":{"edit":{"label":"Subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"Properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"Conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"Role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Role","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","created_at"],"edit":[[{"name":"action","size":6},{"name":"subject","size":6}],[{"name":"conditions","size":12}],[{"name":"properties","size":12}]],"editRelations":["role"]}}','object','','');
INSERT INTO "core_store" VALUES(48,'plugin_content_manager_configuration_content_types::strapi::role','{"uid":"strapi::role","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"code":{"edit":{"label":"Code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Code","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"users":{"edit":{"label":"Users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"Users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"Permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"Permissions","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"editRelations":["users","permissions"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6}]]}}','object','','');
INSERT INTO "core_store" VALUES(49,'plugin_content_manager_configuration_content_types::strapi::user','{"uid":"strapi::user","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"Firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"Lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"Username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Username","searchable":true,"sortable":true}},"email":{"edit":{"label":"Email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Email","searchable":true,"sortable":true}},"password":{"edit":{"label":"Password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"ResetPasswordToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ResetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"RegistrationToken","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"RegistrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"IsActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"IsActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"Roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"Blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"PreferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"PreferedLanguage","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"resetPasswordToken","size":6}],[{"name":"registrationToken","size":6},{"name":"isActive","size":4}],[{"name":"blocked","size":4},{"name":"preferedLanguage","size":6}]],"editRelations":["roles"]}}','object','','');
INSERT INTO "core_store" VALUES(50,'db_model_components_meta','{"name":{"required":true,"type":"string"},"content":{"type":"string","required":true}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(51,'db_model_components_seo','{"title":{"required":true,"type":"string"},"description":{"type":"string","required":true},"meta":{"type":"component","component":"project.meta","repeatable":true}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(54,'db_model_histories','{"action":{"type":"string"},"contenttype":{"type":"string"},"author":{"type":"json"},"before":{"type":"json"},"after":{"type":"json"},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(55,'db_model_homepages','{



  "title": { "type": "string" },



  "seo": {



    "type": "component",



    "component": "project.seo",



    "required": true



  },



  "body": {



    "type": "dynamiczone",



    "components": [







      "project.slider",



      "project.text"



    ]



  },



  "created_by": { "model": "user", "plugin": "admin" },



  "updated_by": { "model": "user", "plugin": "admin" },



  "created_at": { "type": "currentTimestamp" },



  "updated_at": { "type": "currentTimestamp" }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(56,'plugin_content_manager_configuration_content_types::application::history.history','{"uid":"application::history.history","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"action":{"edit":{"label":"Action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Action","searchable":true,"sortable":true}},"contenttype":{"edit":{"label":"Contenttype","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Contenttype","searchable":true,"sortable":true}},"author":{"edit":{"label":"Author","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Author","searchable":false,"sortable":false}},"before":{"edit":{"label":"Before","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Before","searchable":false,"sortable":false}},"after":{"edit":{"label":"After","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"After","searchable":false,"sortable":false}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","contenttype","created_at"],"editRelations":[],"edit":[[{"name":"action","size":6},{"name":"contenttype","size":6}],[{"name":"author","size":12}],[{"name":"before","size":12}],[{"name":"after","size":12}]]}}','object','','');
INSERT INTO "core_store" VALUES(62,'model_def_strapi::core-store','{"uid":"strapi::core-store","collectionName":"core_store","info":{"name":"core_store","description":""},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"key":{"type":"string"},"value":{"type":"text"},"type":{"type":"string"},"environment":{"type":"string"},"tag":{"type":"string"}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(68,'model_def_application::category.category','{"uid":"application::category.category","collectionName":"categories","kind":"collectionType","info":{"name":"category","description":""},"options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":"","draftAndPublish":false},"attributes":{"name":{"type":"string"},"projects":{"via":"category","collection":"project","isVirtual":true},"previous_":{"private":true,"type":"json"},"author_":{"private":true,"type":"json"},"slug":{"type":"uid","targetField":"name"},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(69,'model_def_application::history.history','{"uid":"application::history.history","collectionName":"histories","kind":"collectionType","info":{"name":"history"},"options":{"increments":true,"timestamps":["created_at","updated_at"]},"attributes":{"action":{"type":"string"},"contenttype":{"type":"string"},"author":{"type":"json"},"before":{"type":"json"},"after":{"type":"json"},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(70,'model_def_application::homepage.homepage','{



  "uid": "application::homepage.homepage",



  "collectionName": "homepages",



  "kind": "singleType",



  "info": { "name": "homepage" },



  "options": { "increments": true, "timestamps": ["created_at", "updated_at"] },



  "attributes": {



    "title": { "type": "string" },



    "seo": {



      "type": "component",



      "component": "project.seo",



      "required": true



    },



    "body": {



      "type": "dynamiczone",



      "components": [







        "project.slider",



        "project.text"



      ]



    },



    "created_by": {



      "model": "user",



      "plugin": "admin",



      "configurable": false,



      "writable": false,



      "private": true



    },



    "updated_by": {



      "model": "user",



      "plugin": "admin",



      "configurable": false,



      "writable": false,



      "private": true



    }



  }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(74,'model_def_strapi::webhooks','{"uid":"strapi::webhooks","collectionName":"strapi_webhooks","info":{"name":"Strapi webhooks","description":""},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string"},"url":{"type":"text"},"headers":{"type":"json"},"events":{"type":"json"},"enabled":{"type":"boolean"}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(75,'model_def_strapi::permission','{"uid":"strapi::permission","collectionName":"strapi_permission","kind":"collectionType","info":{"name":"Permission","description":""},"options":{"timestamps":["created_at","updated_at"]},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"model":"role","plugin":"admin"}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(76,'model_def_strapi::role','{"uid":"strapi::role","collectionName":"strapi_role","kind":"collectionType","info":{"name":"Role","description":""},"options":{"timestamps":["created_at","updated_at"]},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"collection":"user","via":"roles","plugin":"admin","attribute":"user","column":"id","isVirtual":true},"permissions":{"configurable":false,"plugin":"admin","collection":"permission","via":"role","isVirtual":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(77,'model_def_strapi::user','{"uid":"strapi::user","collectionName":"strapi_administrator","kind":"collectionType","info":{"name":"User","description":""},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"registrationToken":{"type":"string","configurable":false,"private":true},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"collection":"role","collectionName":"strapi_users_roles","via":"users","dominant":true,"plugin":"admin","configurable":false,"private":true,"attribute":"role","column":"id","isVirtual":true},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(78,'model_def_plugins::upload.file','{"uid":"plugins::upload.file","collectionName":"upload_file","kind":"collectionType","info":{"name":"file","description":""},"options":{"timestamps":["created_at","updated_at"]},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"collection":"*","filter":"field","configurable":false},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(79,'model_def_plugins::users-permissions.permission','{"uid":"plugins::users-permissions.permission","collectionName":"users-permissions_permission","kind":"collectionType","info":{"name":"permission","description":""},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false}},"attributes":{"type":{"type":"string","required":true,"configurable":false},"controller":{"type":"string","required":true,"configurable":false},"action":{"type":"string","required":true,"configurable":false},"enabled":{"type":"boolean","required":true,"configurable":false},"policy":{"type":"string","configurable":false},"role":{"model":"role","via":"permissions","plugin":"users-permissions","configurable":false},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(80,'model_def_plugins::users-permissions.role','{"uid":"plugins::users-permissions.role","collectionName":"users-permissions_role","kind":"collectionType","info":{"name":"role","description":""},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"collection":"permission","via":"role","plugin":"users-permissions","configurable":false,"isVirtual":true},"users":{"collection":"user","via":"role","configurable":false,"plugin":"users-permissions","isVirtual":true},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(81,'model_def_plugins::users-permissions.user','{"uid":"plugins::users-permissions.user","collectionName":"users-permissions_user","kind":"collectionType","info":{"name":"user","description":""},"options":{"draftAndPublish":false,"timestamps":["created_at","updated_at"]},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true},"resetPasswordToken":{"type":"string","configurable":false,"private":true},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"model":"role","via":"users","plugin":"users-permissions","configurable":false},"picture":{"model":"file","via":"related","plugin":"upload","required":false,"pluginOptions":{}},"remarks":{"collection":"remark","via":"users_permissions_user","isVirtual":true},"projects":{"collection":"project","via":"users_permissions_user","isVirtual":true},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(100,'model_def_plugins::i18n.locale','{"uid":"plugins::i18n.locale","collectionName":"i18n_locales","kind":"collectionType","info":{"name":"locale","description":""},"options":{"timestamps":["created_at","updated_at"]},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(101,'plugin_i18n_default_locale','"en"','string','','');
INSERT INTO "core_store" VALUES(102,'plugin_content_manager_configuration_content_types::plugins::i18n.locale','{"uid":"plugins::i18n.locale","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"code":{"edit":{"label":"Code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Code","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","created_at"],"editRelations":[],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]}}','object','','');
INSERT INTO "core_store" VALUES(103,'core_admin_auth','{"providers":{"autoRegister":false,"defaultRole":null}}','object','','');
INSERT INTO "core_store" VALUES(104,'db_model_projects','{



  "cover": {



    "collection": "file",



    "via": "related",



    "plugin": "upload"



  },







  "name": {



    "default": "",



    "type": "string"



  },







  "description": {



    "default": "",



    "type": "text"



  },







  "address": { "default": "", "type": "string" },



  "website": { "default": "", "type": "string" },



  "phone": { "default": "", "type": "string" },



  "amount": { "default": "", "type": "string" },



  "location": {



    "default": "",



    "type": "enumeration",



    "enum": ["_china", "_japan", "_united_states", "_others"]



  },



  "category": { "model": "category", "via": "projects" },



  "investment_terms": {



    "type": "component",



    "component": "project.investment-terms",



    "min": 1,



    "repeatable": true,



    "required": true



  },



  "status": {



    "default": "draft",



    "type": "enumeration",



    "enum": ["draft", "published", "archived"]



  },



  "published_at": { "type": "datetime" },



  "_previous": { "private": true, "type": "json" },



  "_author": { "private": true, "type": "json" },



  "created_by": { "model": "user", "plugin": "admin" },



  "updated_by": { "model": "user", "plugin": "admin" },



  "created_at": { "type": "currentTimestamp" },



  "updated_at": { "type": "currentTimestamp" }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(106,'db_model_projects','{"cover":{"collection":"file","via":"related","plugin":"upload"},"name":{"default":"","type":"string"},"description":{"default":"","type":"text"},"address":{"default":"","type":"string"},"website":{"default":"","type":"string"},"phone":{"default":"","type":"string"},"amount":{"default":"","type":"string"},"location":{"default":"","type":"enumeration","enum":["_china","_japan","_united_states","_others"]},"category":{"model":"category","via":"projects"},"investment_terms":{"type":"component","component":"project.investment-terms","min": 1,"repeatable": true,"required":true},"status":{"default":"draft","type":"enumeration","enum":["draft","published","archived"]},"seo":{"type":"component","component":"project.seo","required":true},"published_at":{"type":"datetime"},"_previous":{"private":true,"type":"json"},"_author":{"private":true,"type":"json"},"created_by":{"model":"user","plugin":"admin"},"updated_by":{"model":"user","plugin":"admin"},"created_at":{"type":"currentTimestamp"},"updated_at":{"type":"currentTimestamp"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(108,'db_model_groups_investment_terms','{



  "item": { "required": true, "type": "string" },



  "detail": { "type": "string" }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(109,'plugin_content_manager_configuration_groups::investsment_terms','{



  "uid": "investment_terms",



  "isGroup": true,



  "settings": {



    "searchable": true,



    "filterable": true,



    "bulkable": true,



    "pageSize": 10,



    "mainField": "item",



    "defaultSortBy": "item",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": false, "sortable": false }



    },



    "item": {



      "edit": {



        "label": "Item",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Item", "searchable": true, "sortable": true }



    },



    "detail": {



      "edit": {



        "label": "Detail",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Detail", "searchable": true, "sortable": true }



    }



  },



  "layouts": {



    "list": ["item", "detail"],



    "edit": [



      [



        { "name": "item", "size": 6 },



        { "name": "detail", "size": 6 }



      ]



    ],



    "editRelations": []



  }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(110,'db_model_components_investment_terms','{



  "item": { "required": true, "type": "string" },



  "detail": { "type": "string" }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(112,'plugin_content_manager_configuration_content_types::application::project.project','{



  "uid": "application::project.project",



  "settings": {



    "bulkable": true,



    "filterable": true,



    "searchable": true,



    "pageSize": 10,



    "mainField": "name",



    "defaultSortBy": "name",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "publish_at": {



      "edit": {



        "label": "Publish_at",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Publish_at", "searchable": true, "sortable": true }



    },



    "previous_": {



      "edit": {



        "label": "Previous_",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Previous_", "searchable": false, "sortable": false }



    },



    "investment_terms": {



      "edit": {



        "label": "Investment_terms",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": {



        "label": "Investment_terms",



        "searchable": false,



        "sortable": false



      }



    },



    "amount": {



      "edit": {



        "label": "Amount",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Amount", "searchable": true, "sortable": true }



    },



    "created_at": {



      "edit": {



        "label": "Created_at",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": { "label": "Created_at", "searchable": true, "sortable": true }



    },



    "name": {



      "edit": {



        "label": "Name",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Name", "searchable": true, "sortable": true }



    },



    "slug": {



      "edit": {



        "label": "Slug",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Slug", "searchable": true, "sortable": true }



    },



    "phone": {



      "edit": {



        "label": "Phone",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Phone", "searchable": true, "sortable": true }



    },



    "location": {



      "edit": {



        "label": "Location",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Location", "searchable": true, "sortable": true }



    },



    "author_": {



      "edit": {



        "label": "Author_",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Author_", "searchable": false, "sortable": false }



    },



    "address": {



      "edit": {



        "label": "Address",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Address", "searchable": true, "sortable": true }



    },



    "updated_at": {



      "edit": {



        "label": "Updated_at",



        "description": "",



        "placeholder": "",



        "visible": false,



        "editable": true



      },



      "list": { "label": "Updated_at", "searchable": true, "sortable": true }



    },



    "cover": {



      "edit": {



        "label": "Cover",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Cover", "searchable": false, "sortable": false }



    },







    "website": {



      "edit": {



        "label": "Website",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Website", "searchable": true, "sortable": true }



    },



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": true, "sortable": true }



    },



    "description": {



      "edit": {



        "label": "Description",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Description", "searchable": true, "sortable": true }



    },



    "seo": {



      "edit": {



        "label": "Seo",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Seo", "searchable": false, "sortable": false }



    },



    "category": {



      "edit": {



        "label": "Category",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true,



        "mainField": "name"



      },



      "list": { "label": "Category", "searchable": false, "sortable": false }



    }



  },



  "layouts": {



    "edit": [



      [



        { "name": "cover", "size": 6 },



        { "name": "name", "size": 6 }



      ],



      [



        { "name": "description", "size": 6 },



        { "name": "address", "size": 6 }



      ],



      [



        { "name": "website", "size": 6 },



        { "name": "phone", "size": 6 }



      ],



      [



        { "name": "amount", "size": 6 },



        { "name": "location", "size": 6 }



      ],



      [{ "name": "investment_terms", "size": 12 }],



      [{ "name": "seo", "size": 12 }],



      [



        { "name": "publish_at", "size": 6 },



        { "name": "slug", "size": 6 }



      ]



    ],



    "editRelations": [ "category"],



    "list": ["id", "cover", "name", "publish_at", "category"]



  }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(114,'plugin_content_manager_configuration_components::project.invesment-terms','{



  "uid": "project.investment-terms",



  "isComponent": true,



  "settings": {



    "bulkable": true,



    "filterable": true,



    "searchable": true,



    "pageSize": 10,



    "mainField": "item",



    "defaultSortBy": "item",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": false, "sortable": false }



    },



    "item": {



      "edit": {



        "label": "Item",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Item", "searchable": true, "sortable": true }



    },



    "detail": {



      "edit": {



        "label": "Detail",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Detail", "searchable": true, "sortable": true }



    }



  },



  "layouts": {



    "list": ["id", "item", "detail"],



    "edit": [



      [



        { "name": "item", "size": 6 },



        { "name": "detail", "size": 6 }



      ]



    ],



    "editRelations": []



  }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(115,'db_model_components_project_sliders','{"image":{"collection":"file","via":"related","allowedTypes":["images","files","videos"],"plugin":"upload","required":false},"title":{"type":"string"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(116,'db_model_components_project_texts','{"title":{"type":"string"},"content":{"type":"richtext"}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(117,'plugin_content_manager_configuration_components::project.meta','{



  "uid": "project.meta",



  "isComponent": true,



  "settings": {



    "bulkable": true,



    "filterable": true,



    "searchable": true,



    "pageSize": 10,



    "mainField": "name",



    "defaultSortBy": "name",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": false, "sortable": false }



    },



    "name": {



      "edit": {



        "label": "Name",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Name", "searchable": true, "sortable": true }



    },



    "content": {



      "edit": {



        "label": "Content",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Content", "searchable": true, "sortable": true }



    }



  },



  "layouts": {



    "list": ["id", "name", "content"],



    "edit": [



      [



        { "name": "name", "size": 6 },



        { "name": "content", "size": 6 }



      ]



    ],



    "editRelations": []



  }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(118,'plugin_content_manager_configuration_components::project.seo','{



  "uid": "project.seo",



  "isComponent": true,



  "settings": {



    "bulkable": true,



    "filterable": true,



    "searchable": true,



    "pageSize": 10,



    "mainField": "title",



    "defaultSortBy": "title",



    "defaultSortOrder": "ASC"



  },



  "metadatas": {



    "id": {



      "edit": {},



      "list": { "label": "Id", "searchable": false, "sortable": false }



    },



    "title": {



      "edit": {



        "label": "Title",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Title", "searchable": true, "sortable": true }



    },



    "description": {



      "edit": {



        "label": "Description",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Description", "searchable": true, "sortable": true }



    },



    "meta": {



      "edit": {



        "label": "Meta",



        "description": "",



        "placeholder": "",



        "visible": true,



        "editable": true



      },



      "list": { "label": "Meta", "searchable": false, "sortable": false }



    }



  },



  "layouts": {



    "list": ["id", "title", "description"],



    "edit": [



      [



        { "name": "title", "size": 6 },



        { "name": "description", "size": 6 }



      ],



      [{ "name": "meta", "size": 12 }]



    ],



    "editRelations": []



  }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(119,'model_def_project.meta','{"uid":"project.meta","collectionName":"components_meta","info":{"name":"meta","description":"","icon":"address-book"},"options":{"timestamps":false},"attributes":{"name":{"required":true,"type":"string"},"content":{"type":"string","required":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(120,'model_def_project.investment-terms','{"uid":"project.investment-terms","collectionName":"components_investment_terms","info":{"name":"investment-terms","description":"","icon":"calendar-alt"},"options":{"timestamps":false},"attributes":{"item":{"required":true,"type":"string"},"detail":{"type":"string"}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(121,'model_def_project.seo','{"uid":"project.seo","collectionName":"components_seo","info":{"name":"seo","description":"","icon":"anchor"},"options":{"timestamps":false},"attributes":{"title":{"required":true,"type":"string"},"description":{"type":"string","required":true},"meta":{"type":"component","component":"project.meta","repeatable":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(122,'model_def_project.slider','{



  "uid": "project.slider",



  "collectionName": "components_project_sliders",



  "info": { "name": "slider", "icon": "images" },



  "options": { "timestamps": false },



  "attributes": {



    "image": {



      "collection": "file",



      "via": "related",



      "allowedTypes": ["images", "files", "videos"],



      "plugin": "upload",



      "required": false



    },



    "title": { "type": "string" }



  }



}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(123,'model_def_project.text','{



  "uid": "project.text",



  "collectionName": "components_project_texts",



  "info": { "name": "text", "icon": "align-justify" },



  "options": { "timestamps": false },



  "attributes": {



    "title": { "type": "string" },



    "content": { "type": "richtext" }



  }



}



','object',NULL,NULL);
INSERT INTO "core_store" VALUES(125,'model_def_application::project.project','{"uid":"application::project.project","collectionName":"projects","kind":"collectionType","info":{"name":"project","description":""},"options":{"increments":true,"timestamps":["created_at","updated_at"],"comment":"","draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"cover":{"collection":"file","via":"related","plugin":"upload","required":false,"pluginOptions":{"i18n":{"localized":true}}},"name":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"address":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"website":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"phone":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"amount":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"location":{"type":"enumeration","enum":["_china","_japan","_US","_others"],"pluginOptions":{"i18n":{"localized":true}}},"publish_at":{"type":"datetime","pluginOptions":{"i18n":{"localized":true}}},"investment_terms":{"type":"component","component":"project.investment-terms","min":1,"repeatable":true,"required":true,"pluginOptions":{"i18n":{"localized":true}}},"seo":{"type":"component","component":"project.seo","required":false,"repeatable":false,"pluginOptions":{"i18n":{"localized":true}}},"previous_":{"private":true,"type":"json","pluginOptions":{"i18n":{"localized":true}}},"author_":{"private":true,"type":"json","pluginOptions":{"i18n":{"localized":true}}},"slug":{"pluginOptions":{"i18n":{"localized":true}},"type":"uid","targetField":"name"},"category":{"model":"category","via":"projects"},"remarks":{"collection":"remark","via":"project","isVirtual":true},"users_permissions_user":{"via":"projects","plugin":"users-permissions","model":"user"},"localizations":{"writable":true,"private":false,"configurable":false,"visible":false,"collection":"project","populate":["id","locale","published_at"],"attribute":"related_project","column":"id","isVirtual":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"published_at":{"type":"datetime","configurable":false,"writable":true,"visible":false},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(127,'plugin_content_manager_configuration_components::project.investment-terms','{"uid":"project.investment-terms","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"item","defaultSortBy":"item","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"item":{"edit":{"label":"Item","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Item","searchable":true,"sortable":true}},"detail":{"edit":{"label":"Detail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Detail","searchable":true,"sortable":true}}},"layouts":{"list":["id","item","detail"],"edit":[[{"name":"item","size":6},{"name":"detail","size":6}]],"editRelations":[]},"isComponent":true}','object','','');
INSERT INTO "core_store" VALUES(128,'plugin_content_manager_configuration_components::project.meta','{"uid":"project.meta","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"content":{"edit":{"label":"Content","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Content","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","content"],"edit":[[{"name":"name","size":6},{"name":"content","size":6}]],"editRelations":[]},"isComponent":true}','object','','');
INSERT INTO "core_store" VALUES(129,'plugin_content_manager_configuration_components::project.seo','{"uid":"project.seo","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":false,"sortable":false}},"title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"meta":{"edit":{"label":"Meta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Meta","searchable":false,"sortable":false}}},"layouts":{"list":["id","title","description"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"meta","size":12}]],"editRelations":[]},"isComponent":true}','object','','');
INSERT INTO "core_store" VALUES(132,'plugin_content_manager_configuration_content_types::application::project.project','{"uid":"application::project.project","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"cover":{"edit":{"label":"Cover","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Cover","searchable":false,"sortable":false}},"name":{"edit":{"label":"Name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Name","searchable":true,"sortable":true}},"description":{"edit":{"label":"Description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Description","searchable":true,"sortable":true}},"address":{"edit":{"label":"Address","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Address","searchable":true,"sortable":true}},"website":{"edit":{"label":"Website","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Website","searchable":true,"sortable":true}},"phone":{"edit":{"label":"Phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Phone","searchable":true,"sortable":true}},"amount":{"edit":{"label":"Amount","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Amount","searchable":true,"sortable":true}},"location":{"edit":{"label":"Location","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Location","searchable":true,"sortable":true}},"publish_at":{"edit":{"label":"Publish_at","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Publish_at","searchable":true,"sortable":true}},"investment_terms":{"edit":{"label":"Investment_terms","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Investment_terms","searchable":false,"sortable":false}},"seo":{"edit":{"label":"Seo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Seo","searchable":false,"sortable":false}},"previous_":{"edit":{"label":"Previous_","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Previous_","searchable":false,"sortable":false}},"author_":{"edit":{"label":"Author_","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Author_","searchable":false,"sortable":false}},"slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"category":{"edit":{"label":"Category","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Category","searchable":false,"sortable":false}},"remarks":{"edit":{"label":"Remarks","description":"","placeholder":"","visible":true,"editable":true,"mainField":"phone"},"list":{"label":"Remarks","searchable":false,"sortable":false}},"users_permissions_user":{"edit":{"label":"Users_permissions_user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users_permissions_user","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","cover","name","publish_at","category"],"edit":[[{"name":"cover","size":6},{"name":"name","size":6}],[{"name":"description","size":6},{"name":"address","size":6}],[{"name":"website","size":6},{"name":"phone","size":6}],[{"name":"amount","size":6},{"name":"location","size":6}],[{"name":"investment_terms","size":12}],[{"name":"seo","size":12}],[{"name":"publish_at","size":6},{"name":"slug","size":6}]],"editRelations":["category","remarks","users_permissions_user"]}}','object','','');
INSERT INTO "core_store" VALUES(133,'model_def_application::remark.remark','{"uid":"application::remark.remark","collectionName":"remarks","kind":"collectionType","info":{"name":"remark","description":""},"options":{"increments":true,"timestamps":["created_at","updated_at"],"draftAndPublish":true},"pluginOptions":{},"attributes":{"project":{"via":"remarks","model":"project"},"users_permissions_user":{"via":"remarks","plugin":"users-permissions","model":"user"},"phone":{"type":"string"},"amount":{"type":"text"},"time":{"type":"string"},"published_at":{"type":"datetime","configurable":false,"writable":true,"visible":false},"created_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true},"updated_by":{"model":"user","plugin":"admin","configurable":false,"writable":false,"visible":false,"private":true}}}','object',NULL,NULL);
INSERT INTO "core_store" VALUES(134,'plugin_content_manager_configuration_content_types::application::remark.remark','{"uid":"application::remark.remark","settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"phone","defaultSortBy":"phone","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"Id","searchable":true,"sortable":true}},"project":{"edit":{"label":"Project","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"Project","searchable":true,"sortable":true}},"users_permissions_user":{"edit":{"label":"Users_permissions_user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"Users_permissions_user","searchable":true,"sortable":true}},"phone":{"edit":{"label":"Phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Phone","searchable":true,"sortable":true}},"amount":{"edit":{"label":"Amount","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Amount","searchable":true,"sortable":true}},"time":{"edit":{"label":"Time","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Time","searchable":true,"sortable":true}},"created_at":{"edit":{"label":"Created_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Created_at","searchable":true,"sortable":true}},"updated_at":{"edit":{"label":"Updated_at","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"Updated_at","searchable":true,"sortable":true}}},"layouts":{"list":["id","created_at","updated_at","phone"],"edit":[[{"name":"phone","size":6},{"name":"amount","size":6}],[{"name":"time","size":6}]],"editRelations":["project","users_permissions_user"]}}','object','','');
CREATE TABLE `histories` (`id` integer not null primary key autoincrement, `action` varchar(255) null, `contenttype` varchar(255) null, `author` text null, `before` text null, `after` text null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "histories" VALUES(135,'create','category',NULL,'{}','{"id":23,"name":"testing","previous_":null,"author_":null,"slug":null,"created_by":null,"updated_by":null,"created_at":"2021-08-09T09:00:14.954Z","updated_at":"2021-08-09T09:00:14.954Z","projects":[]}',NULL,NULL,1628499614996,1628499614996);
CREATE TABLE `i18n_locales` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `code` varchar(255) null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "i18n_locales" VALUES(1,'English','en',NULL,NULL,1618908155047,1618908155047);
INSERT INTO "i18n_locales" VALUES(2,'French (fr)','fr',1,1,1618909740088,1618909740096);
INSERT INTO "i18n_locales" VALUES(3,'Traditional Chinese','zh-TW',1,1,1626245394004,1626245394004);
INSERT INTO "i18n_locales" VALUES(4,'Simplified Chinese','zh-CN',1,1,1626245407016,1626245407016);
CREATE TABLE `projects` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `description` text null, `address` varchar(255) null, `website` varchar(255) null, `phone` varchar(255) null, `amount` varchar(255) null, `location` varchar(255) null, `publish_at` datetime null, `previous_` text null, `author_` text null, `slug` varchar(255) null, `category` integer null, `users_permissions_user` integer null, `locale` varchar(255) null, `published_at` datetime null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "projects" VALUES(1,'Hua Liang IoT Project','The company is located in Foshan, Guangzhou, and has been operating since 2014. Granted ‘National High-tech Technology’, and received great support from Foshan government with favorable treatments on company’s operation and R&D. Its comprehensive technology integrated software & hardware development, production, sales, customer services and platform operation.','Foshan, Guangzhou, China',NULL,NULL,'HKD 20,000,000 for 10% of company shares ','_china',NULL,NULL,NULL,'iot-fund',8,NULL,'en',1626423730283,NULL,NULL,1626423730283,1626423730283);
INSERT INTO "projects" VALUES(2,'Hua Liang Educational Fund','The "Planning Outline" proposes to support the cooperation of universities in Guangdong, Hong Kong and Macao, and explore cooperation and exchanges on mutual recognition of specific course credits, implementation of more flexible exchange arrangements, and sharing of research results.



Support GBA to build an international education demonstration zone, introduce world-famous universities and featured colleges.



','Guangdong, Hong Kong and Macao',NULL,NULL,'50 million USD / project','_others',NULL,NULL,NULL,'educational-fund',4,NULL,'en',1626423754007,NULL,NULL,1626423754007,1626423754007);
INSERT INTO "projects" VALUES(3,'Hua Liang Active Equity Funds','Long/short funds are designed to maximize the upside of markets, while limiting the downside risk. We may hold undervalued stocks that the fund managers believe will rise in price, while simultaneously shorting overvalued stocks in an attempt to reduce losses. Long/short funds also use other strategies aimed at mitigating market volatility, including leverage and derivatives.','Hong Kong',NULL,NULL,'Minimum Subscription: USD 200,000



','_others',NULL,NULL,NULL,'active-equity-fund',7,NULL,'en',1626423764661,NULL,NULL,1626423764661,1626423764661);
INSERT INTO "projects" VALUES(4,'Hua Liang Japan Real Estate Fund



','Hua Liang Japan Real Estate fund (“Fund”) is an Asian managed investment fund focused on Japan hospitality industry. Our Japan property fund combines the expertise of local asset management company (Tokyo mainboard listed) and hotel operator to source the best projects.','Tourist area： Tokyo, Osaka, Kyoto, Hokkaido and suburbs



',NULL,NULL,'Minimum investment amount： HKD 10,000,000 or equivalent','_japan',NULL,NULL,NULL,'real-estate-fund',11,NULL,'en',1626423775324,NULL,NULL,1626423775324,1626423775324);
INSERT INTO "projects" VALUES(5,'Hua Liang Natural Gas Project','The company produces environmentally-friendly air-conditioning systems and other environmentally sustainable products to improve building efficiency. We use a patented and non-electric air chiller in our air conditioning design of our core product. Therefore, instead of using Freon, which is the traditionally used chiller, our system harnesses natural gas to produce an energy solution that cools the air but via a much cleaner approach.','Hunan, China',NULL,NULL,'HKD 76,000,000 ','_china',NULL,NULL,NULL,'gas-project',1,NULL,'en',1626423785765,NULL,NULL,1626423785765,1626423785765);
INSERT INTO "projects" VALUES(6,'Hua Liang Solar Project','The company provides solar products and solutions to customer from different countries and regions.','Shanghai, China',NULL,NULL,'HKD 250,000,000 for 5% of company shares','_china',NULL,NULL,NULL,'solar-project',1,NULL,'en',1626423795535,NULL,NULL,1626423795535,1626423795535);
INSERT INTO "projects" VALUES(7,'Hua Liang Wind Project','The company is focusing on renewable energy and environmental protection. We are devoted to fostering energy transformation in order to provide everyone with cheap, dependable, and sustainable energy and to propel a green future. We sepcialize in wind power, the internet of energy, and environmental protection.','Beijing, China',NULL,NULL,'HKD 400,000,000 for 10% of company shares','_china',NULL,NULL,NULL,'wind-project',1,NULL,'en',1626423805069,NULL,NULL,1626423805069,1626423805069);
CREATE TABLE projects__localizations (



    id                    INTEGER NOT NULL



                                  PRIMARY KEY AUTOINCREMENT,



    project_id         INTEGER,



    related_project_id INTEGER



);
CREATE TABLE projects_components (



    id             INTEGER       NOT NULL



                                 PRIMARY KEY AUTOINCREMENT,



    field          VARCHAR (255) NOT NULL,



    [order]        INTEGER       NOT NULL,



    component_type VARCHAR (255) NOT NULL,



    component_id   INTEGER       NOT NULL,



    project_id     INTEGER       NOT NULL,



    FOREIGN KEY (



        project_id



    )



    REFERENCES "tmp_projects" (id) ON DELETE CASCADE,



    FOREIGN KEY (



        component_id



    )



    REFERENCES components_investment_terms (id) ON DELETE CASCADE



);
INSERT INTO "projects_components" VALUES(73,'investment_terms',6,'components_investment_terms',47,1);
INSERT INTO "projects_components" VALUES(74,'investment_terms',5,'components_investment_terms',1,1);
INSERT INTO "projects_components" VALUES(75,'investment_terms',4,'components_investment_terms',2,1);
INSERT INTO "projects_components" VALUES(76,'investment_terms',3,'components_investment_terms',3,1);
INSERT INTO "projects_components" VALUES(77,'investment_terms',2,'components_investment_terms',4,1);
INSERT INTO "projects_components" VALUES(78,'investment_terms',1,'components_investment_terms',5,1);
INSERT INTO "projects_components" VALUES(79,'investment_terms',1,'components_investment_terms',43,4);
INSERT INTO "projects_components" VALUES(80,'investment_terms',11,'components_investment_terms',13,3);
INSERT INTO "projects_components" VALUES(81,'investment_terms',10,'components_investment_terms',14,3);
INSERT INTO "projects_components" VALUES(82,'investment_terms',9,'components_investment_terms',15,3);
INSERT INTO "projects_components" VALUES(83,'investment_terms',8,'components_investment_terms',16,3);
INSERT INTO "projects_components" VALUES(84,'investment_terms',7,'components_investment_terms',17,3);
INSERT INTO "projects_components" VALUES(85,'investment_terms',6,'components_investment_terms',18,3);
INSERT INTO "projects_components" VALUES(86,'investment_terms',5,'components_investment_terms',19,3);
INSERT INTO "projects_components" VALUES(87,'investment_terms',4,'components_investment_terms',20,3);
INSERT INTO "projects_components" VALUES(88,'investment_terms',3,'components_investment_terms',21,3);
INSERT INTO "projects_components" VALUES(89,'investment_terms',2,'components_investment_terms',22,3);
INSERT INTO "projects_components" VALUES(90,'investment_terms',1,'components_investment_terms',23,3);
INSERT INTO "projects_components" VALUES(91,'investment_terms',7,'components_investment_terms',6,2);
INSERT INTO "projects_components" VALUES(92,'investment_terms',6,'components_investment_terms',7,2);
INSERT INTO "projects_components" VALUES(93,'investment_terms',5,'components_investment_terms',8,2);
INSERT INTO "projects_components" VALUES(94,'investment_terms',4,'components_investment_terms',9,2);
INSERT INTO "projects_components" VALUES(95,'investment_terms',3,'components_investment_terms',10,2);
INSERT INTO "projects_components" VALUES(96,'investment_terms',2,'components_investment_terms',11,2);
INSERT INTO "projects_components" VALUES(97,'investment_terms',1,'components_investment_terms',12,2);
INSERT INTO "projects_components" VALUES(98,'investment_terms',20,'components_investment_terms',25,4);
INSERT INTO "projects_components" VALUES(99,'investment_terms',19,'components_investment_terms',26,4);
INSERT INTO "projects_components" VALUES(100,'investment_terms',18,'components_investment_terms',27,4);
INSERT INTO "projects_components" VALUES(101,'investment_terms',17,'components_investment_terms',28,4);
INSERT INTO "projects_components" VALUES(102,'investment_terms',16,'components_investment_terms',29,4);
INSERT INTO "projects_components" VALUES(103,'investment_terms',15,'components_investment_terms',30,4);
INSERT INTO "projects_components" VALUES(104,'investment_terms',14,'components_investment_terms',31,4);
INSERT INTO "projects_components" VALUES(105,'investment_terms',13,'components_investment_terms',32,4);
INSERT INTO "projects_components" VALUES(106,'investment_terms',12,'components_investment_terms',33,4);
INSERT INTO "projects_components" VALUES(107,'investment_terms',11,'components_investment_terms',34,4);
INSERT INTO "projects_components" VALUES(108,'investment_terms',10,'components_investment_terms',35,4);
INSERT INTO "projects_components" VALUES(109,'investment_terms',9,'components_investment_terms',36,4);
INSERT INTO "projects_components" VALUES(110,'investment_terms',8,'components_investment_terms',37,4);
INSERT INTO "projects_components" VALUES(111,'investment_terms',7,'components_investment_terms',38,4);
INSERT INTO "projects_components" VALUES(112,'investment_terms',6,'components_investment_terms',39,4);
INSERT INTO "projects_components" VALUES(113,'investment_terms',4,'components_investment_terms',40,4);
INSERT INTO "projects_components" VALUES(114,'investment_terms',3,'components_investment_terms',41,4);
INSERT INTO "projects_components" VALUES(115,'investment_terms',2,'components_investment_terms',42,4);
INSERT INTO "projects_components" VALUES(116,'investment_terms',9,'components_investment_terms',48,5);
INSERT INTO "projects_components" VALUES(117,'investment_terms',8,'components_investment_terms',49,5);
INSERT INTO "projects_components" VALUES(118,'investment_terms',7,'components_investment_terms',50,5);
INSERT INTO "projects_components" VALUES(119,'investment_terms',6,'components_investment_terms',51,5);
INSERT INTO "projects_components" VALUES(120,'investment_terms',5,'components_investment_terms',52,5);
INSERT INTO "projects_components" VALUES(121,'investment_terms',4,'components_investment_terms',53,5);
INSERT INTO "projects_components" VALUES(122,'investment_terms',3,'components_investment_terms',54,5);
INSERT INTO "projects_components" VALUES(123,'investment_terms',2,'components_investment_terms',55,5);
INSERT INTO "projects_components" VALUES(124,'investment_terms',1,'components_investment_terms',56,5);
INSERT INTO "projects_components" VALUES(125,'investment_terms',8,'components_investment_terms',57,6);
INSERT INTO "projects_components" VALUES(126,'investment_terms',7,'components_investment_terms',58,6);
INSERT INTO "projects_components" VALUES(127,'investment_terms',6,'components_investment_terms',59,6);
INSERT INTO "projects_components" VALUES(128,'investment_terms',5,'components_investment_terms',60,6);
INSERT INTO "projects_components" VALUES(129,'investment_terms',4,'components_investment_terms',61,6);
INSERT INTO "projects_components" VALUES(130,'investment_terms',3,'components_investment_terms',62,6);
INSERT INTO "projects_components" VALUES(131,'investment_terms',2,'components_investment_terms',63,6);
INSERT INTO "projects_components" VALUES(132,'investment_terms',1,'components_investment_terms',64,6);
INSERT INTO "projects_components" VALUES(133,'investment_terms',3,'components_investment_terms',70,7);
INSERT INTO "projects_components" VALUES(134,'investment_terms',8,'components_investment_terms',65,7);
INSERT INTO "projects_components" VALUES(135,'investment_terms',7,'components_investment_terms',66,7);
INSERT INTO "projects_components" VALUES(136,'investment_terms',6,'components_investment_terms',67,7);
INSERT INTO "projects_components" VALUES(137,'investment_terms',5,'components_investment_terms',68,7);
INSERT INTO "projects_components" VALUES(138,'investment_terms',4,'components_investment_terms',69,7);
INSERT INTO "projects_components" VALUES(139,'investment_terms',2,'components_investment_terms',71,7);
INSERT INTO "projects_components" VALUES(140,'investment_terms',1,'components_investment_terms',72,7);
CREATE TABLE `remarks` (`id` integer not null primary key autoincrement, `project` integer null, `users_permissions_user` integer null, `phone` varchar(255) null, `amount` text null, `time` varchar(255) null, `published_at` datetime null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "remarks" VALUES(1,1,2,'63389945','HKD 20,000,000 for 15% of company shares','2 p.m. to 3 p.m on Wednesday',1628734722262,1,1,1628734711390,1628734722316);
INSERT INTO "remarks" VALUES(2,1,1,'54988336','HKD 20,000,000 for 10% of company shares','on Thursday',1628735979140,NULL,NULL,1628735979150,1628735979177);
INSERT INTO "remarks" VALUES(3,1,1,'54988336','HKD 20,000,000 for 10% of company shares','on Thursday',1628736001733,NULL,NULL,1628736001737,1628736001751);
INSERT INTO "remarks" VALUES(4,1,1,'54988336','HKD 20,000,000 for 10% of company shares','on Thursday',1628736082889,NULL,NULL,1628736082893,1628736082909);
INSERT INTO "remarks" VALUES(5,1,1,'54988336','899798','2 p.m. to 3 p.m on Wednesday',1628736308571,NULL,NULL,1628736308575,1628736308592);
INSERT INTO "remarks" VALUES(6,1,1,'85254988336','899798','2 p.m. to 3 p.m on Wednesday',1628736539994,NULL,NULL,1628736539997,1628736540016);
INSERT INTO "remarks" VALUES(7,1,1,'54988336','899798','2 p.m. to 3 p.m on Wednesday',1628737082926,NULL,NULL,1628737082930,1628737082938);
INSERT INTO "remarks" VALUES(8,1,1,'54988336','899798','2 p.m. to 3 p.m on Wednesday',1628737135544,NULL,NULL,1628737135547,1628737135562);
INSERT INTO "remarks" VALUES(9,2,1,'54988336','899798','2 p.m. to 3 p.m on Wednesday',1628737202653,NULL,NULL,1628737202659,1628737202675);
INSERT INTO "remarks" VALUES(10,2,1,'54988336','899798','2 p.m. to 3 p.m on Wednesday',1628737279259,NULL,NULL,1628737279262,1628737279280);
INSERT INTO "remarks" VALUES(11,2,1,'549883361111111','11111111111111111111','1111111111111111111111111',1628737454020,NULL,NULL,1628737454024,1628737454035);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('components_seo',1);
INSERT INTO "sqlite_sequence" VALUES('core_store',134);
INSERT INTO "sqlite_sequence" VALUES('strapi_role',3);
INSERT INTO "sqlite_sequence" VALUES('strapi_users_roles',2);
INSERT INTO "sqlite_sequence" VALUES('upload_file_morph',529);
INSERT INTO "sqlite_sequence" VALUES('histories',135);
INSERT INTO "sqlite_sequence" VALUES('strapi_permission',2869);
INSERT INTO "sqlite_sequence" VALUES('upload_file',245);
INSERT INTO "sqlite_sequence" VALUES('users-permissions_permission',725);
INSERT INTO "sqlite_sequence" VALUES('users-permissions_role',3);
INSERT INTO "sqlite_sequence" VALUES('i18n_locales',4);
INSERT INTO "sqlite_sequence" VALUES('projects__localizations',56);
INSERT INTO "sqlite_sequence" VALUES('categories',23);
INSERT INTO "sqlite_sequence" VALUES('components_investment_terms',72);
INSERT INTO "sqlite_sequence" VALUES('projects_components',140);
INSERT INTO "sqlite_sequence" VALUES('strapi_administrator',2);
INSERT INTO "sqlite_sequence" VALUES('remarks',11);
INSERT INTO "sqlite_sequence" VALUES('projects',7);
INSERT INTO "sqlite_sequence" VALUES('users-permissions_user',103);
CREATE TABLE `strapi_administrator` (`id` integer not null primary key autoincrement, `firstname` varchar(255) null, `lastname` varchar(255) null, `username` varchar(255) null, `email` varchar(255) not null, `password` varchar(255) null, `resetPasswordToken` varchar(255) null, `registrationToken` varchar(255) null, `isActive` boolean null, `blocked` boolean null, `preferedLanguage` varchar(255) null);
INSERT INTO "strapi_administrator" VALUES(2,'Hualiang','Dev',NULL,'hualiang.dev@gmail.com','$2a$10$0yyEIjHsk7aFm1CX6VdLfenDSsueLhm78WyfsKBPF2t9akt1LFLB.',NULL,NULL,1,NULL,NULL);
CREATE TABLE `strapi_permission` (`id` integer not null primary key autoincrement, `action` varchar(255) not null, `subject` varchar(255) null, `properties` text null, `conditions` text null, `role` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "strapi_permission" VALUES(101,'plugins::content-manager.explorer.create','application::history.history','{"fields":["action","contenttype","author","before","after"]}','[]',1,1600090377212,1618908153876);
INSERT INTO "strapi_permission" VALUES(104,'plugins::content-manager.explorer.read','application::history.history','{"fields":["action","contenttype","author","before","after"]}','[]',1,1600090377250,1618908153882);
INSERT INTO "strapi_permission" VALUES(107,'plugins::content-manager.explorer.update','application::history.history','{"fields":["action","contenttype","author","before","after"]}','[]',1,1600090377290,1618908153889);
INSERT INTO "strapi_permission" VALUES(165,'plugins::content-type-builder.read',NULL,'{}','[]',1,1618908157402,1618908157407);
INSERT INTO "strapi_permission" VALUES(166,'plugins::email.settings.read',NULL,'{}','[]',1,1618908157417,1618908157424);
INSERT INTO "strapi_permission" VALUES(167,'plugins::documentation.read',NULL,'{}','[]',1,1618908157432,1618908157437);
INSERT INTO "strapi_permission" VALUES(168,'plugins::documentation.settings.update',NULL,'{}','[]',1,1618908157445,1618908157450);
INSERT INTO "strapi_permission" VALUES(169,'plugins::documentation.settings.regenerate',NULL,'{}','[]',1,1618908157460,1618908157466);
INSERT INTO "strapi_permission" VALUES(170,'plugins::upload.read',NULL,'{}','[]',1,1618908157476,1618908157484);
INSERT INTO "strapi_permission" VALUES(171,'plugins::upload.assets.create',NULL,'{}','[]',1,1618908157493,1618908157498);
INSERT INTO "strapi_permission" VALUES(172,'plugins::upload.assets.update',NULL,'{}','[]',1,1618908157511,1618908157516);
INSERT INTO "strapi_permission" VALUES(173,'plugins::upload.assets.download',NULL,'{}','[]',1,1618908157525,1618908157529);
INSERT INTO "strapi_permission" VALUES(174,'plugins::upload.assets.copy-link',NULL,'{}','[]',1,1618908157538,1618908157543);
INSERT INTO "strapi_permission" VALUES(175,'plugins::upload.settings.read',NULL,'{}','[]',1,1618908157551,1618908157555);
INSERT INTO "strapi_permission" VALUES(176,'plugins::i18n.locale.create',NULL,'{}','[]',1,1618908157566,1618908157630);
INSERT INTO "strapi_permission" VALUES(177,'plugins::i18n.locale.read',NULL,'{}','[]',1,1618908157647,1618908157654);
INSERT INTO "strapi_permission" VALUES(178,'plugins::i18n.locale.update',NULL,'{}','[]',1,1618908157667,1618908157671);
INSERT INTO "strapi_permission" VALUES(179,'plugins::i18n.locale.delete',NULL,'{}','[]',1,1618908157720,1618908157726);
INSERT INTO "strapi_permission" VALUES(180,'plugins::users-permissions.roles.create',NULL,'{}','[]',1,1618908157735,1618908157740);
INSERT INTO "strapi_permission" VALUES(181,'plugins::users-permissions.roles.read',NULL,'{}','[]',1,1618908157751,1618908157757);
INSERT INTO "strapi_permission" VALUES(182,'plugins::users-permissions.roles.update',NULL,'{}','[]',1,1618908157766,1618908157771);
INSERT INTO "strapi_permission" VALUES(183,'plugins::users-permissions.roles.delete',NULL,'{}','[]',1,1618908157780,1618908157785);
INSERT INTO "strapi_permission" VALUES(184,'plugins::users-permissions.providers.read',NULL,'{}','[]',1,1618908157794,1618908157813);
INSERT INTO "strapi_permission" VALUES(185,'plugins::users-permissions.providers.update',NULL,'{}','[]',1,1618908157828,1618908157835);
INSERT INTO "strapi_permission" VALUES(186,'plugins::users-permissions.email-templates.read',NULL,'{}','[]',1,1618908157845,1618908157850);
INSERT INTO "strapi_permission" VALUES(187,'plugins::users-permissions.email-templates.update',NULL,'{}','[]',1,1618908157859,1618908157864);
INSERT INTO "strapi_permission" VALUES(188,'plugins::users-permissions.advanced-settings.read',NULL,'{}','[]',1,1618908157874,1618908157879);
INSERT INTO "strapi_permission" VALUES(189,'plugins::users-permissions.advanced-settings.update',NULL,'{}','[]',1,1618908157892,1618908157898);
INSERT INTO "strapi_permission" VALUES(190,'plugins::content-manager.single-types.configure-view',NULL,'{}','[]',1,1618908157910,1618908157916);
INSERT INTO "strapi_permission" VALUES(191,'plugins::content-manager.collection-types.configure-view',NULL,'{}','[]',1,1618908157931,1618908157937);
INSERT INTO "strapi_permission" VALUES(192,'plugins::content-manager.components.configure-layout',NULL,'{}','[]',1,1618908157946,1618908157951);
INSERT INTO "strapi_permission" VALUES(193,'admin::marketplace.read',NULL,'{}','[]',1,1618908157961,1618908157967);
INSERT INTO "strapi_permission" VALUES(194,'admin::marketplace.plugins.install',NULL,'{}','[]',1,1618908157976,1618908157981);
INSERT INTO "strapi_permission" VALUES(195,'admin::marketplace.plugins.uninstall',NULL,'{}','[]',1,1618908157993,1618908157999);
INSERT INTO "strapi_permission" VALUES(196,'admin::webhooks.create',NULL,'{}','[]',1,1618908158012,1618908158018);
INSERT INTO "strapi_permission" VALUES(197,'admin::webhooks.read',NULL,'{}','[]',1,1618908158028,1618908158034);
INSERT INTO "strapi_permission" VALUES(198,'admin::webhooks.update',NULL,'{}','[]',1,1618908158043,1618908158049);
INSERT INTO "strapi_permission" VALUES(199,'admin::webhooks.delete',NULL,'{}','[]',1,1618908158060,1618908158067);
INSERT INTO "strapi_permission" VALUES(200,'admin::users.create',NULL,'{}','[]',1,1618908158079,1618908158084);
INSERT INTO "strapi_permission" VALUES(201,'admin::users.read',NULL,'{}','[]',1,1618908158093,1618908158101);
INSERT INTO "strapi_permission" VALUES(202,'admin::users.update',NULL,'{}','[]',1,1618908158112,1618908158118);
INSERT INTO "strapi_permission" VALUES(203,'admin::users.delete',NULL,'{}','[]',1,1618908158130,1618908158142);
INSERT INTO "strapi_permission" VALUES(204,'admin::roles.create',NULL,'{}','[]',1,1618908158155,1618908158160);
INSERT INTO "strapi_permission" VALUES(205,'admin::roles.read',NULL,'{}','[]',1,1618908158172,1618908158178);
INSERT INTO "strapi_permission" VALUES(206,'admin::roles.update',NULL,'{}','[]',1,1618908158188,1618908158202);
INSERT INTO "strapi_permission" VALUES(207,'admin::roles.delete',NULL,'{}','[]',1,1618908158216,1618908158226);
INSERT INTO "strapi_permission" VALUES(247,'plugins::content-manager.explorer.create','application::category.category','{"fields":["name","projects","previous_","author_","slug"]}','[]',1,1618919205602,1618919205609);
INSERT INTO "strapi_permission" VALUES(248,'plugins::content-manager.explorer.read','application::category.category','{"fields":["name","projects","previous_","author_","slug"]}','[]',1,1618919205621,1618919205628);
INSERT INTO "strapi_permission" VALUES(249,'plugins::content-manager.explorer.update','application::category.category','{"fields":["name","projects","previous_","author_","slug"]}','[]',1,1618919205638,1618919205643);
INSERT INTO "strapi_permission" VALUES(2575,'plugins::upload.read',NULL,'{}','[]',2,1628587117621,1628587117632);
INSERT INTO "strapi_permission" VALUES(2576,'plugins::upload.assets.create',NULL,'{}','[]',2,1628587117649,1628587117659);
INSERT INTO "strapi_permission" VALUES(2577,'plugins::upload.assets.update',NULL,'{}','[]',2,1628587117677,1628587117686);
INSERT INTO "strapi_permission" VALUES(2578,'plugins::upload.assets.download',NULL,'{}','[]',2,1628587117702,1628587117713);
INSERT INTO "strapi_permission" VALUES(2579,'plugins::upload.assets.copy-link',NULL,'{}','[]',2,1628587117729,1628587117740);
INSERT INTO "strapi_permission" VALUES(2580,'plugins::content-manager.explorer.create','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','[]',2,1628587117760,1628587117777);
INSERT INTO "strapi_permission" VALUES(2581,'plugins::content-manager.explorer.read','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','[]',2,1628587117798,1628587117816);
INSERT INTO "strapi_permission" VALUES(2582,'plugins::content-manager.explorer.update','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','[]',2,1628587117838,1628587117855);
INSERT INTO "strapi_permission" VALUES(2583,'plugins::content-manager.explorer.delete','application::category.category','{}','[]',2,1628587117873,1628587117883);
INSERT INTO "strapi_permission" VALUES(2588,'plugins::content-manager.explorer.create','application::history.history','{"fields":["action","after","author","before","contenttype"]}','[]',2,1628587118017,1628587118027);
INSERT INTO "strapi_permission" VALUES(2589,'plugins::content-manager.explorer.read','application::history.history','{"fields":["action","after","author","before","contenttype"]}','[]',2,1628587118043,1628587118053);
INSERT INTO "strapi_permission" VALUES(2590,'plugins::content-manager.explorer.update','application::history.history','{"fields":["action","after","author","before","contenttype"]}','[]',2,1628587118071,1628587118082);
INSERT INTO "strapi_permission" VALUES(2591,'plugins::content-manager.explorer.delete','application::history.history','{}','[]',2,1628587118099,1628587118109);
INSERT INTO "strapi_permission" VALUES(2593,'plugins::content-manager.explorer.create','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',2,1628587118151,1629945693875);
INSERT INTO "strapi_permission" VALUES(2594,'plugins::content-manager.explorer.read','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',2,1628587118178,1629945693905);
INSERT INTO "strapi_permission" VALUES(2595,'plugins::content-manager.explorer.update','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',2,1628587118204,1629945693942);
INSERT INTO "strapi_permission" VALUES(2596,'plugins::content-manager.explorer.delete','application::project.project','{"locales":["en","fr","zh-TW","zh-CN"]}','[]',2,1628587118234,1628587118249);
INSERT INTO "strapi_permission" VALUES(2597,'plugins::content-manager.explorer.publish','application::project.project','{"locales":["en","fr","zh-TW","zh-CN"]}','[]',2,1628587118265,1628587118275);
INSERT INTO "strapi_permission" VALUES(2598,'plugins::content-manager.explorer.create','application::remark.remark','{"fields":["project","users_permissions_user"]}','[]',2,1628587118291,1628734516962);
INSERT INTO "strapi_permission" VALUES(2599,'plugins::content-manager.explorer.read','application::remark.remark','{"fields":["project","users_permissions_user"]}','[]',2,1628587118316,1628734516996);
INSERT INTO "strapi_permission" VALUES(2600,'plugins::content-manager.explorer.update','application::remark.remark','{"fields":["project","users_permissions_user"]}','[]',2,1628587118346,1628734517030);
INSERT INTO "strapi_permission" VALUES(2601,'plugins::content-manager.explorer.delete','application::remark.remark','{}','[]',2,1628587118382,1628587118392);
INSERT INTO "strapi_permission" VALUES(2602,'plugins::content-manager.explorer.publish','application::remark.remark','{}','[]',2,1628587118408,1628587118418);
INSERT INTO "strapi_permission" VALUES(2608,'plugins::content-manager.explorer.create','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','[]',2,1628587118575,1629945727857);
INSERT INTO "strapi_permission" VALUES(2609,'plugins::content-manager.explorer.read','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','[]',2,1628587118601,1629945727884);
INSERT INTO "strapi_permission" VALUES(2610,'plugins::content-manager.explorer.update','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','[]',2,1628587118629,1629945727913);
INSERT INTO "strapi_permission" VALUES(2611,'plugins::content-manager.explorer.delete','plugins::users-permissions.user','{}','[]',2,1628587118659,1628587118677);
INSERT INTO "strapi_permission" VALUES(2612,'plugins::upload.read',NULL,'{}','["admin::is-creator"]',3,1628587156735,1628587156746);
INSERT INTO "strapi_permission" VALUES(2613,'plugins::upload.assets.create',NULL,'{}','[]',3,1628587156763,1628587156773);
INSERT INTO "strapi_permission" VALUES(2614,'plugins::upload.assets.update',NULL,'{}','["admin::is-creator"]',3,1628587156790,1628587156800);
INSERT INTO "strapi_permission" VALUES(2615,'plugins::upload.assets.download',NULL,'{}','[]',3,1628587156817,1628587156827);
INSERT INTO "strapi_permission" VALUES(2616,'plugins::upload.assets.copy-link',NULL,'{}','[]',3,1628587156847,1628587156863);
INSERT INTO "strapi_permission" VALUES(2617,'plugins::content-manager.explorer.create','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','["admin::is-creator"]',3,1628587156881,1628587156891);
INSERT INTO "strapi_permission" VALUES(2618,'plugins::content-manager.explorer.read','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','["admin::is-creator"]',3,1628587156908,1628587156918);
INSERT INTO "strapi_permission" VALUES(2619,'plugins::content-manager.explorer.update','application::category.category','{"fields":["author_","name","previous_","projects","slug"]}','["admin::is-creator"]',3,1628587156935,1628587156945);
INSERT INTO "strapi_permission" VALUES(2620,'plugins::content-manager.explorer.delete','application::category.category','{}','["admin::is-creator"]',3,1628587156962,1628587156972);
INSERT INTO "strapi_permission" VALUES(2625,'plugins::content-manager.explorer.create','application::history.history','{"fields":["action","after","author","before","contenttype"]}','["admin::is-creator"]',3,1628587157112,1628587157121);
INSERT INTO "strapi_permission" VALUES(2626,'plugins::content-manager.explorer.read','application::history.history','{"fields":["action","after","author","before","contenttype"]}','["admin::is-creator"]',3,1628587157138,1628587157148);
INSERT INTO "strapi_permission" VALUES(2627,'plugins::content-manager.explorer.update','application::history.history','{"fields":["action","after","author","before","contenttype"]}','["admin::is-creator"]',3,1628587157164,1628587157174);
INSERT INTO "strapi_permission" VALUES(2628,'plugins::content-manager.explorer.delete','application::history.history','{}','["admin::is-creator"]',3,1628587157191,1628587157202);
INSERT INTO "strapi_permission" VALUES(2633,'plugins::content-manager.explorer.create','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','["admin::is-creator"]',3,1628587157330,1629945694163);
INSERT INTO "strapi_permission" VALUES(2634,'plugins::content-manager.explorer.read','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','["admin::is-creator"]',3,1628587157366,1629945694193);
INSERT INTO "strapi_permission" VALUES(2635,'plugins::content-manager.explorer.update','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks"],"locales":["en","fr","zh-TW","zh-CN"]}','["admin::is-creator"]',3,1628587157398,1629945694223);
INSERT INTO "strapi_permission" VALUES(2636,'plugins::content-manager.explorer.delete','application::project.project','{"locales":["en","fr","zh-TW","zh-CN"]}','["admin::is-creator"]',3,1628587157424,1628587157434);
INSERT INTO "strapi_permission" VALUES(2637,'plugins::content-manager.explorer.create','application::remark.remark','{"fields":["project","users_permissions_user"]}','["admin::is-creator"]',3,1628587157451,1628734517064);
INSERT INTO "strapi_permission" VALUES(2638,'plugins::content-manager.explorer.read','application::remark.remark','{"fields":["project","users_permissions_user"]}','["admin::is-creator"]',3,1628587157477,1628734517097);
INSERT INTO "strapi_permission" VALUES(2639,'plugins::content-manager.explorer.update','application::remark.remark','{"fields":["project","users_permissions_user"]}','["admin::is-creator"]',3,1628587157504,1628734517131);
INSERT INTO "strapi_permission" VALUES(2640,'plugins::content-manager.explorer.delete','application::remark.remark','{}','["admin::is-creator"]',3,1628587157530,1628587157539);
INSERT INTO "strapi_permission" VALUES(2645,'plugins::content-manager.explorer.create','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','["admin::is-creator"]',3,1628587157677,1629945727950);
INSERT INTO "strapi_permission" VALUES(2646,'plugins::content-manager.explorer.read','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','["admin::is-creator"]',3,1628587157707,1629945727979);
INSERT INTO "strapi_permission" VALUES(2647,'plugins::content-manager.explorer.update','plugins::users-permissions.user','{"fields":["username","email","picture","remarks"]}','["admin::is-creator"]',3,1628587157742,1629945728008);
INSERT INTO "strapi_permission" VALUES(2648,'plugins::content-manager.explorer.delete','plugins::users-permissions.user','{}','["admin::is-creator"]',3,1628587157769,1628587157779);
INSERT INTO "strapi_permission" VALUES(2692,'plugins::content-manager.explorer.create','application::remark.remark','{"fields":["project","users_permissions_user","phone","amount","time"]}','[]',1,1628734516354,1628734516369);
INSERT INTO "strapi_permission" VALUES(2693,'plugins::content-manager.explorer.read','application::remark.remark','{"fields":["project","users_permissions_user","phone","amount","time"]}','[]',1,1628734516384,1628734516396);
INSERT INTO "strapi_permission" VALUES(2694,'plugins::content-manager.explorer.update','application::remark.remark','{"fields":["project","users_permissions_user","phone","amount","time"]}','[]',1,1628734516412,1628734516425);
INSERT INTO "strapi_permission" VALUES(2850,'plugins::content-manager.explorer.create','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks","users_permissions_user"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',1,1630035540218,1630035540228);
INSERT INTO "strapi_permission" VALUES(2851,'plugins::content-manager.explorer.create','plugins::users-permissions.user','{"fields":["username","email","provider","password","resetPasswordToken","confirmed","blocked","role","picture","remarks","projects"]}','[]',1,1630035540246,1630035540256);
INSERT INTO "strapi_permission" VALUES(2852,'plugins::content-manager.explorer.read','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks","users_permissions_user"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',1,1630035540273,1630035540282);
INSERT INTO "strapi_permission" VALUES(2853,'plugins::content-manager.explorer.read','plugins::users-permissions.user','{"fields":["username","email","provider","password","resetPasswordToken","confirmed","blocked","role","picture","remarks","projects"]}','[]',1,1630035540299,1630035540308);
INSERT INTO "strapi_permission" VALUES(2854,'plugins::content-manager.explorer.update','application::project.project','{"fields":["cover","name","description","address","website","phone","amount","location","publish_at","investment_terms.item","investment_terms.detail","seo.title","seo.description","seo.meta.name","seo.meta.content","previous_","author_","slug","category","remarks","users_permissions_user"],"locales":["en","fr","zh-TW","zh-CN"]}','[]',1,1630035540324,1630035540334);
INSERT INTO "strapi_permission" VALUES(2855,'plugins::content-manager.explorer.update','plugins::users-permissions.user','{"fields":["username","email","provider","password","resetPasswordToken","confirmed","blocked","role","picture","remarks","projects"]}','[]',1,1630035540349,1630035540358);
INSERT INTO "strapi_permission" VALUES(2863,'plugins::content-manager.explorer.delete','application::category.category','{}','[]',1,1630041196954,1630041196964);
INSERT INTO "strapi_permission" VALUES(2864,'plugins::content-manager.explorer.delete','application::history.history','{}','[]',1,1630041196978,1630041196986);
INSERT INTO "strapi_permission" VALUES(2865,'plugins::content-manager.explorer.delete','application::project.project','{"locales":["en","fr","zh-TW","zh-CN"]}','[]',1,1630041197000,1630041197010);
INSERT INTO "strapi_permission" VALUES(2866,'plugins::content-manager.explorer.delete','application::remark.remark','{}','[]',1,1630041197025,1630041197034);
INSERT INTO "strapi_permission" VALUES(2867,'plugins::content-manager.explorer.delete','plugins::users-permissions.user','{}','[]',1,1630041197051,1630041197060);
INSERT INTO "strapi_permission" VALUES(2868,'plugins::content-manager.explorer.publish','application::project.project','{"locales":["en","fr","zh-TW","zh-CN"]}','[]',1,1630041197076,1630041197086);
INSERT INTO "strapi_permission" VALUES(2869,'plugins::content-manager.explorer.publish','application::remark.remark','{}','[]',1,1630041197102,1630041197110);
CREATE TABLE `strapi_role` (`id` integer not null primary key autoincrement, `name` varchar(255) not null, `code` varchar(255) not null, `description` varchar(255) null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "strapi_role" VALUES(1,'Super Admin','strapi-super-admin','Super Admins can access and manage all features and settings.',1595433593120,1595433593120);
INSERT INTO "strapi_role" VALUES(2,'Editor','strapi-editor','Editors can manage and publish contents including those of other users.',1595433593140,1595433593140);
INSERT INTO "strapi_role" VALUES(3,'Author','strapi-author','Authors can manage and publish the content they created.',1595433593157,1595433593157);
CREATE TABLE `strapi_users_roles` (`id` integer not null primary key autoincrement, `user_id` integer null, `role_id` integer null);
INSERT INTO "strapi_users_roles" VALUES(1,1,1);
INSERT INTO "strapi_users_roles" VALUES(2,2,1);
CREATE TABLE `strapi_webhooks` (`id` integer not null primary key autoincrement, `name` varchar(255) null, `url` text null, `headers` text null, `events` text null, `enabled` boolean null);
CREATE TABLE `upload_file` (`id` integer not null primary key autoincrement, `name` varchar(255) not null, `alternativeText` varchar(255) null, `caption` varchar(255) null, `width` integer null, `height` integer null, `formats` text null, `hash` varchar(255) not null, `ext` varchar(255) null, `mime` varchar(255) not null, `size` float not null, `url` varchar(255) not null, `previewUrl` varchar(255) null, `provider` varchar(255) not null, `provider_metadata` text null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "upload_file" VALUES(1,'aspic_004.jpeg',NULL,NULL,NULL,NULL,NULL,'29d5f5ef9bbc4a438cfb9a9299fd0607','.jpeg','image/jpeg',69.93,'/uploads/29d5f5ef9bbc4a438cfb9a9299fd0607.jpeg',NULL,'local',NULL,NULL,NULL,1552396322403,1552396322416);
INSERT INTO "upload_file" VALUES(2,'aspic_001.jpeg',NULL,NULL,NULL,NULL,NULL,'48f5da81ca8e460eb29591605fa6edba','.jpeg','image/jpeg',633.28,'/uploads/48f5da81ca8e460eb29591605fa6edba.jpeg',NULL,'local',NULL,NULL,NULL,1552396322404,1552396322417);
INSERT INTO "upload_file" VALUES(3,'aspic_002.jpeg',NULL,NULL,NULL,NULL,NULL,'2f600e2114994432ae78a3d05e94e133','.jpeg','image/jpeg',740.22,'/uploads/2f600e2114994432ae78a3d05e94e133.jpeg',NULL,'local',NULL,NULL,NULL,1552396322404,1552396322418);
INSERT INTO "upload_file" VALUES(4,'aspic_003.jpeg',NULL,NULL,NULL,NULL,NULL,'063efd98c5b7401f9ea00864211095ed','.jpeg','image/jpeg',142.25,'/uploads/063efd98c5b7401f9ea00864211095ed.jpeg',NULL,'local',NULL,NULL,NULL,1552396322404,1552396322418);
INSERT INTO "upload_file" VALUES(5,'canalegria_003.jpeg',NULL,NULL,NULL,NULL,NULL,'b2f1a916549e4857a2735831b98fc5c0','.jpeg','image/jpeg',290.63,'/uploads/b2f1a916549e4857a2735831b98fc5c0.jpeg',NULL,'local',NULL,NULL,NULL,1552397066261,1552397066273);
INSERT INTO "upload_file" VALUES(6,'canalegria_004.jpeg',NULL,NULL,NULL,NULL,NULL,'8591e6e5719944389f7b666ea11a66bf','.jpeg','image/jpeg',119.42,'/uploads/8591e6e5719944389f7b666ea11a66bf.jpeg',NULL,'local',NULL,NULL,NULL,1552397066261,1552397066273);
INSERT INTO "upload_file" VALUES(7,'canalegria_002.jpeg',NULL,NULL,NULL,NULL,NULL,'05db335321794210a7f2c1591df54d20','.jpeg','image/jpeg',72.31,'/uploads/05db335321794210a7f2c1591df54d20.jpeg',NULL,'local',NULL,NULL,NULL,1552397066262,1552397066274);
INSERT INTO "upload_file" VALUES(8,'canalegria_001.jpeg',NULL,NULL,NULL,NULL,NULL,'e2b7a9488e504269b0c8268ffa163225','.jpeg','image/jpeg',71.1,'/uploads/e2b7a9488e504269b0c8268ffa163225.jpeg',NULL,'local',NULL,NULL,NULL,1552397066262,1552397066275);
INSERT INTO "upload_file" VALUES(9,'signamont_001.jpeg',NULL,NULL,NULL,NULL,NULL,'2ba3387bb58f4070a0c12d3432b50dea','.jpeg','image/jpeg',142.32,'/uploads/2ba3387bb58f4070a0c12d3432b50dea.jpeg',NULL,'local',NULL,NULL,NULL,1552397250921,1552397250933);
INSERT INTO "upload_file" VALUES(10,'signamont_002.jpeg',NULL,NULL,NULL,NULL,NULL,'6d7c0d264993437b9d4232f16201d233','.jpeg','image/jpeg',67.73,'/uploads/6d7c0d264993437b9d4232f16201d233.jpeg',NULL,'local',NULL,NULL,NULL,1552397250921,1552397250934);
INSERT INTO "upload_file" VALUES(11,'signamont_003.jpeg',NULL,NULL,NULL,NULL,NULL,'8a07d783b2614621b36da01b0f906aaa','.jpeg','image/jpeg',154.25,'/uploads/8a07d783b2614621b36da01b0f906aaa.jpeg',NULL,'local',NULL,NULL,NULL,1552397250922,1552397250935);
INSERT INTO "upload_file" VALUES(12,'signamont_004.jpeg',NULL,NULL,NULL,NULL,NULL,'6729da59d5b64f3f96b1cb2c4a279f5a','.jpeg','image/jpeg',138.31,'/uploads/6729da59d5b64f3f96b1cb2c4a279f5a.jpeg',NULL,'local',NULL,NULL,NULL,1552397250922,1552397250935);
INSERT INTO "upload_file" VALUES(13,'lecalife_002.jpeg',NULL,NULL,NULL,NULL,NULL,'05b96a46ea2b4b7bb045bd8b000bedb3','.jpeg','image/jpeg',84.69,'/uploads/05b96a46ea2b4b7bb045bd8b000bedb3.jpeg',NULL,'local',NULL,NULL,NULL,1552397338169,1552397338181);
INSERT INTO "upload_file" VALUES(14,'lecalife_001.jpeg',NULL,NULL,NULL,NULL,NULL,'e705591685f34e7a9b56b794d545b5b3','.jpeg','image/jpeg',73.38,'/uploads/e705591685f34e7a9b56b794d545b5b3.jpeg',NULL,'local',NULL,NULL,NULL,1552397338170,1552397338182);
INSERT INTO "upload_file" VALUES(15,'lecalife_003.jpeg',NULL,NULL,NULL,NULL,NULL,'22c8d9281f7a4c03bed5fa4178ccfcbe','.jpeg','image/jpeg',141.92,'/uploads/22c8d9281f7a4c03bed5fa4178ccfcbe.jpeg',NULL,'local',NULL,NULL,NULL,1552397338170,1552397338183);
INSERT INTO "upload_file" VALUES(16,'lecalife_004.jpeg',NULL,NULL,NULL,NULL,NULL,'5d81455f4ad34e33a520c94ac3cc5947','.jpeg','image/jpeg',44.82,'/uploads/5d81455f4ad34e33a520c94ac3cc5947.jpeg',NULL,'local',NULL,NULL,NULL,1552397338170,1552397338184);
INSERT INTO "upload_file" VALUES(17,'lepiaf_003.jpeg',NULL,NULL,NULL,NULL,NULL,'5fe7e3ac45354029bc0d9dd52d4e00ec','.jpeg','image/jpeg',81.7,'/uploads/5fe7e3ac45354029bc0d9dd52d4e00ec.jpeg',NULL,'local',NULL,NULL,NULL,1552397796586,1552397796599);
INSERT INTO "upload_file" VALUES(18,'lepiaf_001.jpeg',NULL,NULL,NULL,NULL,NULL,'86b4ea14d0e142fe95eacfde5508372f','.jpeg','image/jpeg',153.87,'/uploads/86b4ea14d0e142fe95eacfde5508372f.jpeg',NULL,'local',NULL,NULL,NULL,1552397796587,1552397796600);
INSERT INTO "upload_file" VALUES(19,'lepiaf_002.jpeg',NULL,NULL,NULL,NULL,NULL,'002c37a9152e487cac8cfb387a1e99db','.jpeg','image/jpeg',143.03,'/uploads/002c37a9152e487cac8cfb387a1e99db.jpeg',NULL,'local',NULL,NULL,NULL,1552397796588,1552397796602);
INSERT INTO "upload_file" VALUES(20,'lepiaf_004.jpeg',NULL,NULL,NULL,NULL,NULL,'da26bb68e1384ceab0e4cfa1944b48a0','.jpeg','image/jpeg',87.03,'/uploads/da26bb68e1384ceab0e4cfa1944b48a0.jpeg',NULL,'local',NULL,NULL,NULL,1552397796588,1552397796603);
INSERT INTO "upload_file" VALUES(21,'guiloguilo_001.jpeg',NULL,NULL,NULL,NULL,NULL,'17273dd904c14c80b986e889f2e91121','.jpeg','image/jpeg',146.15,'/uploads/17273dd904c14c80b986e889f2e91121.jpeg',NULL,'local',NULL,NULL,NULL,1552397911044,1552397911060);
INSERT INTO "upload_file" VALUES(22,'guiloguilo_004.jpeg',NULL,NULL,NULL,NULL,NULL,'0962dfef80ce4a4f968b2abe67dd5e1b','.jpeg','image/jpeg',121.66,'/uploads/0962dfef80ce4a4f968b2abe67dd5e1b.jpeg',NULL,'local',NULL,NULL,NULL,1552397911044,1552397911061);
INSERT INTO "upload_file" VALUES(23,'guiloguilo_002.jpeg',NULL,NULL,NULL,NULL,NULL,'42a507e3fdf448a586cb9886192ebcd1','.jpeg','image/jpeg',198.78,'/uploads/42a507e3fdf448a586cb9886192ebcd1.jpeg',NULL,'local',NULL,NULL,NULL,1552397911044,1552397911062);
INSERT INTO "upload_file" VALUES(24,'guiloguilo_003.jpeg',NULL,NULL,NULL,NULL,NULL,'899f9f3eff6544eca26aca760633bf90','.jpeg','image/jpeg',475.98,'/uploads/899f9f3eff6544eca26aca760633bf90.jpeg',NULL,'local',NULL,NULL,NULL,1552397911045,1552397911064);
INSERT INTO "upload_file" VALUES(25,'laMiN_002.jpeg',NULL,NULL,NULL,NULL,NULL,'f2a502483a5f4d9db024185670323889','.jpeg','image/jpeg',181.55,'/uploads/f2a502483a5f4d9db024185670323889.jpeg',NULL,'local',NULL,NULL,NULL,1552398585441,1552398585449);
INSERT INTO "upload_file" VALUES(26,'laMiN_001.jpeg',NULL,NULL,NULL,NULL,NULL,'9e1b5bfc019a462781d10df1c20ed630','.jpeg','image/jpeg',427.32,'/uploads/9e1b5bfc019a462781d10df1c20ed630.jpeg',NULL,'local',NULL,NULL,NULL,1552398585441,1552398585450);
INSERT INTO "upload_file" VALUES(27,'laMiN_003.jpeg',NULL,NULL,NULL,NULL,NULL,'589acd0143df4609b170870fda629ce6','.jpeg','image/jpeg',251.0,'/uploads/589acd0143df4609b170870fda629ce6.jpeg',NULL,'local',NULL,NULL,NULL,1552398585441,1552398585451);
INSERT INTO "upload_file" VALUES(28,'laMiN_004.jpeg',NULL,NULL,NULL,NULL,NULL,'b2927120b21c40d08bb8d4829818b8cb','.jpeg','image/jpeg',208.83,'/uploads/b2927120b21c40d08bb8d4829818b8cb.jpeg',NULL,'local',NULL,NULL,NULL,1552398585441,1552398585452);
INSERT INTO "upload_file" VALUES(29,'oplato_001.jpeg',NULL,NULL,NULL,NULL,NULL,'7e9b27ad612b44739c7b5a4e8601966f','.jpeg','image/jpeg',79.99,'/uploads/7e9b27ad612b44739c7b5a4e8601966f.jpeg',NULL,'local',NULL,NULL,NULL,1552398874796,1552398874806);
INSERT INTO "upload_file" VALUES(30,'oplato_002.jpeg',NULL,NULL,NULL,NULL,NULL,'906e5ebb9b2a493ea8fe154fab153d28','.jpeg','image/jpeg',248.3,'/uploads/906e5ebb9b2a493ea8fe154fab153d28.jpeg',NULL,'local',NULL,NULL,NULL,1552398874796,1552398874807);
INSERT INTO "upload_file" VALUES(31,'oplato_003.jpeg',NULL,NULL,NULL,NULL,NULL,'0fa876133d994feaa1c6f8990e2d9dea','.jpeg','image/jpeg',96.49,'/uploads/0fa876133d994feaa1c6f8990e2d9dea.jpeg',NULL,'local',NULL,NULL,NULL,1552398874797,1552398874807);
INSERT INTO "upload_file" VALUES(32,'oplato_004.jpeg',NULL,NULL,NULL,NULL,NULL,'a45867042208488e931ed093c6f412b1','.jpeg','image/jpeg',219.82,'/uploads/a45867042208488e931ed093c6f412b1.jpeg',NULL,'local',NULL,NULL,NULL,1552398874797,1552398874808);
INSERT INTO "upload_file" VALUES(33,'jardinkashmir_003.jpeg',NULL,NULL,NULL,NULL,NULL,'f52bb9722efe4b10bb3e5c3e0fd0896e','.jpeg','image/jpeg',128.4,'/uploads/f52bb9722efe4b10bb3e5c3e0fd0896e.jpeg',NULL,'local',NULL,NULL,NULL,1552399083732,1552399083743);
INSERT INTO "upload_file" VALUES(34,'jardinkashmir_002.jpeg',NULL,NULL,NULL,NULL,NULL,'9d9c9a89985345cc8e36dfe162f63a98','.jpeg','image/jpeg',299.52,'/uploads/9d9c9a89985345cc8e36dfe162f63a98.jpeg',NULL,'local',NULL,NULL,NULL,1552399083733,1552399083744);
INSERT INTO "upload_file" VALUES(35,'jardinkashmir_001.jpeg',NULL,NULL,NULL,NULL,NULL,'08c9c93c6f194351808820bf507edae1','.jpeg','image/jpeg',278.82,'/uploads/08c9c93c6f194351808820bf507edae1.jpeg',NULL,'local',NULL,NULL,NULL,1552399083733,1552399083744);
INSERT INTO "upload_file" VALUES(36,'jardinkashmir_004.jpeg',NULL,NULL,NULL,NULL,NULL,'d867c7b4856c4669bca6bf85d709735c','.jpeg','image/jpeg',119.01,'/uploads/d867c7b4856c4669bca6bf85d709735c.jpeg',NULL,'local',NULL,NULL,NULL,1552399083733,1552399083745);
INSERT INTO "upload_file" VALUES(37,'cezembre_001.jpeg',NULL,NULL,NULL,NULL,NULL,'341731eeddf9411eaeaa9b01aa1c6bf8','.jpeg','image/jpeg',173.21,'/uploads/341731eeddf9411eaeaa9b01aa1c6bf8.jpeg',NULL,'local',NULL,NULL,NULL,1552399333610,1552399333622);
INSERT INTO "upload_file" VALUES(38,'cezembre_003.jpeg',NULL,NULL,NULL,NULL,NULL,'fd15670843a54bf5a58852bbb454fb1d','.jpeg','image/jpeg',431.44,'/uploads/fd15670843a54bf5a58852bbb454fb1d.jpeg',NULL,'local',NULL,NULL,NULL,1552399333610,1552399333623);
INSERT INTO "upload_file" VALUES(39,'cezembre_002.jpeg',NULL,NULL,NULL,NULL,NULL,'23ddaf9d7971435183b8f720f04a0430','.jpeg','image/jpeg',288.05,'/uploads/23ddaf9d7971435183b8f720f04a0430.jpeg',NULL,'local',NULL,NULL,NULL,1552399333610,1552399333624);
INSERT INTO "upload_file" VALUES(40,'cezembre_004.jpeg',NULL,NULL,NULL,NULL,NULL,'7923a72ae36f405085cc26395a1ef5aa','.jpeg','image/jpeg',283.47,'/uploads/7923a72ae36f405085cc26395a1ef5aa.jpeg',NULL,'local',NULL,NULL,NULL,1552399333611,1552399333625);
INSERT INTO "upload_file" VALUES(41,'bisouscreperie_001.jpeg',NULL,NULL,NULL,NULL,NULL,'1a1e9c2f1129455281aa1333f7aafcc8','.jpeg','image/jpeg',382.37,'/uploads/1a1e9c2f1129455281aa1333f7aafcc8.jpeg',NULL,'local',NULL,NULL,NULL,1552399498854,1552399498864);
INSERT INTO "upload_file" VALUES(42,'bisouscreperie_002.jpeg',NULL,NULL,NULL,NULL,NULL,'1b1977ebcaf949db980de397bdda36ad','.jpeg','image/jpeg',158.88,'/uploads/1b1977ebcaf949db980de397bdda36ad.jpeg',NULL,'local',NULL,NULL,NULL,1552399498854,1552399498866);
INSERT INTO "upload_file" VALUES(43,'bisouscreperie_003.jpeg',NULL,NULL,NULL,NULL,NULL,'f2759b0d63c24dd3987841f23aad0707','.jpeg','image/jpeg',134.88,'/uploads/f2759b0d63c24dd3987841f23aad0707.jpeg',NULL,'local',NULL,NULL,NULL,1552399498855,1552399498867);
INSERT INTO "upload_file" VALUES(44,'bisouscreperie_004.jpeg',NULL,NULL,NULL,NULL,NULL,'f77f7b1d36bc4ceab5e9e510fee3b1b6','.jpeg','image/jpeg',286.45,'/uploads/f77f7b1d36bc4ceab5e9e510fee3b1b6.jpeg',NULL,'local',NULL,NULL,NULL,1552399498855,1552399498868);
INSERT INTO "upload_file" VALUES(45,'biscotte_001.jpeg',NULL,NULL,NULL,NULL,NULL,'25862c74ac624b08aac7743297ef1232','.jpeg','image/jpeg',203.66,'/uploads/25862c74ac624b08aac7743297ef1232.jpeg',NULL,'local',NULL,NULL,NULL,1552399727432,1552399727440);
INSERT INTO "upload_file" VALUES(46,'biscotte_004.jpeg',NULL,NULL,NULL,NULL,NULL,'0ebc4fe2de194a25ab8bedfe4379152c','.jpeg','image/jpeg',162.53,'/uploads/0ebc4fe2de194a25ab8bedfe4379152c.jpeg',NULL,'local',NULL,NULL,NULL,1552399727432,1552399727441);
INSERT INTO "upload_file" VALUES(47,'biscotte_002.jpeg',NULL,NULL,NULL,NULL,NULL,'6399482399e946f38503a69e5e298aa1','.jpeg','image/jpeg',79.23,'/uploads/6399482399e946f38503a69e5e298aa1.jpeg',NULL,'local',NULL,NULL,NULL,1552399727432,1552399727443);
INSERT INTO "upload_file" VALUES(48,'biscotte_003.jpeg',NULL,NULL,NULL,NULL,NULL,'4358665e44d04adebb31e9e5b5496a6c','.jpeg','image/jpeg',114.88,'/uploads/4358665e44d04adebb31e9e5b5496a6c.jpeg',NULL,'local',NULL,NULL,NULL,1552399727432,1552399727444);
INSERT INTO "upload_file" VALUES(49,'bistrotindochine_002.jpeg',NULL,NULL,NULL,NULL,NULL,'9d54d9ed91274f0b8155f5eceb53a87d','.jpeg','image/jpeg',69.18,'/uploads/9d54d9ed91274f0b8155f5eceb53a87d.jpeg',NULL,'local',NULL,NULL,NULL,1552400250819,1552400250829);
INSERT INTO "upload_file" VALUES(50,'bistrotindochine_001.jpeg',NULL,NULL,NULL,NULL,NULL,'4e8b11be6d084bfebc35b2e67ab6b830','.jpeg','image/jpeg',95.13,'/uploads/4e8b11be6d084bfebc35b2e67ab6b830.jpeg',NULL,'local',NULL,NULL,NULL,1552400250819,1552400250830);
INSERT INTO "upload_file" VALUES(51,'bistrotindochine_004.jpeg',NULL,NULL,NULL,NULL,NULL,'9e7c21319cb8498f8bae02709ec4fd95','.jpeg','image/jpeg',61.63,'/uploads/9e7c21319cb8498f8bae02709ec4fd95.jpeg',NULL,'local',NULL,NULL,NULL,1552400250821,1552400250830);
INSERT INTO "upload_file" VALUES(52,'bistrotindochine_003.jpeg',NULL,NULL,NULL,NULL,NULL,'49de1f4b215b4303b4fda937740cd8a9','.jpeg','image/jpeg',73.69,'/uploads/49de1f4b215b4303b4fda937740cd8a9.jpeg',NULL,'local',NULL,NULL,NULL,1552400250821,1552400250832);
INSERT INTO "upload_file" VALUES(53,'ruisseauburger_001.jpeg',NULL,NULL,NULL,NULL,NULL,'ded61641738540438ca95eb4e354a1b8','.jpeg','image/jpeg',53.8,'/uploads/ded61641738540438ca95eb4e354a1b8.jpeg',NULL,'local',NULL,NULL,NULL,1552400458503,1552400458515);
INSERT INTO "upload_file" VALUES(54,'ruisseauburger_002.jpeg',NULL,NULL,NULL,NULL,NULL,'42d030f989984871967833252fb2e047','.jpeg','image/jpeg',92.08,'/uploads/42d030f989984871967833252fb2e047.jpeg',NULL,'local',NULL,NULL,NULL,1552400458503,1552400458516);
INSERT INTO "upload_file" VALUES(55,'ruisseauburger_004.jpeg',NULL,NULL,NULL,NULL,NULL,'f1943d93ddc64c16adfa787ae678fe78','.jpeg','image/jpeg',85.53,'/uploads/f1943d93ddc64c16adfa787ae678fe78.jpeg',NULL,'local',NULL,NULL,NULL,1552400458503,1552400458517);
INSERT INTO "upload_file" VALUES(56,'ruisseauburger_003.jpeg',NULL,NULL,NULL,NULL,NULL,'fd62ac435a9c4bb6b3f2919de58e5740','.jpeg','image/jpeg',42.72,'/uploads/fd62ac435a9c4bb6b3f2919de58e5740.jpeg',NULL,'local',NULL,NULL,NULL,1552400458503,1552400458517);
INSERT INTO "upload_file" VALUES(57,'mancoracebicheria_001.jpeg',NULL,NULL,NULL,NULL,NULL,'71035765a586481cb3c7a3e2f0615561','.jpeg','image/jpeg',73.68,'/uploads/71035765a586481cb3c7a3e2f0615561.jpeg',NULL,'local',NULL,NULL,NULL,1552400602846,1552400602856);
INSERT INTO "upload_file" VALUES(58,'mancoracebicheria_004.jpeg',NULL,NULL,NULL,NULL,NULL,'e51bbc9dbb8e47b9b37340d30937a903','.jpeg','image/jpeg',148.79,'/uploads/e51bbc9dbb8e47b9b37340d30937a903.jpeg',NULL,'local',NULL,NULL,NULL,1552400602846,1552400602857);
INSERT INTO "upload_file" VALUES(59,'mancoracebicheria_003.jpeg',NULL,NULL,NULL,NULL,NULL,'bc665a991c834386adfadb3a847e70a9','.jpeg','image/jpeg',115.93,'/uploads/bc665a991c834386adfadb3a847e70a9.jpeg',NULL,'local',NULL,NULL,NULL,1552400602846,1552400602857);
INSERT INTO "upload_file" VALUES(60,'mancoracebicheria_002.jpeg',NULL,NULL,NULL,NULL,NULL,'5615a72e60494891a54112058756bf83','.jpeg','image/jpeg',230.26,'/uploads/5615a72e60494891a54112058756bf83.jpeg',NULL,'local',NULL,NULL,NULL,1552400602846,1552400602858);
INSERT INTO "upload_file" VALUES(61,'arrivederci_001.jpeg',NULL,NULL,NULL,NULL,NULL,'9ca77246b1a44df59aa3ddb77457c10a','.jpeg','image/jpeg',84.47,'/uploads/9ca77246b1a44df59aa3ddb77457c10a.jpeg',NULL,'local',NULL,NULL,NULL,1552401900839,1552401900850);
INSERT INTO "upload_file" VALUES(62,'arrivederci_002.jpeg',NULL,NULL,NULL,NULL,NULL,'3087fb16909d40c980823b25198ca253','.jpeg','image/jpeg',57.82,'/uploads/3087fb16909d40c980823b25198ca253.jpeg',NULL,'local',NULL,NULL,NULL,1552401900839,1552401900851);
INSERT INTO "upload_file" VALUES(63,'arrivederci_003.jpeg',NULL,NULL,NULL,NULL,NULL,'47167fb5d728420e9bcd49d41760dfc2','.jpeg','image/jpeg',77.9,'/uploads/47167fb5d728420e9bcd49d41760dfc2.jpeg',NULL,'local',NULL,NULL,NULL,1552401900839,1552401900852);
INSERT INTO "upload_file" VALUES(64,'arrivederci_004.jpeg',NULL,NULL,NULL,NULL,NULL,'2eff130c358c4b9d8c309ce369d3ad2d','.jpeg','image/jpeg',97.29,'/uploads/2eff130c358c4b9d8c309ce369d3ad2d.jpeg',NULL,'local',NULL,NULL,NULL,1552401900839,1552401900853);
INSERT INTO "upload_file" VALUES(65,'loubnane_001.jpeg',NULL,NULL,NULL,NULL,NULL,'0b20dec91eee46f9aca8e854b94c040b','.jpeg','image/jpeg',67.01,'/uploads/0b20dec91eee46f9aca8e854b94c040b.jpeg',NULL,'local',NULL,NULL,NULL,1552402071604,1552402071613);
INSERT INTO "upload_file" VALUES(66,'loubnane_002.jpeg',NULL,NULL,NULL,NULL,NULL,'c124bf70bc0347dab50bb96929f04bf4','.jpeg','image/jpeg',70.31,'/uploads/c124bf70bc0347dab50bb96929f04bf4.jpeg',NULL,'local',NULL,NULL,NULL,1552402071604,1552402071615);
INSERT INTO "upload_file" VALUES(67,'loubnane_003.jpeg',NULL,NULL,NULL,NULL,NULL,'418f401edaa8496790ff34bc36e04c37','.jpeg','image/jpeg',111.73,'/uploads/418f401edaa8496790ff34bc36e04c37.jpeg',NULL,'local',NULL,NULL,NULL,1552402071605,1552402071615);
INSERT INTO "upload_file" VALUES(68,'loubnane_004.jpeg',NULL,NULL,NULL,NULL,NULL,'fb0053d29bbb4639af8b6cc27ff0529a','.jpeg','image/jpeg',57.6,'/uploads/fb0053d29bbb4639af8b6cc27ff0529a.jpeg',NULL,'local',NULL,NULL,NULL,1552402071605,1552402071616);
INSERT INTO "upload_file" VALUES(69,'danard_001.jpeg',NULL,NULL,NULL,NULL,NULL,'bdb95ff372e0430d9789b6acbcddff5b','.jpeg','image/jpeg',56.73,'/uploads/bdb95ff372e0430d9789b6acbcddff5b.jpeg',NULL,'local',NULL,NULL,NULL,1552402253671,1552402253708);
INSERT INTO "upload_file" VALUES(70,'danard_002.jpeg',NULL,NULL,NULL,NULL,NULL,'4754cf06790b4c2f9c16e0b56617ccec','.jpeg','image/jpeg',98.13,'/uploads/4754cf06790b4c2f9c16e0b56617ccec.jpeg',NULL,'local',NULL,NULL,NULL,1552402253671,1552402253709);
INSERT INTO "upload_file" VALUES(71,'danard_004.jpeg',NULL,NULL,NULL,NULL,NULL,'7ce0010c16a2404dad5b4c524447529e','.jpeg','image/jpeg',53.77,'/uploads/7ce0010c16a2404dad5b4c524447529e.jpeg',NULL,'local',NULL,NULL,NULL,1552402253672,1552402253709);
INSERT INTO "upload_file" VALUES(72,'danard_003.jpeg',NULL,NULL,NULL,NULL,NULL,'1b7f5d7d35814ac283744ce40efacaf4','.jpeg','image/jpeg',207.86,'/uploads/1b7f5d7d35814ac283744ce40efacaf4.jpeg',NULL,'local',NULL,NULL,NULL,1552402253674,1552402253710);
INSERT INTO "upload_file" VALUES(73,'baronrouge_001.jpeg',NULL,NULL,NULL,NULL,NULL,'8bb416e5e6ba4b25b8d4f1b2a8e63b9d','.jpeg','image/jpeg',41.29,'/uploads/8bb416e5e6ba4b25b8d4f1b2a8e63b9d.jpeg',NULL,'local',NULL,NULL,NULL,1552402509316,1552402509327);
INSERT INTO "upload_file" VALUES(74,'baronrouge_002.jpeg',NULL,NULL,NULL,NULL,NULL,'37f1ee9be7e3470082e3231d71ece7c5','.jpeg','image/jpeg',44.76,'/uploads/37f1ee9be7e3470082e3231d71ece7c5.jpeg',NULL,'local',NULL,NULL,NULL,1552402509317,1552402509328);
INSERT INTO "upload_file" VALUES(75,'baronrouge_003.jpeg',NULL,NULL,NULL,NULL,NULL,'eebe1b8ed012402caefb001b403249a7','.jpeg','image/jpeg',63.84,'/uploads/eebe1b8ed012402caefb001b403249a7.jpeg',NULL,'local',NULL,NULL,NULL,1552402509317,1552402509329);
INSERT INTO "upload_file" VALUES(76,'baronrouge_004.jpeg',NULL,NULL,NULL,NULL,NULL,'84aa457c19c04c59bf6f7142f6335576','.jpeg','image/jpeg',152.88,'/uploads/84aa457c19c04c59bf6f7142f6335576.jpeg',NULL,'local',NULL,NULL,NULL,1552402509317,1552402509329);
INSERT INTO "upload_file" VALUES(77,'shescake_002.jpeg',NULL,NULL,NULL,NULL,NULL,'daa5adc9427840d3a82929a0d19c63fa','.jpeg','image/jpeg',40.48,'/uploads/daa5adc9427840d3a82929a0d19c63fa.jpeg',NULL,'local',NULL,NULL,NULL,1552402698473,1552402698485);
INSERT INTO "upload_file" VALUES(78,'shescake_004.jpeg',NULL,NULL,NULL,NULL,NULL,'6679825a5b4f495ebf0e784ce41ac2d2','.jpeg','image/jpeg',85.88,'/uploads/6679825a5b4f495ebf0e784ce41ac2d2.jpeg',NULL,'local',NULL,NULL,NULL,1552402698473,1552402698486);
INSERT INTO "upload_file" VALUES(79,'shescake_003.jpeg',NULL,NULL,NULL,NULL,NULL,'6409c3c2b0d04cb79b6402d9d31231bb','.jpeg','image/jpeg',83.86,'/uploads/6409c3c2b0d04cb79b6402d9d31231bb.jpeg',NULL,'local',NULL,NULL,NULL,1552402698474,1552402698486);
INSERT INTO "upload_file" VALUES(80,'shescake_001.jpeg',NULL,NULL,NULL,NULL,NULL,'7f26de1d0ef440dab3d206f9e0bb459f','.jpeg','image/jpeg',77.03,'/uploads/7f26de1d0ef440dab3d206f9e0bb459f.jpeg',NULL,'local',NULL,NULL,NULL,1552402698474,1552402698487);
INSERT INTO "upload_file" VALUES(81,'merveilleux_001.jpeg',NULL,NULL,NULL,NULL,NULL,'3cccaad906dd46d2b5b3eb4a9d9c0d76','.jpeg','image/jpeg',12.43,'/uploads/3cccaad906dd46d2b5b3eb4a9d9c0d76.jpeg',NULL,'local',NULL,NULL,NULL,1552402851318,1552402851329);
INSERT INTO "upload_file" VALUES(82,'merveilleux_002.jpeg',NULL,NULL,NULL,NULL,NULL,'52643a5244e64b50a9a0a67e0af391cb','.jpeg','image/jpeg',13.96,'/uploads/52643a5244e64b50a9a0a67e0af391cb.jpeg',NULL,'local',NULL,NULL,NULL,1552402851319,1552402851330);
INSERT INTO "upload_file" VALUES(83,'merveilleux_003.jpeg',NULL,NULL,NULL,NULL,NULL,'b3e452041cca46b7ba603b7a1b82aa86','.jpeg','image/jpeg',13.82,'/uploads/b3e452041cca46b7ba603b7a1b82aa86.jpeg',NULL,'local',NULL,NULL,NULL,1552402851319,1552402851330);
INSERT INTO "upload_file" VALUES(84,'merveilleux_004.jpeg',NULL,NULL,NULL,NULL,NULL,'da411d4dc0334955b352fee0e1a60f2a','.jpeg','image/jpeg',8.89,'/uploads/da411d4dc0334955b352fee0e1a60f2a.jpeg',NULL,'local',NULL,NULL,NULL,1552402851319,1552402851331);
INSERT INTO "upload_file" VALUES(85,'comptoirgourmet_001.jpeg',NULL,NULL,NULL,NULL,NULL,'bbd18e1c2e424df6bd0a1adf7b06b03f','.jpeg','image/jpeg',104.22,'/uploads/bbd18e1c2e424df6bd0a1adf7b06b03f.jpeg',NULL,'local',NULL,NULL,NULL,1552403078997,1552403079008);
INSERT INTO "upload_file" VALUES(86,'comptoirgourmet_003.jpeg',NULL,NULL,NULL,NULL,NULL,'20d584e9ed894ffd963772bb96121d3c','.jpeg','image/jpeg',148.79,'/uploads/20d584e9ed894ffd963772bb96121d3c.jpeg',NULL,'local',NULL,NULL,NULL,1552403078997,1552403079009);
INSERT INTO "upload_file" VALUES(87,'comptoirgourmet_002.jpeg',NULL,NULL,NULL,NULL,NULL,'f855f3a442664ce6b17fc7f6e2972343','.jpeg','image/jpeg',64.52,'/uploads/f855f3a442664ce6b17fc7f6e2972343.jpeg',NULL,'local',NULL,NULL,NULL,1552403078999,1552403079009);
INSERT INTO "upload_file" VALUES(88,'comptoirgourmet_004.jpeg',NULL,NULL,NULL,NULL,NULL,'025075e5d11b44f0b66b66101340c4b6','.jpeg','image/jpeg',62.88,'/uploads/025075e5d11b44f0b66b66101340c4b6.jpeg',NULL,'local',NULL,NULL,NULL,1552403078999,1552403079011);
INSERT INTO "upload_file" VALUES(89,'reed_001.jpeg',NULL,NULL,NULL,NULL,NULL,'663e9a8f761b49f8ac6fca16b78bec5d','.jpeg','image/jpeg',22.8,'/uploads/663e9a8f761b49f8ac6fca16b78bec5d.jpeg',NULL,'local',NULL,NULL,NULL,1552403250549,1552403250558);
INSERT INTO "upload_file" VALUES(90,'reed_002.jpeg',NULL,NULL,NULL,NULL,NULL,'5bed26d6fdd94bb9af9308081eeaa4a5','.jpeg','image/jpeg',40.64,'/uploads/5bed26d6fdd94bb9af9308081eeaa4a5.jpeg',NULL,'local',NULL,NULL,NULL,1552403250549,1552403250558);
INSERT INTO "upload_file" VALUES(91,'reed_003.jpeg',NULL,NULL,NULL,NULL,NULL,'9a77d74713bc48548fd988ec0fa01cad','.jpeg','image/jpeg',40.25,'/uploads/9a77d74713bc48548fd988ec0fa01cad.jpeg',NULL,'local',NULL,NULL,NULL,1552403250550,1552403250560);
INSERT INTO "upload_file" VALUES(92,'reed_004.jpeg',NULL,NULL,NULL,NULL,NULL,'742f186af1cc48d880c432af108dde86','.jpeg','image/jpeg',67.22,'/uploads/742f186af1cc48d880c432af108dde86.jpeg',NULL,'local',NULL,NULL,NULL,1552403250550,1552403250561);
INSERT INTO "upload_file" VALUES(93,'thaipapaye_001.jpeg',NULL,NULL,NULL,NULL,NULL,'75387e78347047be85e2793077b1efe1','.jpeg','image/jpeg',39.15,'/uploads/75387e78347047be85e2793077b1efe1.jpeg',NULL,'local',NULL,NULL,NULL,1552403510460,1552403510469);
INSERT INTO "upload_file" VALUES(94,'thaipapaye_002.jpeg',NULL,NULL,NULL,NULL,NULL,'d064430ea29849d695e65310862b6786','.jpeg','image/jpeg',123.18,'/uploads/d064430ea29849d695e65310862b6786.jpeg',NULL,'local',NULL,NULL,NULL,1552403510461,1552403510470);
INSERT INTO "upload_file" VALUES(95,'thaipapaye_003.jpeg',NULL,NULL,NULL,NULL,NULL,'838d4a1729ac4f21b0d0e8638fb08c48','.jpeg','image/jpeg',115.51,'/uploads/838d4a1729ac4f21b0d0e8638fb08c48.jpeg',NULL,'local',NULL,NULL,NULL,1552403510461,1552403510471);
INSERT INTO "upload_file" VALUES(96,'thaipapaye_004.jpeg',NULL,NULL,NULL,NULL,NULL,'17666bf6b4c34bff890e238fafa4cd71','.jpeg','image/jpeg',78.18,'/uploads/17666bf6b4c34bff890e238fafa4cd71.jpeg',NULL,'local',NULL,NULL,NULL,1552403510461,1552403510472);
INSERT INTO "upload_file" VALUES(97,'becaneagaston_003.jpeg',NULL,NULL,NULL,NULL,NULL,'7460f144ab584379a1ff61546b22fc89','.jpeg','image/jpeg',93.86,'/uploads/7460f144ab584379a1ff61546b22fc89.jpeg',NULL,'local',NULL,NULL,NULL,1552403694232,1552403694242);
INSERT INTO "upload_file" VALUES(98,'becaneagaston_001.jpeg',NULL,NULL,NULL,NULL,NULL,'68e4b61030e64343b496f9b34fd44fc2','.jpeg','image/jpeg',84.77,'/uploads/68e4b61030e64343b496f9b34fd44fc2.jpeg',NULL,'local',NULL,NULL,NULL,1552403694232,1552403694243);
INSERT INTO "upload_file" VALUES(99,'becaneagaston_004.jpeg',NULL,NULL,NULL,NULL,NULL,'7077c3f872734ff69ed963e0629fe7c5','.jpeg','image/jpeg',58.42,'/uploads/7077c3f872734ff69ed963e0629fe7c5.jpeg',NULL,'local',NULL,NULL,NULL,1552403694233,1552403694243);
INSERT INTO "upload_file" VALUES(100,'becaneagaston_002.jpeg',NULL,NULL,NULL,NULL,NULL,'46c7e9f67e8e4012bc7b86c004c532c1','.jpeg','image/jpeg',116.26,'/uploads/46c7e9f67e8e4012bc7b86c004c532c1.jpeg',NULL,'local',NULL,NULL,NULL,1552403694233,1552403694244);
INSERT INTO "upload_file" VALUES(101,'bmk_003.jpg',NULL,NULL,NULL,NULL,NULL,'04e20a3d1fbd44199e3b5ce22f565175','.jpg','image/jpeg',69.52,'/uploads/04e20a3d1fbd44199e3b5ce22f565175.jpg',NULL,'local',NULL,NULL,NULL,1552404087887,1552404087897);
INSERT INTO "upload_file" VALUES(102,'bmk_002.jpeg',NULL,NULL,NULL,NULL,NULL,'1a720879312e4c0ebc9c48675b365d48','.jpeg','image/jpeg',119.93,'/uploads/1a720879312e4c0ebc9c48675b365d48.jpeg',NULL,'local',NULL,NULL,NULL,1552404087887,1552404087897);
INSERT INTO "upload_file" VALUES(103,'bmk_001.jpeg',NULL,NULL,NULL,NULL,NULL,'36c6d7fa6d874a6ab1373e950fde1742','.jpeg','image/jpeg',138.33,'/uploads/36c6d7fa6d874a6ab1373e950fde1742.jpeg',NULL,'local',NULL,NULL,NULL,1552404087888,1552404087899);
INSERT INTO "upload_file" VALUES(104,'bmk_004.jpeg',NULL,NULL,NULL,NULL,NULL,'a1e31663399d4d3faef55b364c4252c2','.jpeg','image/jpeg',67.98,'/uploads/a1e31663399d4d3faef55b364c4252c2.jpeg',NULL,'local',NULL,NULL,NULL,1552404087888,1552404087900);
INSERT INTO "upload_file" VALUES(105,'cafebolivar_003.jpeg',NULL,NULL,NULL,NULL,NULL,'df4b289827c64902b59b8f957ddc05c4','.jpeg','image/jpeg',136.76,'/uploads/df4b289827c64902b59b8f957ddc05c4.jpeg',NULL,'local',NULL,NULL,NULL,1552404287605,1552404287616);
INSERT INTO "upload_file" VALUES(106,'cafebolivar_002.jpeg',NULL,NULL,NULL,NULL,NULL,'cb8934b80115483ea789e16231942f20','.jpeg','image/jpeg',90.59,'/uploads/cb8934b80115483ea789e16231942f20.jpeg',NULL,'local',NULL,NULL,NULL,1552404287605,1552404287616);
INSERT INTO "upload_file" VALUES(107,'cafebolivar_004.jpeg',NULL,NULL,NULL,NULL,NULL,'dd5bf235c86149fc991ac7fb3375bb8e','.jpeg','image/jpeg',77.12,'/uploads/dd5bf235c86149fc991ac7fb3375bb8e.jpeg',NULL,'local',NULL,NULL,NULL,1552404287606,1552404287617);
INSERT INTO "upload_file" VALUES(108,'cafebolivar_001.jpeg',NULL,NULL,NULL,NULL,NULL,'56301de0837f4818b80610a8c71b94ad','.jpeg','image/jpeg',140.32,'/uploads/56301de0837f4818b80610a8c71b94ad.jpeg',NULL,'local',NULL,NULL,NULL,1552404287606,1552404287617);
INSERT INTO "upload_file" VALUES(109,'enfantsgates_002.jpeg',NULL,NULL,NULL,NULL,NULL,'f12f7dbc3e4d4c65ab6783d4f6fab084','.jpeg','image/jpeg',96.12,'/uploads/f12f7dbc3e4d4c65ab6783d4f6fab084.jpeg',NULL,'local',NULL,NULL,NULL,1552404443392,1552404443403);
INSERT INTO "upload_file" VALUES(110,'enfantsgates_001.jpeg',NULL,NULL,NULL,NULL,NULL,'4b66f90a305f43f1b6e5ea76e65cbb31','.jpeg','image/jpeg',90.84,'/uploads/4b66f90a305f43f1b6e5ea76e65cbb31.jpeg',NULL,'local',NULL,NULL,NULL,1552404443392,1552404443404);
INSERT INTO "upload_file" VALUES(111,'enfantsgates_003.jpeg',NULL,NULL,NULL,NULL,NULL,'26bd1244a0e84b9da76bdff1187df008','.jpeg','image/jpeg',77.33,'/uploads/26bd1244a0e84b9da76bdff1187df008.jpeg',NULL,'local',NULL,NULL,NULL,1552404443392,1552404443404);
INSERT INTO "upload_file" VALUES(112,'enfantsgates_004.jpeg',NULL,NULL,NULL,NULL,NULL,'cc91373a9b194875a10f8b6b4a112855','.jpeg','image/jpeg',101.17,'/uploads/cc91373a9b194875a10f8b6b4a112855.jpeg',NULL,'local',NULL,NULL,NULL,1552404443392,1552404443405);
INSERT INTO "upload_file" VALUES(113,'obrigao_002.jpeg',NULL,NULL,NULL,NULL,NULL,'8ca4bf5373fd4564be76d552cd5ffcf9','.jpeg','image/jpeg',121.82,'/uploads/8ca4bf5373fd4564be76d552cd5ffcf9.jpeg',NULL,'local',NULL,NULL,NULL,1552404669337,1552404669350);
INSERT INTO "upload_file" VALUES(114,'obrigao_001.jpeg',NULL,NULL,NULL,NULL,NULL,'b525fa55e767441cadd974deea45d7ff','.jpeg','image/jpeg',58.52,'/uploads/b525fa55e767441cadd974deea45d7ff.jpeg',NULL,'local',NULL,NULL,NULL,1552404669338,1552404669351);
INSERT INTO "upload_file" VALUES(115,'obrigao_004.jpeg',NULL,NULL,NULL,NULL,NULL,'388e12ee0c434beb994b60da9f117fe5','.jpeg','image/jpeg',153.53,'/uploads/388e12ee0c434beb994b60da9f117fe5.jpeg',NULL,'local',NULL,NULL,NULL,1552404669339,1552404669352);
INSERT INTO "upload_file" VALUES(116,'obrigao_003.jpeg',NULL,NULL,NULL,NULL,NULL,'f66469b15f484f2f88c0264f278bec75','.jpeg','image/jpeg',64.32,'/uploads/f66469b15f484f2f88c0264f278bec75.jpeg',NULL,'local',NULL,NULL,NULL,1552404669340,1552404669353);
INSERT INTO "upload_file" VALUES(117,'0.jpg',NULL,NULL,NULL,NULL,NULL,'5f4a1af0c3bd49799a4de5269112fa50','.jpg','image/jpeg',4.86,'/uploads/5f4a1af0c3bd49799a4de5269112fa50.jpg',NULL,'local',NULL,NULL,NULL,1552486065339,1552486065345);
INSERT INTO "upload_file" VALUES(118,'1.jpg',NULL,NULL,NULL,NULL,NULL,'7360be631cfa47179e444a4573f5859f','.jpg','image/jpeg',3.6,'/uploads/7360be631cfa47179e444a4573f5859f.jpg',NULL,'local',NULL,NULL,NULL,1552486072475,1552486072479);
INSERT INTO "upload_file" VALUES(119,'1C4EEDC2-FE9C-40B3-A2C9-A038873EE692-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'6b5f232ac3b94e41bc0ea6a4cc19a1c4','.jpeg','image/jpeg',10.61,'/uploads/6b5f232ac3b94e41bc0ea6a4cc19a1c4.jpeg',NULL,'local',NULL,NULL,NULL,1552486099981,1552486099987);
INSERT INTO "upload_file" VALUES(120,'2.jpg',NULL,NULL,NULL,NULL,NULL,'a0e518bdcd4b44ea967347c8243e627b','.jpg','image/jpeg',5.16,'/uploads/a0e518bdcd4b44ea967347c8243e627b.jpg',NULL,'local',NULL,NULL,NULL,1552486126127,1552486126130);
INSERT INTO "upload_file" VALUES(121,'03F55412-DE8A-4F83-AAA6-D67EE5CE48DA-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'8f89036c960b4d1db6c96fd0e4fcf44b','.jpeg','image/jpeg',14.88,'/uploads/8f89036c960b4d1db6c96fd0e4fcf44b.jpeg',NULL,'local',NULL,NULL,NULL,1552486168661,1552486168664);
INSERT INTO "upload_file" VALUES(122,'6h0HeYG_.jpg',NULL,NULL,NULL,NULL,NULL,'4d8da455f00a45cc8e5e1a4cec93f8bf','.jpg','image/jpeg',32.8,'/uploads/4d8da455f00a45cc8e5e1a4cec93f8bf.jpg',NULL,'local',NULL,NULL,NULL,1552486183311,1552486183316);
INSERT INTO "upload_file" VALUES(123,'7D3FA6C0-83C8-4834-B432-6C65ED4FD4C3-500w.jpeg',NULL,NULL,NULL,NULL,NULL,'2a0c08471b9a455cb16d6fc1c139e019','.jpeg','image/jpeg',61.53,'/uploads/2a0c08471b9a455cb16d6fc1c139e019.jpeg',NULL,'local',NULL,NULL,NULL,1552486190893,1552486190896);
INSERT INTO "upload_file" VALUES(124,'8.jpg',NULL,NULL,NULL,NULL,NULL,'3f3e183029654e5cb65477f611a43de1','.jpg','image/jpeg',5.81,'/uploads/3f3e183029654e5cb65477f611a43de1.jpg',NULL,'local',NULL,NULL,NULL,1552486201743,1552486201747);
INSERT INTO "upload_file" VALUES(125,'8B510E03-96BA-43F0-A85A-F38BB3005AF1-500w.jpeg',NULL,NULL,NULL,NULL,NULL,'baa9c9d0bbd24075a10c2a4654dfa4ab','.jpeg','image/jpeg',55.56,'/uploads/baa9c9d0bbd24075a10c2a4654dfa4ab.jpeg',NULL,'local',NULL,NULL,NULL,1552486219608,1552486219612);
INSERT INTO "upload_file" VALUES(126,'17 (1).jpg',NULL,NULL,NULL,NULL,NULL,'8408122737cb4618a475a0d4527cd594','.jpg','image/jpeg',3.2,'/uploads/8408122737cb4618a475a0d4527cd594.jpg',NULL,'local',NULL,NULL,NULL,1552486231299,1552486231304);
INSERT INTO "upload_file" VALUES(127,'18.jpg',NULL,NULL,NULL,NULL,NULL,'6a743db5fd784bee87915d8d326a1c62','.jpg','image/jpeg',4.34,'/uploads/6a743db5fd784bee87915d8d326a1c62.jpg',NULL,'local',NULL,NULL,NULL,1552486250932,1552486250935);
INSERT INTO "upload_file" VALUES(128,'21.jpg',NULL,NULL,NULL,NULL,NULL,'4cab75169c904a24be2d484d263d2f1e','.jpg','image/jpeg',3.47,'/uploads/4cab75169c904a24be2d484d263d2f1e.jpg',NULL,'local',NULL,NULL,NULL,1552486259194,1552486259199);
INSERT INTO "upload_file" VALUES(129,'22.jpg',NULL,NULL,NULL,NULL,NULL,'4cec26e0326047c0a690eeb13410ea7a','.jpg','image/jpeg',4.75,'/uploads/4cec26e0326047c0a690eeb13410ea7a.jpg',NULL,'local',NULL,NULL,NULL,1552486266357,1552486266361);
INSERT INTO "upload_file" VALUES(130,'26CFEFB3-21C8-49FC-8C19-8E6A62B6D2E0-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'f6b42ef1a2604e2cac9744eb41ba578b','.jpeg','image/jpeg',9.07,'/uploads/f6b42ef1a2604e2cac9744eb41ba578b.jpeg',NULL,'local',NULL,NULL,NULL,1552486277258,1552486277262);
INSERT INTO "upload_file" VALUES(131,'26.jpg',NULL,NULL,NULL,NULL,NULL,'5c3b4812c1a34c7ca4d4889d2c93d784','.jpg','image/jpeg',4.68,'/uploads/5c3b4812c1a34c7ca4d4889d2c93d784.jpg',NULL,'local',NULL,NULL,NULL,1552486293530,1552486293535);
INSERT INTO "upload_file" VALUES(132,'29.jpg',NULL,NULL,NULL,NULL,NULL,'b3957f8e200546f7a472a90f34d53e21','.jpg','image/jpeg',6.52,'/uploads/b3957f8e200546f7a472a90f34d53e21.jpg',NULL,'local',NULL,NULL,NULL,1552486301037,1552486301040);
INSERT INTO "upload_file" VALUES(133,'31.jpg',NULL,NULL,NULL,NULL,NULL,'904697174b3c48de943cd1e9f3c671e9','.jpg','image/jpeg',6.38,'/uploads/904697174b3c48de943cd1e9f3c671e9.jpg',NULL,'local',NULL,NULL,NULL,1552486318664,1552486318667);
INSERT INTO "upload_file" VALUES(134,'32.jpg',NULL,NULL,NULL,NULL,NULL,'71291239647d48a698dbdff2214236c8','.jpg','image/jpeg',5.24,'/uploads/71291239647d48a698dbdff2214236c8.jpg',NULL,'local',NULL,NULL,NULL,1552486325951,1552486325955);
INSERT INTO "upload_file" VALUES(135,'33.jpg',NULL,NULL,NULL,NULL,NULL,'37d2d966995f482a84a062ba22382322','.jpg','image/jpeg',5.11,'/uploads/37d2d966995f482a84a062ba22382322.jpg',NULL,'local',NULL,NULL,NULL,1552486336506,1552486336510);
INSERT INTO "upload_file" VALUES(136,'35.jpg',NULL,NULL,NULL,NULL,NULL,'698918331512445681e3f564959d2143','.jpg','image/jpeg',4.56,'/uploads/698918331512445681e3f564959d2143.jpg',NULL,'local',NULL,NULL,NULL,1552486344693,1552486344697);
INSERT INTO "upload_file" VALUES(137,'36.jpg',NULL,NULL,NULL,NULL,NULL,'f1c5ee5e03c3487cb62f680097ba77ae','.jpg','image/jpeg',4.74,'/uploads/f1c5ee5e03c3487cb62f680097ba77ae.jpg',NULL,'local',NULL,NULL,NULL,1552486773723,1552486773726);
INSERT INTO "upload_file" VALUES(138,'41.jpg',NULL,NULL,NULL,NULL,NULL,'2ae2f7e34b0a4b80b8b2b7917f5f183e','.jpg','image/jpeg',4.25,'/uploads/2ae2f7e34b0a4b80b8b2b7917f5f183e.jpg',NULL,'local',NULL,NULL,NULL,1552486780207,1552486780212);
INSERT INTO "upload_file" VALUES(139,'42.jpg',NULL,NULL,NULL,NULL,NULL,'4e741baab42d48cd954d247509a34f31','.jpg','image/jpeg',5.0,'/uploads/4e741baab42d48cd954d247509a34f31.jpg',NULL,'local',NULL,NULL,NULL,1552486785557,1552486785559);
INSERT INTO "upload_file" VALUES(140,'43 (1).jpg',NULL,NULL,NULL,NULL,NULL,'e368d18a4d0a4a91912874cf4dc769dd','.jpg','image/jpeg',3.9,'/uploads/e368d18a4d0a4a91912874cf4dc769dd.jpg',NULL,'local',NULL,NULL,NULL,1552486792905,1552486792908);
INSERT INTO "upload_file" VALUES(141,'43.jpg',NULL,NULL,NULL,NULL,NULL,'6c84394710c04f85aaf6d5e7e75cf803','.jpg','image/jpeg',4.96,'/uploads/6c84394710c04f85aaf6d5e7e75cf803.jpg',NULL,'local',NULL,NULL,NULL,1552486804023,1552486804027);
INSERT INTO "upload_file" VALUES(142,'44.jpg',NULL,NULL,NULL,NULL,NULL,'12266f6ee42640349f67562a5e04bb7c','.jpg','image/jpeg',3.54,'/uploads/12266f6ee42640349f67562a5e04bb7c.jpg',NULL,'local',NULL,NULL,NULL,1552486811491,1552486811493);
INSERT INTO "upload_file" VALUES(143,'46.jpg',NULL,NULL,NULL,NULL,NULL,'6ed96f3016754dbebb33aae965f870ab','.jpg','image/jpeg',4.82,'/uploads/6ed96f3016754dbebb33aae965f870ab.jpg',NULL,'local',NULL,NULL,NULL,1552486821112,1552486821117);
INSERT INTO "upload_file" VALUES(144,'47 (1).jpg',NULL,NULL,NULL,NULL,NULL,'12cff693ee43449fb684ac9cf0bb8b8f','.jpg','image/jpeg',4.45,'/uploads/12cff693ee43449fb684ac9cf0bb8b8f.jpg',NULL,'local',NULL,NULL,NULL,1552486832717,1552486832721);
INSERT INTO "upload_file" VALUES(145,'47.jpg',NULL,NULL,NULL,NULL,NULL,'beccdb7317cc448ca0e2e1e2aaaac79c','.jpg','image/jpeg',11.33,'/uploads/beccdb7317cc448ca0e2e1e2aaaac79c.jpg',NULL,'local',NULL,NULL,NULL,1552486841842,1552486841845);
INSERT INTO "upload_file" VALUES(146,'48.jpg',NULL,NULL,NULL,NULL,NULL,'b953521ed034488e914265abe7d31df3','.jpg','image/jpeg',3.77,'/uploads/b953521ed034488e914265abe7d31df3.jpg',NULL,'local',NULL,NULL,NULL,1552486850020,1552486850023);
INSERT INTO "upload_file" VALUES(147,'49.jpg',NULL,NULL,NULL,NULL,NULL,'5ae7dfafd7784a87b4edd60ce9a49a8d','.jpg','image/jpeg',4.29,'/uploads/5ae7dfafd7784a87b4edd60ce9a49a8d.jpg',NULL,'local',NULL,NULL,NULL,1552486860254,1552486860257);
INSERT INTO "upload_file" VALUES(148,'57.jpg',NULL,NULL,NULL,NULL,NULL,'6f2db1c508704ac3b1486d78de1d70c9','.jpg','image/jpeg',5.87,'/uploads/6f2db1c508704ac3b1486d78de1d70c9.jpg',NULL,'local',NULL,NULL,NULL,1552486866730,1552486866733);
INSERT INTO "upload_file" VALUES(149,'61.jpg',NULL,NULL,NULL,NULL,NULL,'d01f50af772b41f0bd289231df5c93c5','.jpg','image/jpeg',6.24,'/uploads/d01f50af772b41f0bd289231df5c93c5.jpg',NULL,'local',NULL,NULL,NULL,1552486874218,1552486874221);
INSERT INTO "upload_file" VALUES(150,'63.jpg',NULL,NULL,NULL,NULL,NULL,'9efb315f16684ceb9228e80095608c54','.jpg','image/jpeg',6.46,'/uploads/9efb315f16684ceb9228e80095608c54.jpg',NULL,'local',NULL,NULL,NULL,1552486885469,1552486885472);
INSERT INTO "upload_file" VALUES(151,'64.jpg',NULL,NULL,NULL,NULL,NULL,'99b633f2983747aebe0a8df659e3f9fe','.jpg','image/jpeg',9.38,'/uploads/99b633f2983747aebe0a8df659e3f9fe.jpg',NULL,'local',NULL,NULL,NULL,1552486891615,1552486891617);
INSERT INTO "upload_file" VALUES(152,'65.jpg',NULL,NULL,NULL,NULL,NULL,'48c69d7a1c5143fc928b71455bd23c6f','.jpg','image/jpeg',5.97,'/uploads/48c69d7a1c5143fc928b71455bd23c6f.jpg',NULL,'local',NULL,NULL,NULL,1552486910922,1552486910925);
INSERT INTO "upload_file" VALUES(153,'68.jpg',NULL,NULL,NULL,NULL,NULL,'b2ae251dfaed4458bf400d29b690650f','.jpg','image/jpeg',6.95,'/uploads/b2ae251dfaed4458bf400d29b690650f.jpg',NULL,'local',NULL,NULL,NULL,1552486925296,1552486925299);
INSERT INTO "upload_file" VALUES(154,'76.jpg',NULL,NULL,NULL,NULL,NULL,'d9d5b7bc76d24e5fa3c3d7db3d11ff18','.jpg','image/jpeg',4.69,'/uploads/d9d5b7bc76d24e5fa3c3d7db3d11ff18.jpg',NULL,'local',NULL,NULL,NULL,1552486964492,1552486964497);
INSERT INTO "upload_file" VALUES(155,'78.jpg',NULL,NULL,NULL,NULL,NULL,'07db9fb3ffdb4096b51ef54403df34e8','.jpg','image/jpeg',4.64,'/uploads/07db9fb3ffdb4096b51ef54403df34e8.jpg',NULL,'local',NULL,NULL,NULL,1552486971213,1552486971216);
INSERT INTO "upload_file" VALUES(156,'79.jpg',NULL,NULL,NULL,NULL,NULL,'40387009aecb47568fd484562130cdba','.jpg','image/jpeg',5.27,'/uploads/40387009aecb47568fd484562130cdba.jpg',NULL,'local',NULL,NULL,NULL,1552486978398,1552486978401);
INSERT INTO "upload_file" VALUES(157,'79.jpg',NULL,NULL,NULL,NULL,NULL,'4c81d486bed8444da5d7549beb28ad82','.jpg','image/jpeg',5.27,'/uploads/4c81d486bed8444da5d7549beb28ad82.jpg',NULL,'local',NULL,NULL,NULL,1552487031320,1552487031323);
INSERT INTO "upload_file" VALUES(158,'80.jpg',NULL,NULL,NULL,NULL,NULL,'858e41f89db1471496d90d6b1559fb5d','.jpg','image/jpeg',4.82,'/uploads/858e41f89db1471496d90d6b1559fb5d.jpg',NULL,'local',NULL,NULL,NULL,1552487037922,1552487037925);
INSERT INTO "upload_file" VALUES(159,'81.jpg',NULL,NULL,NULL,NULL,NULL,'31fa32373507400cbcd41ce0936b16c5','.jpg','image/jpeg',4.54,'/uploads/31fa32373507400cbcd41ce0936b16c5.jpg',NULL,'local',NULL,NULL,NULL,1552487044618,1552487044621);
INSERT INTO "upload_file" VALUES(160,'82.jpg',NULL,NULL,NULL,NULL,NULL,'b385a61171984a23aba27cce5a34b16a','.jpg','image/jpeg',6.29,'/uploads/b385a61171984a23aba27cce5a34b16a.jpg',NULL,'local',NULL,NULL,NULL,1552487051306,1552487051309);
INSERT INTO "upload_file" VALUES(161,'86.jpg',NULL,NULL,NULL,NULL,NULL,'49e42c764a7146c2bfc950b22efc8c97','.jpg','image/jpeg',5.43,'/uploads/49e42c764a7146c2bfc950b22efc8c97.jpg',NULL,'local',NULL,NULL,NULL,1552487058262,1552487058265);
INSERT INTO "upload_file" VALUES(162,'91 (1).jpg',NULL,NULL,NULL,NULL,NULL,'009669ab69804d7192ffe7d849a7b254','.jpg','image/jpeg',4.86,'/uploads/009669ab69804d7192ffe7d849a7b254.jpg',NULL,'local',NULL,NULL,NULL,1552487066063,1552487066066);
INSERT INTO "upload_file" VALUES(163,'95 (1).jpg',NULL,NULL,NULL,NULL,NULL,'55b13bca870d40f8a1555e72aab4d149','.jpg','image/jpeg',6.59,'/uploads/55b13bca870d40f8a1555e72aab4d149.jpg',NULL,'local',NULL,NULL,NULL,1552487083812,1552487083815);
INSERT INTO "upload_file" VALUES(164,'95.jpg',NULL,NULL,NULL,NULL,NULL,'e4174f8131db4e6285fe07ad8db05f1d','.jpg','image/jpeg',4.58,'/uploads/e4174f8131db4e6285fe07ad8db05f1d.jpg',NULL,'local',NULL,NULL,NULL,1552487100548,1552487100551);
INSERT INTO "upload_file" VALUES(165,'97.jpg',NULL,NULL,NULL,NULL,NULL,'62e77b52d6c740ce92455d494fa80e9c','.jpg','image/jpeg',4.41,'/uploads/62e77b52d6c740ce92455d494fa80e9c.jpg',NULL,'local',NULL,NULL,NULL,1552487108167,1552487108170);
INSERT INTO "upload_file" VALUES(166,'282A12CA-E0D7-4011-8BDD-1FAFAAB035F7-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'4271e7fedf4e4774a48b7caedfdccfd0','.jpeg','image/jpeg',6.37,'/uploads/4271e7fedf4e4774a48b7caedfdccfd0.jpeg',NULL,'local',NULL,NULL,NULL,1552487131008,1552487131011);
INSERT INTO "upload_file" VALUES(167,'A7299C8E-CEFC-47D9-939A-3C8CA0EA4D13-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'01940b20380843f09cf62feac2ad4ee1','.jpeg','image/jpeg',17.34,'/uploads/01940b20380843f09cf62feac2ad4ee1.jpeg',NULL,'local',NULL,NULL,NULL,1552487623353,1552487623357);
INSERT INTO "upload_file" VALUES(168,'AEF44435-B547-4B84-A2AE-887DFAEE6DDF-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'1591b45a290a4902b2216b105a3a15b6','.jpeg','image/jpeg',15.11,'/uploads/1591b45a290a4902b2216b105a3a15b6.jpeg',NULL,'local',NULL,NULL,NULL,1552487628201,1552487628204);
INSERT INTO "upload_file" VALUES(169,'B0298C36-9751-48EF-BE15-80FB9CD11143-500w.jpeg',NULL,NULL,NULL,NULL,NULL,'7aa91d545849491cb24f3840eb3a11c1','.jpeg','image/jpeg',48.03,'/uploads/7aa91d545849491cb24f3840eb3a11c1.jpeg',NULL,'local',NULL,NULL,NULL,1552487635135,1552487635138);
INSERT INTO "upload_file" VALUES(170,'BA0CB1F2-8C79-4376-B13B-DD5FB8772537-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'86438b567f79451cb3e65f43b12fb868','.jpeg','image/jpeg',15.05,'/uploads/86438b567f79451cb3e65f43b12fb868.jpeg',NULL,'local',NULL,NULL,NULL,1552487644311,1552487644314);
INSERT INTO "upload_file" VALUES(171,'dJj9Z8uq.jpg',NULL,NULL,NULL,NULL,NULL,'cfa6423926484aab84fdf4e57f445cea','.jpg','image/jpeg',42.5,'/uploads/cfa6423926484aab84fdf4e57f445cea.jpg',NULL,'local',NULL,NULL,NULL,1552487650493,1552487650495);
INSERT INTO "upload_file" VALUES(172,'e-3MyGW3.jpg',NULL,NULL,NULL,NULL,NULL,'eac763d49f20473c9fb8d4faaa827926','.jpg','image/jpeg',32.8,'/uploads/eac763d49f20473c9fb8d4faaa827926.jpg',NULL,'local',NULL,NULL,NULL,1552487658133,1552487658136);
INSERT INTO "upload_file" VALUES(173,'E0B4CAB3-F491-4322-BEF2-208B46748D4A-200w.jpeg',NULL,NULL,NULL,NULL,NULL,'ee9bc0b57dc046db83cd2b0c6fe152b7','.jpeg','image/jpeg',10.48,'/uploads/ee9bc0b57dc046db83cd2b0c6fe152b7.jpeg',NULL,'local',NULL,NULL,NULL,1552487665581,1552487665584);
INSERT INTO "upload_file" VALUES(174,'F6440FF2-AB6C-4E71-A57C-F2E79808EC82-500w.jpeg',NULL,NULL,NULL,NULL,NULL,'e0517434e9f24eb3ae77c887d9e82a45','.jpeg','image/jpeg',56.02,'/uploads/e0517434e9f24eb3ae77c887d9e82a45.jpeg',NULL,'local',NULL,NULL,NULL,1552487671461,1552487671464);
INSERT INTO "upload_file" VALUES(175,'GfWweiGR.jpg',NULL,NULL,NULL,NULL,NULL,'5c8d772694424da4961e879c5742f284','.jpg','image/jpeg',56.06,'/uploads/5c8d772694424da4961e879c5742f284.jpg',NULL,'local',NULL,NULL,NULL,1552487678195,1552487678198);
INSERT INTO "upload_file" VALUES(176,'gPZwCbdS.jpg',NULL,NULL,NULL,NULL,NULL,'291535c2461144e08775b4a264fa509f','.jpg','image/jpeg',32.8,'/uploads/291535c2461144e08775b4a264fa509f.jpg',NULL,'local',NULL,NULL,NULL,1552487685196,1552487685199);
INSERT INTO "upload_file" VALUES(177,'hKv3Fddh.jpg',NULL,NULL,NULL,NULL,NULL,'7d74e89a87c844239ac63da72cde5c02','.jpg','image/jpeg',480.9,'/uploads/7d74e89a87c844239ac63da72cde5c02.jpg',NULL,'local',NULL,NULL,NULL,1552487692674,1552487692677);
INSERT INTO "upload_file" VALUES(178,'L7wQctBt.jpg',NULL,NULL,NULL,NULL,NULL,'b3d1508e8fa0432086f066cee702677d','.jpg','image/jpeg',32.8,'/uploads/b3d1508e8fa0432086f066cee702677d.jpg',NULL,'local',NULL,NULL,NULL,1552487698629,1552487698634);
INSERT INTO "upload_file" VALUES(179,'L7wQctBt.jpg',NULL,NULL,NULL,NULL,NULL,'e3269e475f5f46adbb3a8785b5572b81','.jpg','image/jpeg',32.8,'/uploads/e3269e475f5f46adbb3a8785b5572b81.jpg',NULL,'local',NULL,NULL,NULL,1552487705112,1552487705115);
INSERT INTO "upload_file" VALUES(180,'MV5BMjA3NjYzMzE1MV5BMl5BanBnXkFtZTgwNTA4NDY4OTE@._V1_UX172_CR0,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'9a07581583114e01bde3a0ff1d0aa71b','.jpg','image/jpeg',9.04,'/uploads/9a07581583114e01bde3a0ff1d0aa71b.jpg',NULL,'local',NULL,NULL,NULL,1552487711689,1552487711694);
INSERT INTO "upload_file" VALUES(181,'MV5BMjE5ODk2NTI2Nl5BMl5BanBnXkFtZTgwNzIyMDA4MTE@._V1_UY256_CR6,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'36f48befbd2c46dabfbd34c07b8e7767','.jpg','image/jpeg',10.28,'/uploads/36f48befbd2c46dabfbd34c07b8e7767.jpg',NULL,'local',NULL,NULL,NULL,1552487718820,1552487718825);
INSERT INTO "upload_file" VALUES(182,'MV5BMjEzMjA0ODk1OF5BMl5BanBnXkFtZTcwMTA4ODM3OQ@@._V1_UY256_CR5,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'e1987dd1d34e450eb96c44ac2b1c2b33','.jpg','image/jpeg',7.82,'/uploads/e1987dd1d34e450eb96c44ac2b1c2b33.jpg',NULL,'local',NULL,NULL,NULL,1552487725977,1552487725983);
INSERT INTO "upload_file" VALUES(183,'MV5BMjUzZTJmZDItODRjYS00ZGRhLTg2NWQtOGE0YjJhNWVlMjNjXkEyXkFqcGdeQXVyMTg4NDI0NDM@._V1_UY256_CR42,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'53f52952b41143afba1a8d56a76abef8','.jpg','image/jpeg',7.72,'/uploads/53f52952b41143afba1a8d56a76abef8.jpg',NULL,'local',NULL,NULL,NULL,1552487736742,1552487736746);
INSERT INTO "upload_file" VALUES(184,'MV5BMTAyNTAzMTA4OTJeQTJeQWpwZ15BbWU3MDA4NDI2Njk@._V1_UX172_CR0,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'69d39e3b1b994947a3956282ddeed3d4','.jpg','image/jpeg',6.86,'/uploads/69d39e3b1b994947a3956282ddeed3d4.jpg',NULL,'local',NULL,NULL,NULL,1552487752796,1552487752800);
INSERT INTO "upload_file" VALUES(185,'MV5BMTkxODQwNTgxN15BMl5BanBnXkFtZTcwMjk2OTY1Ng@@._V1_UY256_CR7,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'b6512dcb221e4940abf12df0314753c4','.jpg','image/jpeg',7.68,'/uploads/b6512dcb221e4940abf12df0314753c4.jpg',NULL,'local',NULL,NULL,NULL,1552487761648,1552487761652);
INSERT INTO "upload_file" VALUES(186,'MV5BMTkzNjE5MzY5M15BMl5BanBnXkFtZTgwMDI5ODMxODE@._V1_UY256_CR98,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'19f605795bee4972b61002a3f49676a6','.jpg','image/jpeg',5.53,'/uploads/19f605795bee4972b61002a3f49676a6.jpg',NULL,'local',NULL,NULL,NULL,1552487784569,1552487784573);
INSERT INTO "upload_file" VALUES(187,'MV5BMTQwMDQ0NDk1OV5BMl5BanBnXkFtZTcwNDcxOTExNg@@._V1_UY256_CR2,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'838a36d843d24d55aa7b0c9ef81df4d4','.jpg','image/jpeg',11.52,'/uploads/838a36d843d24d55aa7b0c9ef81df4d4.jpg',NULL,'local',NULL,NULL,NULL,1552488855609,1552488855613);
INSERT INTO "upload_file" VALUES(188,'MV5BMTUxNTExMzUzOF5BMl5BanBnXkFtZTgwOTI1MjA3OTE@._V1_UX172_CR0,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'138d04bf892e41d0ad5d5240a8da84f2','.jpg','image/jpeg',9.21,'/uploads/138d04bf892e41d0ad5d5240a8da84f2.jpg',NULL,'local',NULL,NULL,NULL,1552488986007,1552488986010);
INSERT INTO "upload_file" VALUES(189,'MV5BODFjZTkwMjItYzRhMS00OWYxLWI3YTUtNWIzOWQ4Yjg4NGZiXkEyXkFqcGdeQXVyMTQ0ODAxNzE@._V1_UX172_CR0,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'a75d32e41ef4403987a548fa3b496b35','.jpg','image/jpeg',8.94,'/uploads/a75d32e41ef4403987a548fa3b496b35.jpg',NULL,'local',NULL,NULL,NULL,1552489004045,1552489004051);
INSERT INTO "upload_file" VALUES(190,'MV5BOWViYjUzOWMtMzRkZi00MjNkLTk4M2ItMTVkMDg5MzE2ZDYyXkEyXkFqcGdeQXVyODQwNjM3NDA@._V1_UY256_CR36,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'f156fc8303d042c0aa937246f44fe8d4','.jpg','image/jpeg',5.02,'/uploads/f156fc8303d042c0aa937246f44fe8d4.jpg',NULL,'local',NULL,NULL,NULL,1552489010709,1552489010712);
INSERT INTO "upload_file" VALUES(191,'MV5BOWViYjUzOWMtMzRkZi00MjNkLTk4M2ItMTVkMDg5MzE2ZDYyXkEyXkFqcGdeQXVyODQwNjM3NDA@._V1_UY256_CR36,0,172,256_AL_.jpg',NULL,NULL,NULL,NULL,NULL,'78111234bf864db48f4b080eeee35f86','.jpg','image/jpeg',5.02,'/uploads/78111234bf864db48f4b080eeee35f86.jpg',NULL,'local',NULL,NULL,NULL,1552489025433,1552489025437);
INSERT INTO "upload_file" VALUES(192,'n4Ngwvi7.jpg',NULL,NULL,NULL,NULL,NULL,'016b3f09c3d64d0e89fe00700ce3f39e','.jpg','image/jpeg',32.8,'/uploads/016b3f09c3d64d0e89fe00700ce3f39e.jpg',NULL,'local',NULL,NULL,NULL,1552489033047,1552489033051);
INSERT INTO "upload_file" VALUES(193,'N5PLzyan.jpg',NULL,NULL,NULL,NULL,NULL,'5bf44b356c0242b298c7504afcafb467','.jpg','image/jpeg',42.5,'/uploads/5bf44b356c0242b298c7504afcafb467.jpg',NULL,'local',NULL,NULL,NULL,1552489039388,1552489039391);
INSERT INTO "upload_file" VALUES(194,'N25WgvW_.png',NULL,NULL,NULL,NULL,NULL,'d4c6bb8a05314a62a1c2a9b52e2e1422','.png','image/png',116.75,'/uploads/d4c6bb8a05314a62a1c2a9b52e2e1422.png',NULL,'local',NULL,NULL,NULL,1552489054260,1552489054263);
INSERT INTO "upload_file" VALUES(195,'oedmUmVc.jpg',NULL,NULL,NULL,NULL,NULL,'0c0727d7a26649738a6293b1c8d2f277','.jpg','image/jpeg',42.5,'/uploads/0c0727d7a26649738a6293b1c8d2f277.jpg',NULL,'local',NULL,NULL,NULL,1552489060664,1552489060666);
INSERT INTO "upload_file" VALUES(196,'pexels-photo-61100.jpeg',NULL,NULL,NULL,NULL,NULL,'2fc9eee231ca427d8f4c4f430daf2f6e','.jpeg','image/jpeg',18.39,'/uploads/2fc9eee231ca427d8f4c4f430daf2f6e.jpeg',NULL,'local',NULL,NULL,NULL,1552489067069,1552489067071);
INSERT INTO "upload_file" VALUES(197,'pexels-photo-220453.jpeg',NULL,NULL,NULL,NULL,NULL,'51813299b2f94d5d9f188d312112fd15','.jpeg','image/jpeg',8.61,'/uploads/51813299b2f94d5d9f188d312112fd15.jpeg',NULL,'local',NULL,NULL,NULL,1552489107050,1552489107054);
INSERT INTO "upload_file" VALUES(198,'pexels-photo-247885.jpeg',NULL,NULL,NULL,NULL,NULL,'a0777a01756a4f2196fe47b694b70e89','.jpeg','image/jpeg',27.79,'/uploads/a0777a01756a4f2196fe47b694b70e89.jpeg',NULL,'local',NULL,NULL,NULL,1552489131502,1552489131504);
INSERT INTO "upload_file" VALUES(199,'pexels-photo-355164.jpeg',NULL,NULL,NULL,NULL,NULL,'90fc7420b7974f92a5840cda34601b80','.jpeg','image/jpeg',16.4,'/uploads/90fc7420b7974f92a5840cda34601b80.jpeg',NULL,'local',NULL,NULL,NULL,1552489140661,1552489140665);
INSERT INTO "upload_file" VALUES(200,'pexels-photo-415829.jpeg',NULL,NULL,NULL,NULL,NULL,'147b1af63a974781adec49df3f632090','.jpeg','image/jpeg',12.41,'/uploads/147b1af63a974781adec49df3f632090.jpeg',NULL,'local',NULL,NULL,NULL,1552489149463,1552489149466);
INSERT INTO "upload_file" VALUES(201,'pexels-photo-614810.jpeg',NULL,NULL,NULL,NULL,NULL,'1d6781c15d9b466988dca19f4ccb93fe','.jpeg','image/jpeg',10.43,'/uploads/1d6781c15d9b466988dca19f4ccb93fe.jpeg',NULL,'local',NULL,NULL,NULL,1552489156421,1552489156425);
INSERT INTO "upload_file" VALUES(202,'photo-1438761681033-6461ffad8d80.jpeg',NULL,NULL,NULL,NULL,NULL,'7a88543f039a4a87a634805491e609d6','.jpeg','image/jpeg',6.46,'/uploads/7a88543f039a4a87a634805491e609d6.jpeg',NULL,'local',NULL,NULL,NULL,1552489170260,1552489170263);
INSERT INTO "upload_file" VALUES(203,'photo-1456327102063-fb5054efe647.jpeg',NULL,NULL,NULL,NULL,NULL,'60954239cc7c46a5aeaf7bd1aac3d652','.jpeg','image/jpeg',8.26,'/uploads/60954239cc7c46a5aeaf7bd1aac3d652.jpeg',NULL,'local',NULL,NULL,NULL,1552489177628,1552489177632);
INSERT INTO "upload_file" VALUES(204,'photo-1463453091185-61582044d556.jpeg',NULL,NULL,NULL,NULL,NULL,'8c827996abcb4add863b83d81a524672','.jpeg','image/jpeg',12.56,'/uploads/8c827996abcb4add863b83d81a524672.jpeg',NULL,'local',NULL,NULL,NULL,1552489185638,1552489185641);
INSERT INTO "upload_file" VALUES(205,'photo-1476493279419-b785d41e38d8.jpeg',NULL,NULL,NULL,NULL,NULL,'c386d14e109d4640a2fadbceaf68b86d','.jpeg','image/jpeg',8.63,'/uploads/c386d14e109d4640a2fadbceaf68b86d.jpeg',NULL,'local',NULL,NULL,NULL,1552489192303,1552489192307);
INSERT INTO "upload_file" VALUES(206,'photo-1488426862026-3ee34a7d66df.jpeg',NULL,NULL,NULL,NULL,NULL,'bfe030a2c902495ea12eaf7f54bbba86','.jpeg','image/jpeg',17.73,'/uploads/bfe030a2c902495ea12eaf7f54bbba86.jpeg',NULL,'local',NULL,NULL,NULL,1552489200320,1552489200324);
INSERT INTO "upload_file" VALUES(207,'photo-1493666438817-866a91353ca9.jpeg',NULL,NULL,NULL,NULL,NULL,'3f3a08cf3c2d41d6b8af5244ea02e03e','.jpeg','image/jpeg',9.89,'/uploads/3f3a08cf3c2d41d6b8af5244ea02e03e.jpeg',NULL,'local',NULL,NULL,NULL,1552489211796,1552489211801);
INSERT INTO "upload_file" VALUES(208,'photo-1494790108377-be9c29b29330.jpeg',NULL,NULL,NULL,NULL,NULL,'44021421d8174e67b905526455035cd3','.jpeg','image/jpeg',11.76,'/uploads/44021421d8174e67b905526455035cd3.jpeg',NULL,'local',NULL,NULL,NULL,1552489218141,1552489218146);
INSERT INTO "upload_file" VALUES(209,'photo-1496081081095-d32308dd6206.jpeg',NULL,NULL,NULL,NULL,NULL,'af205ba1af1740768395258c96db0546','.jpeg','image/jpeg',11.45,'/uploads/af205ba1af1740768395258c96db0546.jpeg',NULL,'local',NULL,NULL,NULL,1552489231624,1552489231628);
INSERT INTO "upload_file" VALUES(210,'photo-1498529605908-f357a9af7bf5.jpeg',NULL,NULL,NULL,NULL,NULL,'c4c0247b9690426aaa62f545bcbaf2cf','.jpeg','image/jpeg',7.32,'/uploads/c4c0247b9690426aaa62f545bcbaf2cf.jpeg',NULL,'local',NULL,NULL,NULL,1552489238087,1552489238090);
INSERT INTO "upload_file" VALUES(211,'photo-1502378735452-bc7d86632805.jpeg',NULL,NULL,NULL,NULL,NULL,'86fb6b18dfd84817941eb3c9411bacf5','.jpeg','image/jpeg',9.59,'/uploads/86fb6b18dfd84817941eb3c9411bacf5.jpeg',NULL,'local',NULL,NULL,NULL,1552489244851,1552489244855);
INSERT INTO "upload_file" VALUES(212,'photo-1502720705749-871143f0e671.jpeg',NULL,NULL,NULL,NULL,NULL,'f68d55b7940f4493b715c607517d886d','.jpeg','image/jpeg',13.03,'/uploads/f68d55b7940f4493b715c607517d886d.jpeg',NULL,'local',NULL,NULL,NULL,1552489250531,1552489250536);
INSERT INTO "upload_file" VALUES(213,'photo-1506085452766-c330853bea50.jpeg',NULL,NULL,NULL,NULL,NULL,'67b2ac8db706436b80b9852ee86ae477','.jpeg','image/jpeg',5.77,'/uploads/67b2ac8db706436b80b9852ee86ae477.jpeg',NULL,'local',NULL,NULL,NULL,1552489255374,1552489255378);
INSERT INTO "upload_file" VALUES(214,'photo-1506085452766-c330853bea50.jpeg',NULL,NULL,NULL,NULL,NULL,'dff0f166718546919cfd99280c8042f1','.jpeg','image/jpeg',5.77,'/uploads/dff0f166718546919cfd99280c8042f1.jpeg',NULL,'local',NULL,NULL,NULL,1552489262256,1552489262260);
INSERT INTO "upload_file" VALUES(215,'photo-1506794778202-cad84cf45f1d.jpeg',NULL,NULL,NULL,NULL,NULL,'99a13c6b03014f1ca13513d08a74f090','.jpeg','image/jpeg',15.47,'/uploads/99a13c6b03014f1ca13513d08a74f090.jpeg',NULL,'local',NULL,NULL,NULL,1552489269245,1552489269248);
INSERT INTO "upload_file" VALUES(216,'photo-1506803682981-6e718a9dd3ee.jpeg',NULL,NULL,NULL,NULL,NULL,'f0c197304cd546fc805f770553733f88','.jpeg','image/jpeg',6.52,'/uploads/f0c197304cd546fc805f770553733f88.jpeg',NULL,'local',NULL,NULL,NULL,1552489274354,1552489274357);
INSERT INTO "upload_file" VALUES(217,'photo-1507003211169-0a1dd7228f2d.jpeg',NULL,NULL,NULL,NULL,NULL,'70dd0d4d9eba45319e186bac2e171ca3','.jpeg','image/jpeg',11.14,'/uploads/70dd0d4d9eba45319e186bac2e171ca3.jpeg',NULL,'local',NULL,NULL,NULL,1552489286097,1552489286101);
INSERT INTO "upload_file" VALUES(218,'project_1_IoT.jpg',NULL,NULL,NULL,NULL,NULL,'7f512d8d52e3c1f66cb6821bcd6be6ed','.jpg','image/jpeg',91.4,'/uploads/project_1_IoT.jpg',NULL,'local',NULL,NULL,NULL,1626149624086,1626149624086);
INSERT INTO "upload_file" VALUES(219,'project_2_education.jpg',NULL,NULL,NULL,NULL,NULL,'f23e421cc87ebdf4567bb002e486301b','.jpg','image/jpeg',77.6,'/uploads/project_2_education.jpg',NULL,'local',NULL,NULL,NULL,1626149681367,1626149695039);
INSERT INTO "upload_file" VALUES(220,'project_3_finance.jpg',NULL,NULL,NULL,NULL,NULL,'034fb4a40236458bdfb8bd4d2da21a15','.jpg','image/jpeg',131.0,'/uploads/project_3_finance.jpg',NULL,'local',NULL,NULL,NULL,1626149706689,1626149720862);
INSERT INTO "upload_file" VALUES(221,'project_4_japan_real_estate.jpg',NULL,NULL,NULL,NULL,NULL,'a88f0df91e30840738c744c52e272973','.jpg','image/jpeg',226.0,'/uploads/project_4_japan_real_estate.jpg',NULL,'local',NULL,NULL,NULL,1626149732422,1626149745677);
INSERT INTO "upload_file" VALUES(222,'project_5_natural_gas.jpg',NULL,NULL,NULL,NULL,NULL,'a26531ce719a44c44620cfeeb2fb7957','.jpg','image/jpeg',206.0,'/uploads/project_5_natural_gas.jpg',NULL,'local',NULL,NULL,NULL,1626149756170,1626149766832);
INSERT INTO "upload_file" VALUES(223,'project_6_solar_energy.jpg',NULL,NULL,NULL,NULL,NULL,'29a1afeae33ab7a5fc7dc78ef682b09b','.jpg','image/jpeg',187.0,'/uploads/project_6_solar_energy.jpg',NULL,'local',NULL,NULL,NULL,1626149778364,1626149789800);
INSERT INTO "upload_file" VALUES(224,'project_7_wind_energy.jpg',NULL,NULL,NULL,NULL,NULL,'b06e721c33f8184b2d782a999da1a851','.jpg','image/jpeg',125.0,'/uploads/project_7_wind_energy.jpg',NULL,'local',NULL,NULL,NULL,1626149800877,1626149813161);
INSERT INTO "upload_file" VALUES(225,'project_2_education_4.jpg',NULL,NULL,NULL,NULL,NULL,'2f5777eaa22c8bb467561f192dca52a5','.jpg','image/jpeg',127.54,'/uploads/project_2_education_4.jpg',NULL,'local',NULL,NULL,NULL,1626241114393,1626241114393);
INSERT INTO "upload_file" VALUES(226,'project_2_education_3.jpg',NULL,NULL,NULL,NULL,NULL,'f086549d15d1ab91636bc118bbb8f93d','.jpg','image/jpeg',111.89,'/uploads/project_2_education_3.jpg',NULL,'local',NULL,NULL,NULL,1626241103428,1626241103428);
INSERT INTO "upload_file" VALUES(227,'project_2_education_2.jpg',NULL,NULL,NULL,NULL,NULL,'99c4686e8cca88229b16d073c5f41b92','.jpg','image/jpeg',143.16,'/uploads/project_2_education_2.jpg',NULL,'local',NULL,NULL,NULL,1626241089607,1626241089607);
INSERT INTO "upload_file" VALUES(228,'project_1_IoT_4.jpg',NULL,NULL,NULL,NULL,NULL,'53ae2ce2372dc7c76db3d325bc813700','.jpg','image/jpeg',160.62,'/uploads/project_1_IoT_4.jpg',NULL,'local',NULL,NULL,NULL,1626240731723,1626240731723);
INSERT INTO "upload_file" VALUES(229,'project_1_IoT_3.jpg',NULL,NULL,NULL,NULL,NULL,'21729fcc236079b43f107fb723a104c9','.jpg','image/jpeg',120.0,'/uploads/project_1_IoT_3.jpg',NULL,'local',NULL,NULL,NULL,1626240512013,1626240512013);
INSERT INTO "upload_file" VALUES(230,'project_1_IoT_2.jpg',NULL,NULL,NULL,NULL,NULL,'66ee0d5e5376de14ae239993a4c83fcc','.jpg','image/jpeg',157.0,'/uploads/project_1_IoT_2.jpg',NULL,'local',NULL,NULL,NULL,1626240330690,1626240330690);
INSERT INTO "upload_file" VALUES(231,'project_3_finance_4.jpg',NULL,NULL,NULL,NULL,NULL,'f96e6d7f6a684d3ea7ffb584c5487205','.jpg','image/jpeg',98.25,'/uploads/project_3_finance_4.jpg',NULL,'local',NULL,NULL,NULL,1626241451297,1626241451297);
INSERT INTO "upload_file" VALUES(232,'project_3_finance_3.jpg',NULL,NULL,NULL,NULL,NULL,'c8eeee423d695232b6de6a8bb9a12b68','.jpg','image/jpeg',160.07,'/uploads/project_3_finance_3.jpg',NULL,'local',NULL,NULL,NULL,1626241340053,1626241340053);
INSERT INTO "upload_file" VALUES(233,'project_3_finance_2.jpg',NULL,NULL,NULL,NULL,NULL,'090fdb62e5d695d00f94fc0ea5242b5e','.jpg','image/jpeg',90.74,'/uploads/project_3_finance_2.jpg',NULL,'local',NULL,NULL,NULL,1626241241875,1626241241875);
INSERT INTO "upload_file" VALUES(234,'project_4_japan_real_estate_4.jpg',NULL,NULL,NULL,NULL,NULL,'fa98ecda7af768824ed5780791701c2e','.jpg','image/jpeg',260.42,'/uploads/project_4_japan_real_estate_4.jpg',NULL,'local',NULL,NULL,NULL,1626242289228,1626242289228);
INSERT INTO "upload_file" VALUES(235,'project_4_japan_real_estate_3.jpg',NULL,NULL,NULL,NULL,NULL,'662b61490e396a6c4146b4a87df2f29c','.jpg','image/jpeg',318.79,'/uploads/project_4_japan_real_estate_3.jpg',NULL,'local',NULL,NULL,NULL,1626242197895,1626242197895);
INSERT INTO "upload_file" VALUES(236,'project_4_japan_real_estate_2.jpg',NULL,NULL,NULL,NULL,NULL,'868953bc85c77cb430cfc94a45a56f8f','.jpg','image/jpeg',242.98,'/uploads/project_4_japan_real_estate_2.jpg',NULL,'local',NULL,NULL,NULL,1626242092509,1626242092509);
INSERT INTO "upload_file" VALUES(237,'project_5_natural_gas_4.jpg',NULL,NULL,NULL,NULL,NULL,'7690d5bd3af42836f05948de972d52fb','.jpg','image/jpeg',123.14,'/uploads/project_5_natural_gas_4.jpg',NULL,'local',NULL,NULL,NULL,1626242629495,1626242629495);
INSERT INTO "upload_file" VALUES(238,'project_5_natural_gas_3.jpg',NULL,NULL,NULL,NULL,NULL,'662b61490e396a6c4146b4a87df2f29c','.jpg','image/jpeg',88.64,'/uploads/project_5_natural_gas_3.jpg',NULL,'local',NULL,NULL,NULL,1626242497158,1626242497158);
INSERT INTO "upload_file" VALUES(239,'project_5_natural_gas_2.jpg',NULL,NULL,NULL,NULL,NULL,'74bdd5c8184e657a011262544dd805f0','.jpg','image/jpeg',156.87,'/uploads/project_5_natural_gas_2.jpg',NULL,'local',NULL,NULL,NULL,1626242403187,1626242403187);
INSERT INTO "upload_file" VALUES(240,'project_6_solar_energy_4.jpg',NULL,NULL,NULL,NULL,NULL,'d378ffd2aa90eec5cda523ab978e1465','.jpg','image/jpeg',190.32,'/uploads/project_6_solar_energy_4.jpg',NULL,'local',NULL,NULL,NULL,1626242942608,1626242942608);
INSERT INTO "upload_file" VALUES(241,'project_6_solar_energy_3.jpg',NULL,NULL,NULL,NULL,NULL,'926efa08c61c672b02fe29a8eb280e18','.jpg','image/jpeg',121.35,'/uploads/project_6_solar_energy_3.jpg',NULL,'local',NULL,NULL,NULL,1626242832714,1626242832714);
INSERT INTO "upload_file" VALUES(242,'project_6_solar_energy_2.jpg',NULL,NULL,NULL,NULL,NULL,'4651ecbc6ece0b6279aefdc6394d0429','.jpg','image/jpeg',174.18,'/uploads/project_6_solar_energy_2.jpg',NULL,'local',NULL,NULL,NULL,1626242737232,1626242737232);
INSERT INTO "upload_file" VALUES(243,'project_7_wind_energy_4.jpg',NULL,NULL,NULL,NULL,NULL,'3b55e24add80b21810372a770c5a5dbc','.jpg','image/jpeg',144.57,'/uploads/project_7_wind_energy_4.jpg',NULL,'local',NULL,NULL,NULL,1626243445083,1626243445083);
INSERT INTO "upload_file" VALUES(244,'project_7_wind_energy_3.jpg',NULL,NULL,NULL,NULL,NULL,'814d4d0e2dd547e4026e22336daa010d','.jpg','image/jpeg',133.86,'/uploads/project_7_wind_energy_3.jpg',NULL,'local',NULL,NULL,NULL,1626243379241,1626243379241);
INSERT INTO "upload_file" VALUES(245,'project_7_wind_energy_2.jpg',NULL,NULL,NULL,NULL,NULL,'4959c933813d10e6c5f8799cb3e94b55','.jpg','image/jpeg',127.18,'/uploads/project_7_wind_energy_2.jpg',NULL,'local',NULL,NULL,NULL,1626243206808,1626243206808);
CREATE TABLE `upload_file_morph` (`id` integer not null primary key autoincrement, `upload_file_id` integer null, `related_id` integer null, `related_type` text null, `field` text null, `order` integer null);
INSERT INTO "upload_file_morph" VALUES(117,117,1,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(118,118,2,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(119,119,3,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(120,120,4,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(121,121,5,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(122,122,6,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(123,123,7,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(124,124,8,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(125,125,9,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(126,126,10,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(127,127,11,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(128,128,12,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(129,129,13,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(130,130,14,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(131,131,15,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(132,132,16,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(133,133,17,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(134,134,18,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(135,135,19,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(136,136,20,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(137,137,21,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(138,138,22,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(139,139,23,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(140,140,24,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(141,141,25,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(142,142,26,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(143,143,27,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(144,144,28,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(145,145,29,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(146,146,30,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(147,147,31,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(148,148,32,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(149,149,33,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(150,150,34,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(151,151,35,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(152,152,37,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(153,153,36,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(154,154,38,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(155,155,39,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(156,156,40,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(157,157,41,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(158,158,42,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(159,159,43,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(160,160,44,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(161,161,45,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(162,162,46,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(163,163,47,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(164,164,48,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(165,165,49,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(166,166,50,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(167,167,51,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(168,168,52,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(169,169,53,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(170,170,54,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(171,171,55,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(172,172,56,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(173,173,57,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(174,174,58,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(175,175,59,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(176,176,60,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(177,177,61,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(178,178,62,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(180,180,64,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(181,181,65,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(182,182,66,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(183,183,67,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(184,184,68,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(185,185,69,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(186,186,70,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(187,187,63,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(188,188,71,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(189,189,72,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(190,190,73,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(191,191,75,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(192,192,76,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(193,193,77,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(194,194,78,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(195,195,79,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(196,196,80,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(197,197,81,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(198,198,82,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(199,199,83,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(200,200,84,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(201,201,85,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(202,202,86,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(203,203,87,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(204,204,88,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(205,205,89,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(206,206,90,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(207,207,91,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(208,208,92,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(209,209,93,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(210,210,94,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(211,211,96,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(212,212,95,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(213,213,97,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(214,214,98,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(215,215,99,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(216,216,100,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(217,217,101,'users-permissions_user','picture',NULL);
INSERT INTO "upload_file_morph" VALUES(502,218,1,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(503,219,2,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(504,220,3,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(505,221,4,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(506,222,5,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(507,223,6,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(508,224,7,'projects','cover',1);
INSERT INTO "upload_file_morph" VALUES(509,228,1,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(510,229,1,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(511,230,1,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(512,225,2,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(513,226,2,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(514,227,2,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(515,231,3,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(516,232,3,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(517,233,3,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(518,234,4,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(519,235,4,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(520,236,4,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(521,237,5,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(522,238,5,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(523,239,5,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(524,240,6,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(525,241,6,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(526,242,6,'projects','cover',2);
INSERT INTO "upload_file_morph" VALUES(527,243,7,'projects','cover',4);
INSERT INTO "upload_file_morph" VALUES(528,244,7,'projects','cover',3);
INSERT INTO "upload_file_morph" VALUES(529,245,7,'projects','cover',2);
CREATE TABLE `users-permissions_permission` (`id` integer not null primary key autoincrement, `type` varchar(255) not null, `controller` varchar(255) not null, `action` varchar(255) not null, `enabled` boolean not null, `policy` varchar(255) null, `role` integer null, `created_by` integer null, `updated_by` integer null);
INSERT INTO "users-permissions_permission" VALUES(1,'application','category','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(2,'application','category','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(3,'application','category','count',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(4,'application','category','create',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(5,'application','category','update',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(42,'email','email','send',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(60,'upload','upload','upload',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(62,'upload','upload','getsettings',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(63,'upload','upload','updatesettings',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(64,'upload','upload','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(65,'upload','upload','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(66,'upload','upload','count',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(67,'upload','upload','destroy',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(68,'upload','upload','search',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(69,'users-permissions','auth','callback',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(71,'users-permissions','auth','connect',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(72,'users-permissions','auth','forgotpassword',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(73,'users-permissions','auth','register',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(74,'users-permissions','auth','emailconfirmation',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(75,'users-permissions','user','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(76,'users-permissions','user','me',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(77,'users-permissions','user','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(78,'users-permissions','user','create',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(79,'users-permissions','user','update',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(80,'users-permissions','user','destroy',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(81,'users-permissions','user','destroyall',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(82,'users-permissions','userspermissions','createrole',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(84,'users-permissions','userspermissions','deleterole',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(85,'users-permissions','userspermissions','getpermissions',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(86,'users-permissions','userspermissions','getpolicies',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(87,'users-permissions','userspermissions','getrole',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(88,'users-permissions','userspermissions','getroles',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(89,'users-permissions','userspermissions','getroutes',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(90,'users-permissions','userspermissions','index',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(92,'users-permissions','userspermissions','searchusers',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(93,'users-permissions','userspermissions','updaterole',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(94,'users-permissions','userspermissions','getemailtemplate',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(95,'users-permissions','userspermissions','updateemailtemplate',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(96,'users-permissions','userspermissions','getadvancedsettings',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(97,'users-permissions','userspermissions','updateadvancedsettings',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(98,'users-permissions','userspermissions','getproviders',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(99,'users-permissions','userspermissions','updateproviders',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(100,'application','category','find',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(101,'application','category','findone',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(102,'application','category','count',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(103,'application','category','create',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(104,'application','category','update',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(141,'email','email','send',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(159,'upload','upload','upload',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(161,'upload','upload','getsettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(162,'upload','upload','updatesettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(163,'upload','upload','find',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(164,'upload','upload','findone',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(165,'upload','upload','count',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(166,'upload','upload','destroy',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(167,'upload','upload','search',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(168,'users-permissions','auth','callback',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(170,'users-permissions','auth','connect',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(171,'users-permissions','auth','forgotpassword',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(172,'users-permissions','auth','register',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(173,'users-permissions','auth','emailconfirmation',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(174,'users-permissions','user','find',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(175,'users-permissions','user','me',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(176,'users-permissions','user','findone',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(177,'users-permissions','user','create',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(178,'users-permissions','user','update',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(179,'users-permissions','user','destroy',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(180,'users-permissions','user','destroyall',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(181,'users-permissions','userspermissions','createrole',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(183,'users-permissions','userspermissions','deleterole',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(184,'users-permissions','userspermissions','getpermissions',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(185,'users-permissions','userspermissions','getpolicies',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(186,'users-permissions','userspermissions','getrole',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(187,'users-permissions','userspermissions','getroles',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(188,'users-permissions','userspermissions','getroutes',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(189,'users-permissions','userspermissions','index',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(191,'users-permissions','userspermissions','searchusers',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(192,'users-permissions','userspermissions','updaterole',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(193,'users-permissions','userspermissions','getemailtemplate',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(194,'users-permissions','userspermissions','updateemailtemplate',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(195,'users-permissions','userspermissions','getadvancedsettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(196,'users-permissions','userspermissions','updateadvancedsettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(197,'users-permissions','userspermissions','getproviders',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(198,'users-permissions','userspermissions','updateproviders',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(199,'application','category','find',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(200,'application','category','findone',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(201,'application','category','count',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(202,'application','category','create',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(203,'application','category','update',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(240,'email','email','send',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(258,'upload','upload','upload',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(260,'upload','upload','getsettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(261,'upload','upload','updatesettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(262,'upload','upload','find',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(263,'upload','upload','findone',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(264,'upload','upload','count',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(265,'upload','upload','destroy',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(266,'upload','upload','search',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(267,'users-permissions','auth','callback',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(269,'users-permissions','auth','connect',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(270,'users-permissions','auth','forgotpassword',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(271,'users-permissions','auth','register',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(272,'users-permissions','auth','emailconfirmation',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(273,'users-permissions','user','find',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(274,'users-permissions','user','me',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(275,'users-permissions','user','findone',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(276,'users-permissions','user','create',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(277,'users-permissions','user','update',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(278,'users-permissions','user','destroy',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(279,'users-permissions','user','destroyall',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(280,'users-permissions','userspermissions','createrole',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(282,'users-permissions','userspermissions','deleterole',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(283,'users-permissions','userspermissions','getpermissions',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(284,'users-permissions','userspermissions','getpolicies',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(285,'users-permissions','userspermissions','getrole',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(286,'users-permissions','userspermissions','getroles',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(287,'users-permissions','userspermissions','getroutes',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(288,'users-permissions','userspermissions','index',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(290,'users-permissions','userspermissions','searchusers',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(291,'users-permissions','userspermissions','updaterole',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(292,'users-permissions','userspermissions','getemailtemplate',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(293,'users-permissions','userspermissions','updateemailtemplate',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(294,'users-permissions','userspermissions','getadvancedsettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(295,'users-permissions','userspermissions','updateadvancedsettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(296,'users-permissions','userspermissions','getproviders',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(297,'users-permissions','userspermissions','updateproviders',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(298,'application','category','delete',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(316,'documentation','documentation','getinfos',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(317,'documentation','documentation','index',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(318,'documentation','documentation','loginview',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(319,'documentation','documentation','login',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(320,'documentation','documentation','regeneratedoc',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(321,'documentation','documentation','deletedoc',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(322,'documentation','documentation','updatesettings',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(323,'application','category','delete',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(341,'documentation','documentation','getinfos',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(342,'documentation','documentation','index',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(343,'documentation','documentation','loginview',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(344,'documentation','documentation','login',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(345,'documentation','documentation','regeneratedoc',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(346,'documentation','documentation','deletedoc',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(347,'documentation','documentation','updatesettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(348,'application','category','delete',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(366,'documentation','documentation','getinfos',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(367,'documentation','documentation','index',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(368,'documentation','documentation','loginview',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(369,'documentation','documentation','login',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(370,'documentation','documentation','regeneratedoc',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(371,'documentation','documentation','deletedoc',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(372,'documentation','documentation','updatesettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(376,'content-type-builder','componentcategories','editcategory',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(377,'content-type-builder','componentcategories','deletecategory',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(378,'content-type-builder','components','getcomponents',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(379,'content-type-builder','components','getcomponent',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(380,'content-type-builder','components','createcomponent',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(381,'content-type-builder','components','updatecomponent',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(382,'content-type-builder','components','deletecomponent',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(383,'content-type-builder','connections','getconnections',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(384,'content-type-builder','contenttypes','getcontenttypes',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(385,'content-type-builder','contenttypes','getcontenttype',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(386,'content-type-builder','contenttypes','createcontenttype',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(387,'content-type-builder','contenttypes','updatecontenttype',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(388,'content-type-builder','contenttypes','deletecontenttype',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(389,'users-permissions','auth','sendemailconfirmation',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(393,'content-type-builder','componentcategories','editcategory',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(394,'content-type-builder','componentcategories','deletecategory',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(395,'content-type-builder','components','getcomponents',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(396,'content-type-builder','components','getcomponent',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(397,'content-type-builder','components','createcomponent',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(398,'content-type-builder','components','updatecomponent',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(399,'content-type-builder','components','deletecomponent',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(400,'content-type-builder','connections','getconnections',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(401,'content-type-builder','contenttypes','getcontenttypes',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(402,'content-type-builder','contenttypes','getcontenttype',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(403,'content-type-builder','contenttypes','createcontenttype',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(404,'content-type-builder','contenttypes','updatecontenttype',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(405,'content-type-builder','contenttypes','deletecontenttype',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(406,'users-permissions','auth','sendemailconfirmation',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(410,'content-type-builder','componentcategories','editcategory',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(411,'content-type-builder','componentcategories','deletecategory',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(412,'content-type-builder','components','getcomponents',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(413,'content-type-builder','components','getcomponent',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(414,'content-type-builder','components','createcomponent',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(415,'content-type-builder','components','updatecomponent',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(416,'content-type-builder','components','deletecomponent',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(417,'content-type-builder','connections','getconnections',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(418,'content-type-builder','contenttypes','getcontenttypes',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(419,'content-type-builder','contenttypes','getcontenttype',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(420,'content-type-builder','contenttypes','createcontenttype',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(421,'content-type-builder','contenttypes','updatecontenttype',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(422,'content-type-builder','contenttypes','deletecontenttype',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(423,'users-permissions','auth','sendemailconfirmation',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(433,'content-type-builder','builder','getreservednames',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(434,'content-type-builder','builder','getreservednames',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(435,'content-type-builder','builder','getreservednames',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(439,'users-permissions','auth','resetpassword',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(440,'users-permissions','auth','resetpassword',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(441,'users-permissions','auth','resetpassword',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(442,'users-permissions','user','count',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(443,'users-permissions','user','count',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(444,'users-permissions','user','count',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(445,'application','history','count',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(446,'application','history','count',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(447,'application','history','count',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(448,'application','history','create',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(449,'application','history','create',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(450,'application','history','create',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(451,'application','history','delete',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(452,'application','history','delete',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(453,'application','history','delete',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(454,'application','history','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(455,'application','history','find',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(456,'application','history','find',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(457,'application','history','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(458,'application','history','findone',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(459,'application','history','findone',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(460,'application','history','update',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(461,'application','history','update',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(462,'application','history','update',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(505,'content-manager','collection-types','bulkdelete',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(506,'content-manager','collection-types','bulkdelete',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(507,'content-manager','collection-types','bulkdelete',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(508,'content-manager','collection-types','create',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(509,'content-manager','collection-types','create',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(510,'content-manager','collection-types','create',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(511,'content-manager','collection-types','delete',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(512,'content-manager','collection-types','delete',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(513,'content-manager','collection-types','delete',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(514,'content-manager','collection-types','find',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(515,'content-manager','collection-types','find',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(516,'content-manager','collection-types','find',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(517,'content-manager','collection-types','findone',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(518,'content-manager','collection-types','findone',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(519,'content-manager','collection-types','findone',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(520,'content-manager','collection-types','previewmanyrelations',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(521,'content-manager','collection-types','previewmanyrelations',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(522,'content-manager','collection-types','previewmanyrelations',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(523,'content-manager','collection-types','publish',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(524,'content-manager','collection-types','publish',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(525,'content-manager','collection-types','publish',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(526,'content-manager','collection-types','unpublish',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(527,'content-manager','collection-types','unpublish',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(528,'content-manager','collection-types','unpublish',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(529,'content-manager','collection-types','update',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(530,'content-manager','collection-types','update',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(531,'content-manager','collection-types','update',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(532,'content-manager','components','findcomponentconfiguration',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(533,'content-manager','components','findcomponentconfiguration',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(534,'content-manager','components','findcomponentconfiguration',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(535,'content-manager','components','findcomponents',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(536,'content-manager','components','findcomponents',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(537,'content-manager','components','findcomponents',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(538,'content-manager','components','updatecomponentconfiguration',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(539,'content-manager','components','updatecomponentconfiguration',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(540,'content-manager','components','updatecomponentconfiguration',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(541,'content-manager','content-types','findcontenttypeconfiguration',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(542,'content-manager','content-types','findcontenttypeconfiguration',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(543,'content-manager','content-types','findcontenttypeconfiguration',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(544,'content-manager','content-types','findcontenttypes',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(545,'content-manager','content-types','findcontenttypes',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(546,'content-manager','content-types','findcontenttypes',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(547,'content-manager','content-types','updatecontenttypeconfiguration',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(548,'content-manager','content-types','updatecontenttypeconfiguration',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(549,'content-manager','content-types','updatecontenttypeconfiguration',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(550,'content-manager','relations','find',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(551,'content-manager','relations','find',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(552,'content-manager','relations','find',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(553,'content-manager','single-types','createorupdate',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(554,'content-manager','single-types','createorupdate',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(555,'content-manager','single-types','createorupdate',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(556,'content-manager','single-types','delete',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(557,'content-manager','single-types','delete',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(558,'content-manager','single-types','delete',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(559,'content-manager','single-types','find',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(560,'content-manager','single-types','find',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(561,'content-manager','single-types','find',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(562,'content-manager','single-types','publish',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(563,'content-manager','single-types','publish',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(564,'content-manager','single-types','publish',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(565,'content-manager','single-types','unpublish',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(566,'content-manager','single-types','unpublish',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(567,'content-manager','single-types','unpublish',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(568,'content-manager','uid','checkuidavailability',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(569,'content-manager','uid','checkuidavailability',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(570,'content-manager','uid','checkuidavailability',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(571,'content-manager','uid','generateuid',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(572,'content-manager','uid','generateuid',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(573,'content-manager','uid','generateuid',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(577,'content-manager','content-types','findcontenttypessettings',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(578,'content-manager','content-types','findcontenttypessettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(579,'content-manager','content-types','findcontenttypessettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(580,'email','email','getsettings',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(581,'email','email','getsettings',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(582,'email','email','getsettings',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(583,'email','email','test',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(584,'email','email','test',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(585,'email','email','test',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(586,'i18n','content-types','getnonlocalizedattributes',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(587,'i18n','content-types','getnonlocalizedattributes',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(588,'i18n','content-types','getnonlocalizedattributes',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(589,'i18n','iso-locales','listisolocales',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(590,'i18n','iso-locales','listisolocales',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(591,'i18n','iso-locales','listisolocales',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(592,'i18n','locales','createlocale',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(593,'i18n','locales','createlocale',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(594,'i18n','locales','createlocale',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(595,'i18n','locales','deletelocale',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(596,'i18n','locales','deletelocale',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(597,'i18n','locales','deletelocale',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(598,'i18n','locales','listlocales',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(599,'i18n','locales','listlocales',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(600,'i18n','locales','listlocales',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(601,'i18n','locales','updatelocale',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(602,'i18n','locales','updatelocale',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(603,'i18n','locales','updatelocale',0,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(645,'application','project','update',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(646,'application','project','create',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(647,'application','project','count',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(648,'application','project','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(649,'application','project','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(660,'application','project','update',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(661,'application','project','create',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(662,'application','project','count',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(663,'application','project','findone',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(664,'application','project','find',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(675,'application','project','update',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(676,'application','project','create',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(677,'application','project','count',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(678,'application','project','findone',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(679,'application','project','find',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(681,'application','project','delete',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(684,'application','project','delete',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(687,'application','project','delete',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(689,'application','project','createlocalization',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(690,'application','project','createlocalization',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(691,'application','project','createlocalization',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(705,'application','remark','count',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(706,'application','remark','count',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(707,'application','remark','count',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(708,'application','remark','create',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(709,'application','remark','create',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(710,'application','remark','create',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(711,'application','remark','delete',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(712,'application','remark','delete',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(713,'application','remark','delete',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(714,'application','remark','find',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(715,'application','remark','find',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(716,'application','remark','find',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(717,'application','remark','findone',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(718,'application','remark','findone',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(719,'application','remark','findone',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(720,'application','remark','update',1,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(721,'application','remark','update',1,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(722,'application','remark','update',1,'',3,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(723,'guided-tour','guided-tour','index',0,'',1,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(724,'guided-tour','guided-tour','index',0,'',2,NULL,NULL);
INSERT INTO "users-permissions_permission" VALUES(725,'guided-tour','guided-tour','index',0,'',3,NULL,NULL);
CREATE TABLE `users-permissions_role` (`id` integer not null primary key autoincrement, `name` varchar(255) not null, `description` varchar(255) null, `type` varchar(255) null, `created_by` integer null, `updated_by` integer null);
INSERT INTO "users-permissions_role" VALUES(1,'Administrator','These users have all access in the project.','root',NULL,NULL);
INSERT INTO "users-permissions_role" VALUES(2,'Authenticated','Default role given to authenticated user.','authenticated',NULL,NULL);
INSERT INTO "users-permissions_role" VALUES(3,'Public','Default role given to unauthenticated user.','public',NULL,NULL);
CREATE TABLE `users-permissions_user` (`id` integer not null primary key autoincrement, `username` varchar(255) not null, `email` varchar(255) not null, `provider` varchar(255) null, `password` varchar(255) null, `resetPasswordToken` varchar(255) null, `confirmed` boolean null, `blocked` boolean null, `role` integer null, `created_by` integer null, `updated_by` integer null, `created_at` datetime null default CURRENT_TIMESTAMP, `updated_at` datetime null default CURRENT_TIMESTAMP);
INSERT INTO "users-permissions_user" VALUES(1,'Accrada','accrada@gmail.com','local','$2a$10$aKhCBsrCJ9YZTVzQdsZldeL6fjkBkpEN9KpJFaWUwU1SwLJFxq/Y.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(2,'tuskangles','tuskangles@gmail.com','local','$2a$10$BHELBvaA5j/8IBncz4zgd.t2npkgmc9N7B5sI92FaNZnX6P8wLIze',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(3,'planechange','planechange@gmail.com','local','$2a$10$PH/6/owJDxrx.HDImjLjQOoREeWkAPCNqsQWxvkFlvc9T4RHWiuGO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(4,'deskointment','deskointment@gmail.com','local','$2a$10$bm4ytA3Unu32dFBD.FCJ.OZmvKYdrWFPSZLUNeAs0Cd7Vk9lfm2qm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(5,'rumblecullionly','rumblecullionly@gmail.com','local','$2a$10$k3hTjNHtt5SdDUHAmufiLew9wqKr0rDbrcfbLzU/V1P6EnNT2KhGO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(6,'vengefulcofferdam','vengefulcofferdam@gmail.com','local','$2a$10$nWv9i07xOvlFM2W2lAoYs.wbS2MXisCBGIztRUkW7t9X.1u3pdX6m',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(7,'crumbedacetone','crumbedacetone@gmail.com','local','$2a$10$wPfzrxkGmJnv3YIMjPj2TOvCFdLZpWRDNCPXoFqYvOHDDTmXPX8Ye',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(8,'hamstringdusk','hamstringdusk@gmail.com','local','$2a$10$zfStpFvuq/t2IlDTRuE0K.qDvC5855K.NCETQKxSoG.3UhG3tRU3e',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(9,'bubblegumirritating','bubblegumirritating@gmail.com','local','$2a$10$KUmsUWoDCGW5VKrg378OiOn09wE4ZrzhegP.wcKpFlgfJ4TzTJONy',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(10,'cablebroad','cablebroad@gmail.com','local','$2a$10$jMA.RxmJ4iyqLv2bUZgj4enqiz.u7IUKlyqykscUIxJhGjmxujM/m',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(11,'lostriggcreatures','lostriggcreatures@gmail.com','local','$2a$10$FjK0parx029Dg7lvftd/kuSkIU/ik/bleGvDXodFl/E6J7VygQgZe',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(12,'wimpgland','wimpgland@gmail.com','local','$2a$10$kOKWl5tiA4n8.6/lN9xYe.MIK5JPwd21c9NnfO0TvFupNdoO21eKu',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(13,'leukocyteahead','leukocyteahead@gmail.com','local','$2a$10$wMCA/v8h3Fa/N6h3TtI0XeL8reRTwUh0RSb8OFCFi4Pbnhbq9gpi2',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(14,'pryelflock','pryelflock@gmail.com','local','$2a$10$jg.MJUzLZbjhvsncDC5v.e/78DBdWpjxAMnEE89qM6itYj3h1/B5e',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(15,'jemmybasket','jemmybasket@gmail.com','local','$2a$10$NKFXISttaPqIMQFHpNyvKOcKKro9eicK5.NYoWxrGe43R0BEG9D6y',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(16,'lankycalifornium','lankycalifornium@gmail.com','local','$2a$10$VyfUPM9toRs5jVVOPUG6POuFCJr.uGjG0B5.w1eekxuz251Txy7GC',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(17,'loyununtrium','loyununtrium@gmail.com','local','$2a$10$ds6U6aqB9HR4mH4K5tI3UOCniql2SEYM6NYu5sR20vv/XfiB0h6yO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(18,'sentencemour','sentencemour@gmail.com','local','$2a$10$ejzinfvH8XZ3.tQWkTqTkOpDJtt1tDU9ppfNKsECia1jkFkCB1x1.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(19,'steersmancovet','steersmancovet@gmail.com','local','$2a$10$lE5PB4IOVSacZoLrejHqceMTZJBYW9bqqMbOu0t5/Wb9hzTt3G9M.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(20,'lateraldysprosium','lateraldysprosium@gmail.com','local','$2a$10$8wLpm2ix4i09ChM6xTVcE.VJCEPgcVo/9jHAxaQ9JcanTOgqcxnIm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(21,'analystzany','analystzany@gmail.com','local','$2a$10$f6KQVGgB3Y1STSbc1Lkw9eMDNncHQUecnEjWUjs1UI9oLvdjEyzJm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(22,'ongiving','ongiving@gmail.com','local','$2a$10$xKacH7vESbSduOrPmY2.wOhS8I4T8hoWJ8nbW3I2bZ.gXb5/XsPky',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(23,'namakatext','namakatext@gmail.com','local','$2a$10$iZlhQMg6A6epy05DymlCh.9AHhopE78.BAw2a2eBAdjO2LeWqPWEW',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(24,'beardlint','beardlint@gmail.com','local','$2a$10$SEorsB2Ofdk/aMOu.RkvTOXZDxX52gnjth.Q3heVpF5uD25qXa61i',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(25,'wideeyedtroupe','wideeyedtroupe@gmail.com','local','$2a$10$nj7JRjBA.ekc6iMaJ6alJORRHdingI6G.dgSDRiBd1BccFktGdNjO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(26,'berkrounding','berkrounding@gmail.com','local','$2a$10$PLX3GB8oUvgU8AIjt3qgU.gUSrH7.bHG9i1XGI7kNiOCsifCMBdJy',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(27,'presentalias','presentalias@gmail.com','local','$2a$10$BZdAZQn9QFOVvv40qXKvqubA..RiKpI7LnMFwJCSMoacpxOHA7D0m',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(28,'footmanresurrect','footmanresurrect@gmail.com','local','$2a$10$vCx3iq4FrwOmiNCLIh5hheFiQpAD5Lf5D0Ma1OD/6c.xfhqaYUpNC',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(29,'swingerallegiance','swingerallegiance@gmail.com','local','$2a$10$zzTQNpfyhphUtRuUQVXa.uJUD34PTHcClnz7IRf4cGjTp8uE0puUS',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(30,'matlabregain','matlabregain@gmail.com','local','$2a$10$..9wMzA1HJulcHBe5xDMhOIa66Wb5Z0Lz1qwALZeZQgjwcrLN0sja',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(31,'catchabledramatic','catchabledramatic@gmail.com','local','$2a$10$DehWWl97Dif4hePaKWykJekAciNyQD7Pgiuhp7s9fARmxsn6IGB7y',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(32,'doinghorns','doinghorns@gmail.com','local','$2a$10$3rmoIpirreiciW1Z5ag1hOb3O7nQa9.2.Lz0IMssdSzrUjCowrmaG',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(33,'naptrunc','naptrunc@gmail.com','local','$2a$10$rvwBwr0qm5Dq3Mo5cPG0ve3BHVlzL5cdKAzVjmQwIFaYFZb0GTCbm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(34,'phonepigjump','phonepigjump@gmail.com','local','$2a$10$/wmEdBFCRfsQHonptJHPaePeDKwgExkNGUyFmf9D1K5KJV/bKg8W2',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(35,'lushlyexcretion','lushlyexcretion@gmail.com','local','$2a$10$g1U9bz7qlH5KDjqi3CY.kenIFaKoHENdtauFRiQzwLkF0BI8Wo106',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(36,'downloadcivil','downloadcivil@gmail.com','local','$2a$10$uwrxpHo6W2xBMcFq0TF0wu0KAhUhhBMaf/j4uoS/pKqTpmRgzKIoO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(37,'carbonrecast','carbonrecast@gmail.com','local','$2a$10$GbcYJksD9ziaYgeVOIs.kelMYymw4TXHQrCJhLKo2n8s1sFoe4OxS',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(38,'omissibletashing','omissibletashing@gmail.com','local','$2a$10$oqBo6tmUza/S8FQF4DI6O.c207Y0Va4W2w1Jw2LOSxrPqcvb.DP0.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(39,'puppyprint','puppyprint@gmail.com','local','$2a$10$PNtAZujiyYEoerrvUmmQL.XnWUywEVn0.15MjeeKoOACYO6OOC5ze',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(40,'yappingclassroom','yappingclassroom@gmail.com','local','$2a$10$IYHiuU4WtACt18ETOa1ckOLe5PNg70fBPVXC8hwHam4.iJ6Gc.9CG',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(41,'remoteessential','remoteessential@gmail.com','local','$2a$10$Jz69p6s7ftIhqwGBkzbHF.W/nhioCB9iQ/a.rpqCNIantIm1.XI.u',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(42,'tramuninsured','tramuninsured@gmail.com','local','$2a$10$VxtVf89P.d4iUfoNiVKk3.xl1UEZPdgS/S9VWETdyJ9muKd9APIKm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(43,'flaskreluctant','flaskreluctant@gmail.com','local','$2a$10$O8KD6RJd25i30UWGzIeU6.KzO6EBZwscKWNxlNCRlDgFfxT/MYFhe',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(44,'outeractivity','outeractivity@gmail.com','local','$2a$10$3QdxBamfsqTrq/U.KA8UN.fzO1OQTgSSBwQZt2wfYSwvBynYM21O.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(45,'xeroxchest','xeroxchest@gmail.com','local','$2a$10$iwR3uM.3hEPU3BotZsoMO.7f1aHmkr855YxZL1QVFD8ENhdXyU/wC',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(46,'hastinesslength','hastinesslength@gmail.com','local','$2a$10$ECu8SxAcWKTXqaDTDiPGWOJ88ntFuqFgOhrY54UrXtIYgSSCVg6He',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(47,'snowdropkooky','snowdropkooky@gmail.com','local','$2a$10$1n3VE3ZgEAQ1HgZ0rD57c.sn.imZqTQ0194MtAECkmP9ZC3lWAEsm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(48,'sodatokens','sodatokens@gmail.com','local','$2a$10$Q/xN7PfrBidtKDQL1sOpm.s03p2HRS./24rl04mzDUfiVHlPIyYxK',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(49,'unfastenwelcome','unfastenwelcome@gmail.com','local','$2a$10$NqGSi3A6V2slHoN.4CmIdeYqZRIukOSJ2UBA4Z3V0dMYEcYVvQ5kO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(50,'hardhatcowsic','hardhatcowsic@gmail.com','local','$2a$10$DpvzeOCdUzdNb7wzB1xKPu3l07SBZ9vHkUBfHAUWrlyVVFj6CBYYO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(51,'matinguneaten','matinguneaten@gmail.com','local','$2a$10$klLj1Q.Y9zpcnHeXfBlIX.2Agxxb9LbrzxmMLKv3Dt38//fI92m/6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(52,'prongnuptials','prongnuptials@gmail.com','local','$2a$10$Hjs4.SpFDTERdNyFMd/WkuaQMwWcHzvBqVGXPy7Le4Ec81GY.zMwK',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(53,'snappingcucumber','snappingcucumber@gmail.com','local','$2a$10$LiTlEWlWcKQxxWT3kJAHduUvV8U5gIp.mFPnU7cIbsw.OijB0plFa',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(54,'jacksuperbowl','jacksuperbowl@gmail.com','local','$2a$10$wBgtFKkPDBFowMKIhsf3pOPIOR41ZnxsxgIQBsjgTZBBol7xtYmmi',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(55,'choatgag','choatgag@gmail.com','local','$2a$10$g2TFGfHYbH2/VcPCJi2sEuRytdwF/mo1D76AHpzxxscU4kw/GnX3e',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(56,'timingmaintain','timingmaintain@gmail.com','local','$2a$10$qLzLK7E8rNzEMdQ.iE2hr.TkASMjwGVaHZ5l7qvNgL0hdJMrg2Udi',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(57,'criticismdeport','criticismdeport@gmail.com','local','$2a$10$AXKLO9fsJyRAf42x4wjwee1ru5F40Dbj2MkExlP0XgVpOEyAeJKyS',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(58,'nativesun','nativesun@gmail.com','local','$2a$10$H/VH.uF3xnp1BoT9xBArYehAwUSiE6nwI5xiXCbVUmH51g/4xk3Ya',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(59,'biologysoup','biologysoup@gmail.com','local','$2a$10$6OZjcW01uVOy7/6MhE6VTeL0o8ZrUhFCgUZm.OJLraZU4EsyQUAc6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(60,'thawculture','thawculture@gmail.com','local','$2a$10$6sYeXuhFOdZQVpL99Oy.LeQXDOodtEhaWC9YYQn3KMqxAJxnWYpJG',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(61,'lekearlobe','lekearlobe@gmail.com','local','$2a$10$3NpR901TyXZ/U8OHcDYlLe9j2aspBKU2D/jzmcVq9tKSSx.v.Jj9G',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(62,'censorflight','censorflight@gmail.com','local','$2a$10$wYl96u/dpRldfIPtUsgnvOLCEkkGC1o6mguVlowYWwLI.patf4c16',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(63,'unreachedavailable','unreachedavailable@gmail.com','local','$2a$10$FUABrYyeRMD68hECLHDPSOS1g8xUH1xtkpFXD2L/u/UjBnV63K73O',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(64,'nortoninevitable','nortoninevitable@gmail.com','local','$2a$10$GuY4dW43Ryph2LH4FMipIOwkkzuJw/VMUHnB4UuInqY1FdjyY9Q3m',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(65,'maplelewis','maplelewis@gmail.com','local','$2a$10$XuwPRq93KsaukqB92rIlyedTbF8/GWXxeGerszc5y./sxVLGDiAuS',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(66,'yttriumripple','yttriumripple@gmail.com','local','$2a$10$/HTaA2SD3fxmquHpzsZbjuA1rg1gPa3pZG92e98GLzv0GLZnw//Q.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(67,'lieflattered','lieflattered@gmail.com','local','$2a$10$NZpJKsp/XT03kuL6CY1VMeYbp/ryeqUf3vti3BpzCSuJhzCATPgR.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(68,'spraymosque','spraymosque@gmail.com','local','$2a$10$Y3vt4ih5XQ36FmXIDeDSa.67DXS2ahbXlbTvtGOov9AubQC0Ggr36',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(69,'untreatedmail','untreatedmail@gmail.com','local','$2a$10$cAdky8sidPUAhFLpGMO3mOYxAm2tmo3utuUA.QI7TCDEh6edYziMW',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(70,'aspireoctopus','aspireoctopus@gmail.com','local','$2a$10$LsIAr.yEljnXPg9nB0NBhu4YLqud/UFKbv0qBmHYpSNhLpsp5nIb6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(71,'scaredrainage','scaredrainage@gmail.com','local','$2a$10$0fHbxF9qAKea5DO.sNqEgO9NMGH1uz/sAO3gG4MQZRbMZnJdUl6Qe',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(72,'cremeadams','cremeadams@gmail.com','local','$2a$10$MIOM5LZCcYhOjhwM.tTFuOt1IOwPTEeKMqZIMJIZb8Ot/7hzpqsX6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(73,'trapperboth','trapperboth@gmail.com','local','$2a$10$eA58JNs6trYWeoeHWTKCZ.aAw5RuLVZuhdfSNImaICGalY8gmsH1C',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(74,'fancychancellor','fancychancellor@gmail.com','local','$2a$10$uAwuxaIZYsaeh0U9RC7hq.82foNuCoD2qvsPW08DXasDy9vMPnPCK',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(75,'brandbenny','brandbenny@gmail.com','local','$2a$10$Xocx03S4kWj2ZcX1xIKbiee7uI6KlZ4F52oXhPi8BsrCZC5XWfdam',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(76,'frokensaucepan','frokensaucepan@gmail.com','local','$2a$10$KKtnr7CMyzi950vtfiwhIO1GRy0P2urA7J3.GcVJmraJ6nSzvqtTO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(77,'meanwhilecoming','meanwhilecoming@gmail.com','local','$2a$10$B0JtireDd7bJi3mt6DIyruTS5cOA3EhhrawbhdIF7dgg584L19aOq',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(78,'unicornmobilize','unicornmobilize@gmail.Com','local','$2a$10$LmCMh2jrhqDwMj.qo1nmuep2iF/HhDcDjmUSCm.rnqXOYKBuY6OI.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(79,'noveltyblatantly','noveltyblatantly@gmail.com','local','$2a$10$W8aBdkgLiioQGxAt1KkdZ.jVr0LpZYGtWEgGMZyeso3ab42UXScoO',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(80,'sumsplornish','sumsplornish@gmail.com','local','$2a$10$Be3.kc5oDFCMeQ.XIYw7mOgrYs0j52tg1.zHV0a34lQAdvb9jOMSu',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(81,'fetchstrength','fetchstrength@gmail.com','local','$2a$10$LovkaRPv1TwR/e/84QPVnumwh/WwzsMcyNaE9hkP7E60QohqFL99q',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(82,'feabulge','feabulge@gmail.com','local','$2a$10$rBH9p86JT1CL1UE./q0YPu988OEvjfrkK1zqC7viHkel7VtOfqhXW',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(83,'millcivil','millcivil@gmail.com','local','$2a$10$UPr0M4U1.yKWXOcjqyAR2u/E7L5th4rhiDxHoJ4wvp0xbQIoBp8Qm',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(84,'dweebscraper','dweebscraper@gmail.com','local','$2a$10$5cCTlNqjH.STS6qLhZTOgOjguvkBSCMpyCyTT2szD.nXSFscXUNC6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(85,'clerkincredible','clerkincredible@gmail.com','local','$2a$10$XXtvJJazO/iWSVBypUpZ..HP81zuTvWfi.yPpDkPePxBBhseOUTva',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(86,'tarzanwham','tarzanwham@gmail.com','local','$2a$10$x7HvnhC2OxJEe7Uukeb75uU0qpEmLwbflXi8bB/6ZgO8dbQMcJjse',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(87,'fraidcorizon','fraidcorizon@gmail.com','local','$2a$10$M5LulQ3lVHkpGChHsS5aHeZb1RPF3UlEOKscIakFZ7z8D9Uk6j7pW',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(88,'imagevirgin','imagevirgin@gmail.com','local','$2a$10$wYO7cRgvGtz3Thy7OxTWfei9HvUZSi9owYco9HVya2zr3WKDsVkei',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(89,'dominancewhite','dominancewhite@gmail.com','local','$2a$10$iDTtn0wbfcNLpVP0lI1lweT/gRszoSGtVPdIwQaxYHhiD7zPz5Kc.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(90,'bingersmorals','bingersmorals@gmail.com','local','$2a$10$eMAFuAfI4bTU70k.va3SKu4I3fKf.EhIyUOvDzySnrT9WM.6O1By6',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(91,'dumpregistered','dumpregistered@gmail.com','local','$2a$10$TbG5YVtpaPSQ03NNpZFMBOCWL1WG5EwSPke5tu2AAUdNyhzR2Fd/.',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(92,'overstockjockstrap','overstockjockstrap@gmail.com','local','$2a$10$hX0hMP5Vk5HWPMXsQykt.uhOoeBmjThPlg5iwdqVBn5IK9/0IAqkK',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(93,'pleadmerchants','pleadmerchants@gmail.com','local','$2a$10$JSQ0.jkvrnBsXigCXsTctOzdWV8AjOSIphIR9bCFZqjUWcx7GexXi',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(94,'rockingrabble','rockingrabble@gmail.com','local','$2a$10$R0eWoUDDiiCiSxjyWIyx0.yYv4pS0pXKMmTlk0fduqv6V3Nwyz0pu',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(95,'chapsguessing','chapsguessing@gmail.com','local','$2a$10$0GEpKsTcGpFjjEevEIG.YO41QTNGgoUmKJ3msBDymLI8A4dbkg.FK',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(96,'lurchicy','lurchicy@gmail.com','local','$2a$10$A9ZlGkebkwqdjT6uCThMVu2XcYzvH.n1kQBvkVB94VwWWdcb9AbRq',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(97,'baryonwrist','baryonwrist@gmail.Com','local','$2a$10$PzqW5M5p7fhphc4zgy7Kf.yx0qzakkj9zA7VZSXfWjCI3NqqwXucS',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(98,'unsecuredpebbles','unsecuredpebbles@gmail.colm','local','$2a$10$s4uTFglnPrwgxaLHo6CXEeK31SWf2HBYqfSZrR8Z8iUkBpcchmybi',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(99,'koalamax','koalamax@gmail.com','local','$2a$10$4VU4eWQ6Za4sHr/ap5.6ROVkgC6oBH5L.trmoVj8MXJzwHsr7AGiq',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(100,'sophidubbed','sophidubbed@gmail.com','local','$2a$10$RNdZIIx9dmdYflfOpdAiieDqWBxjaVpereHnNYXjkBQcOEhS0qnaa',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(101,'sesamecollar','sesamecollar@gmail.com','local','$2a$10$WjV.RNbPy5sZ3h.oucWzsuKOZQPR2NXA7pnZaxWjYyeX77HTUJxu2',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL);
INSERT INTO "users-permissions_user" VALUES(102,'ttdo','ttdo@connect.ust.hk','local','$2a$10$OsQbWi5qOA2IUEF2Vky1BeqJBkQ9.H6OSILs0gthvf7oms9H3k7em',NULL,1,NULL,2,NULL,NULL,1628733837443,1628733837465);
INSERT INTO "users-permissions_user" VALUES(103,'admin','admin@gmail.com','local','$2a$10$hYZM6yvcJNcB.HUl4W0PoO7pDfU/g8a.MPfjJ/6lB07VyIfx8uSvO',NULL,1,NULL,2,NULL,NULL,1628733986952,1628733986983);
CREATE UNIQUE INDEX `strapi_administrator_email_unique` on `strapi_administrator` (`email`);
CREATE UNIQUE INDEX `i18n_locales_code_unique` on `i18n_locales` (`code`);
CREATE UNIQUE INDEX `users-permissions_role_type_unique` on `users-permissions_role` (`type`);
CREATE UNIQUE INDEX `categories_slug_unique` on `categories` (`slug`);
CREATE UNIQUE INDEX `projects_slug_unique` on `projects` (`slug`);
CREATE UNIQUE INDEX `users-permissions_user_username_unique` on `users-permissions_user` (`username`);
COMMIT;
